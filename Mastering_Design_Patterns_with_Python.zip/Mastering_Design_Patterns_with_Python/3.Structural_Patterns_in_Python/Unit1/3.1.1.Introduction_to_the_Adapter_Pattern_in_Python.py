from abc import ABC, abstractmethod

class EuropeanPlug:
    def connect(self):
        print("European plug connected.")

class USPlug(ABC):
    @abstractmethod
    def connect(self):
        pass

class Adapter(USPlug):
    def __init__(self, european_plug):
        self.european_plug = european_plug

    def connect(self):
        self.european_plug.connect()

# Client code
if __name__ == "__main__":
    european_plug = EuropeanPlug()
    adapter = Adapter(european_plug)
    adapter.connect()  # Output: European plug connected.