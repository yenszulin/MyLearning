from abc import ABC, abstractmethod

class EuropeanPlug:
    def connect(self):
        print("European plug connected.")

class BritishPlug:
    def connect(self):
        print("British plug connected.")

class USPlug(ABC):
    @abstractmethod
    def connect(self):
        pass

class Adapter(USPlug):
    def __init__(self, plug):
        self.plug = plug

    def connect(self):
        self.plug.connect()

# Client code
# european_plug = EuropeanPlug()
british_plug = BritishPlug()
adapter = Adapter(british_plug)
adapter.connect()  # Output: European plug connected.