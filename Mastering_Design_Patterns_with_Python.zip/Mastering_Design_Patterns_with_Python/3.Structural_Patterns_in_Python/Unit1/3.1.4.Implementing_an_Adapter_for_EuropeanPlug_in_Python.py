from abc import ABC, abstractmethod


# Adaptee
class EuropeanPlug:
    # TODO: Implement the connect method that prints "European plug connected."
    def connect(self):
        print("European plug connected.")


# Target Interface
class USPlug(ABC):
    @abstractmethod
    def connect(self):
        pass


# TODO: Implement the Adapter class here
# It should inherit from USPlug
# It should have a constructor that takes a EuropeanPlug instance
# It should have a connect method that calls the connect method of EuropeanPlug
# Adapter
class Adapter(USPlug):
    def __init__(self, european_plug):
        self.european_plug = european_plug

    def connect(self):
        self.european_plug.connect()


if __name__ == "__main__":
    euro_plug = EuropeanPlug()
    adapter = Adapter(euro_plug)
    adapter.connect()