from abc import ABC, abstractmethod


class BritishPlug:
    def engage(self):
        print("British plug engaged.")


class USPlug(ABC):
    @abstractmethod
    def connect(self):
        pass


class BritishToUSAdapter(USPlug):
    # TODO: Implement constructor to initialize member variable
    def __init__(self, british_plug):
        self.british_plug = british_plug  # Initialize member variable

    # TODO: Implement connect method to call engage method of BritishPlug
    def connect(self):
        self.british_plug.engage()  # Adapt to expected interface

if __name__ == "__main__":
    # Testing the adapter pattern
    british_plug = BritishPlug()
    # TODO: Instantiate adapter with BritishToUSAdapter object
    adapter = BritishToUSAdapter(british_plug)  # Instantiate adapter
    # TODO: Call connect method on adapter
    adapter.connect()  # Call connect method