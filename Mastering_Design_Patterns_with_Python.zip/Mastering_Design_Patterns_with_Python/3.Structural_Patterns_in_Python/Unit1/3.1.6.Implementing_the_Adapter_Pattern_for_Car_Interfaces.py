from abc import ABC, abstractmethod


# TODO: Define the VintageCar class
# It should have a method `drive` that prints "Driving a vintage car."
# Adaptee
class VintageCar:
    def drive(self):
        print("Driving a vintage car.")


# TODO: Define the ModernCarInterface class as an abstract class
# It should have an abstract method `start`
# Target Interface
class ModernCarInterface(ABC):
    @abstractmethod
    def start(self):
        pass


# TODO: Define the CarAdapter class that inherits from ModernCarInterface
# It should have a constructor that takes a VintageCar instance
# Implement the start method to call the drive method of VintageCar
# Adapter
class CarAdapter(ModernCarInterface):
    def __init__(self, vintage_car):
        self.vintage_car = vintage_car

    def start(self):
        self.vintage_car.drive()


# Client Code
if __name__ == "__main__":
    # TODO: Create an instance of VintageCar
    # TODO: Instantiate a CarAdapter object with the VintageCar instance
    # TODO: Call the start method on the CarAdapter instance
    vintage = VintageCar()  # Create an instance of VintageCar
    modern_adapter = CarAdapter(vintage)  # Instantiate adapter with VintageCar
    modern_adapter.start()
