from abc import ABC, abstractmethod

# Adaptee (Legacy)
class LegacySoundSystem:
    # TODO: Define and implement the play_sound method to print "Sound playing from legacy system."
    def play_sound(self):
        print("Sound playing from legacy system.")


# Target Interface
class ModernSoundSystemInterface(ABC):
    @abstractmethod
    def output_sound(self):
        pass


# Adapter
class SoundSystemAdapter(ModernSoundSystemInterface):
    def __init__(self, system):
        self.system = system

    # TODO: Implement the output_sound method
    def output_sound(self):
        # Delegates the call to the legacy system
        self.system.play_sound()


# Usage
if __name__ == "__main__":
    legacy_system = LegacySoundSystem()
    adapter = SoundSystemAdapter(legacy_system)

    adapter.output_sound()