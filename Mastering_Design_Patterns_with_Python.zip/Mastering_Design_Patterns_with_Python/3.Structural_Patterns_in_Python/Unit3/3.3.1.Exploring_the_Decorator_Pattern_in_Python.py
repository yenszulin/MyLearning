from abc import ABC, abstractmethod

class Coffee(ABC):
    def get_description(self):
        return "Coffee"

    @abstractmethod
    def cost(self):
        pass

class SimpleCoffee(Coffee):
    def cost(self):
        return 2.0

class CoffeeDecorator(Coffee):
    def __init__(self, decorated_coffee):
        self.decorated_coffee = decorated_coffee

    def get_description(self):
        return self.decorated_coffee.get_description()

    def cost(self):
        return self.decorated_coffee.cost()

class MilkDecorator(CoffeeDecorator):
    def get_description(self):
        return f"{self.decorated_coffee.get_description()}, Milk"

    def cost(self):
        return self.decorated_coffee.cost() + 0.5

class SugarDecorator(CoffeeDecorator):
    def get_description(self):
        return f"{self.decorated_coffee.get_description()}, Sugar"

    def cost(self):
        return self.decorated_coffee.cost() + 0.3

if __name__ == "__main__":
    # Example usage
    my_coffee = SimpleCoffee()
    print(f"Description: {my_coffee.get_description()}, Cost: {my_coffee.cost()}")

    my_coffee_with_milk = MilkDecorator(my_coffee)
    print(f"Description: {my_coffee_with_milk.get_description()}, Cost: {my_coffee_with_milk.cost()}")

    my_coffee_with_milk_and_sugar = SugarDecorator(my_coffee_with_milk)
    print(f"Description: {my_coffee_with_milk_and_sugar.get_description()}, Cost: {my_coffee_with_milk_and_sugar.cost()}")

    # Outputs:
    # Description: Coffee, Cost: 2.0
    # Description: Coffee, Milk, Cost: 2.5
    # Description: Coffee, Milk, Sugar, Cost: 2.8