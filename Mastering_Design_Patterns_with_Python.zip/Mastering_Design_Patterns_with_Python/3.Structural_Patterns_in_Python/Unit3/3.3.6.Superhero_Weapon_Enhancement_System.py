from abc import ABC, abstractmethod


# TODO: Define the Weapon class with a method get_description() and an abstract method power()
## Abstract Component ##
class Weapon(ABC):
    def get_description(self):
        return "Basic Weapon"

    @abstractmethod
    def power(self):
        pass


# TODO: Define the Sword class that inherits from Weapon. Implement the power() method to return 20.0.
## Concrete Component ##
class Sword(Weapon):
    def get_description(self):
        return "Sword"

    def power(self):
        return 20.0


# TODO: Define the WeaponDecorator class that inherits from Weapon. It should have a __init__ constructor to initialize a decorated_weapon. Implement get_description() to return the decorated weapon's description.
## Abstract Decorator ##
class WeaponDecorator(Weapon):
    def __init__(self, decorated_weapon):
        self.decorated_weapon = decorated_weapon

    def get_description(self):
        return self.decorated_weapon.get_description()

    def power(self):
        return self.decorated_weapon.power()


# TODO: Define the FirePowerDecorator class that inherits from WeaponDecorator. It should add " with Fire Power" to the description and 10.0 to the power.
## Concrete Decorator - Fire ##
class FirePowerDecorator(WeaponDecorator):
    def get_description(self):
        return f"{self.decorated_weapon.get_description()} with Fire Power"

    def power(self):
        return self.decorated_weapon.power() + 10.0


# TODO: Define the IcePowerDecorator class that inherits from WeaponDecorator. It should add " with Ice Power" to the description and 8.0 to the power.
class IcePowerDecorator(WeaponDecorator):
    def get_description(self):
        return f"{self.decorated_weapon.get_description()},  with Ice Power"

    def power(self):
        return self.decorated_weapon.power() + 8.0


if __name__ == "__main__":
    # Example usage
    # TODO: Create a new Sword object and print its description and power.
    my_sword = Sword()
    print(f"{my_sword.get_description()}, Cost: {my_sword.power()}")

    # TODO: Wrap the sword object with FirePowerDecorator and print the updated description and power.
    my_sword = FirePowerDecorator(my_sword)
    print(f"{my_sword.get_description()}, Cost: {my_sword.power()}")

    # TODO: Wrap the sword object with IcePowerDecorator and print the updated description and power.
    my_sword = IcePowerDecorator(my_sword)
    print(f"{my_sword.get_description()}, Cost: {my_sword.power()}")