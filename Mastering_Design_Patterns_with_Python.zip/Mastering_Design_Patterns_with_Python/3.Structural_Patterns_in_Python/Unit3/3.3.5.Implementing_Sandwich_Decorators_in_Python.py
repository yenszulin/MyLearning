from abc import ABC, abstractmethod


class Sandwich(ABC):
    def get_description(self):
        return "Basic Sandwich"

    @abstractmethod
    def cost(self):
        pass


class BasicSandwich(Sandwich):
    def cost(self):
        return 3.0


class SandwichDecorator(Sandwich):
    def __init__(self, decorated_sandwich):
        self.decorated_sandwich = decorated_sandwich

    def get_description(self):
        return self.decorated_sandwich.get_description()

    def cost(self):
        return self.decorated_sandwich.cost()


# TODO: Define the LettuceDecorator class that adds ", Lettuce" to the description and 0.5 to the cost.
class LettuceDecorator(SandwichDecorator):
    def get_description(self):
        return f"{self.decorated_sandwich.get_description()}, Lettuce"

    def cost(self):
        return self.decorated_sandwich.cost() + 0.5


# TODO: Define the TomatoDecorator class that adds ", Tomato" to the description and 0.7 to the cost.
class TomatoDecorator(SandwichDecorator):
    def get_description(self):
        return f"{self.decorated_sandwich.get_description()}, Tomato"

    def cost(self):
        return self.decorated_sandwich.cost() + 0.7


# TODO: Define the BaconDecorator class that adds ", Bacon" to the description and 1.5 to the cost.
class BaconDecorator(SandwichDecorator):
    def get_description(self):
        return f"{self.decorated_sandwich.get_description()}, Bacon"

    def cost(self):
        return self.decorated_sandwich.cost() + 1.5


if __name__ == "__main__":
    # Example usage
    # TODO: Create a new BasicSandwich object and print its description and cost.
    my_sandwich = BasicSandwich()
    # TODO: Wrap the sandwich object with LettuceDecorator and print the updated description and cost.
    my_sandwich = LettuceDecorator(my_sandwich)
    print(f"{my_sandwich.get_description()}, Cost: {my_sandwich.cost()}")
    # TODO: Wrap the sandwich object with TomatoDecorator and print the updated description and cost.
    my_sandwich = TomatoDecorator(my_sandwich)
    print(f"{my_sandwich.get_description()}, Cost: {my_sandwich.cost()}")
    # TODO: Wrap the sandwich object with BaconDecorator and print the updated description and cost.
    my_sandwich = BaconDecorator(my_sandwich)
    print(f"{my_sandwich.get_description()}, Cost: {my_sandwich.cost}")