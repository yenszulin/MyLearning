from abc import ABC, abstractmethod


# Abstract Component
class Task(ABC):
    @abstractmethod
    def show_info(self):
        pass


# TODO: Define the SimpleTask class inherited from Task. It should have a constructor
#       to initialize description and duration, and implement the show_info() method.
#       The show_info should say "<description> will take <duration> hours."
## Leaf ##
class SimpleTask(Task):
    def __init__(self, description, duration):
        self.description = description
        self.duration = duration

    def show_info(self):
        print(f"{self.description} will take {self.duration} hours.")


# TODO: Define the Project class inherited from Task. It should have a method to add
#       Task objects, and implement the show_info() method to display all tasks' details.
## Composite ##
class Project(Task):
    def __init__(self):
        self.tasks = []

    def add(self, task):
        self.tasks.append(task)

    def show_info(self):
        for task in self.tasks:
            task.show_info()


# Client code
if __name__ == "__main__":
    task1 = SimpleTask("Design", 5)
    task2 = SimpleTask("Implementation", 10)

    project = Project()
    project.add(task1)
    project.add(task2)

    project.show_info()