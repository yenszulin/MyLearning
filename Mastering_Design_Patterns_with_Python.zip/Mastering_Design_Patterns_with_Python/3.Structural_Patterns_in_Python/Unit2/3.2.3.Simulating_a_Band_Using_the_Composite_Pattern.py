from abc import ABC, abstractmethod


class Musician(ABC):
    @abstractmethod
    def show_details(self):
        pass


class SoloArtist(Musician):
    def __init__(self, name, instrument):
        self.name = name
        self.instrument = instrument

    def show_details(self):
        print(f"{self.name} plays the {self.instrument}.")


# TODO: Define the Band class inherited from Musician. Implement methods to add, and show_details of musicians (stored in a list).
class Band(Musician):
    def __init__(self):
        self.musicians = []

    def add(self, musician):
        self.musicians.append(musician)

    def remove(self, musician):
        self.musicians.pop()

    def show_details(self):
        for musician in self.musicians:
            musician.show_details()

if __name__ == "__main__":
    # Test the classes
    # TODO: Create two SoloArtist objects "John Doe" and "Jane Smith" with instruments "guitar" and "keyboard" respectively.
    artist1 = SoloArtist("John Doe", "guitar")
    artist2 = SoloArtist("Jane Smith", "keyboard")

    # TODO: Create a Band object and add the two SoloArtist objects to the band.
    band = Band()
    band.add(artist1)
    band.add(artist2)

    # TODO: Show the details of the band.
    band.show_details()