from abc import ABC, abstractmethod


# TODO: Define an abstract class `Exhibit` with an abstract method `show_details()`
## Abstract Component ##
class Exhibit(ABC):
    @abstractmethod
    def show_details():
        pass


# TODO: Define the `Painting` class inherited from `Exhibit`. It should have
#       a constructor to initialize `title` and `artist`, and implement the `show_details()` method that says "<title> by <artist>".
## Leaf ##
class Painting(Exhibit):
    def __init__(self, title, artist):
        self.title = title
        self.artist = artist

    def show_details(self):
        print(f"{self.title} by {self.artist}")


# TODO: Define the `Gallery` class inherited from `Exhibit`. It should have methods to add and
#       remove `Exhibit` objects, and implement the `show_details()` method to display all exhibits'
#       details.
## Composite ##
class Gallery(Exhibit):
    def __init__(self):
        self.exhibits = []

    def add(self, exhibit):
        self.exhibits.append(exhibit)

    def remove(self, exhibit):
        self.exhibits.remove(exhibit)

    def show_details(self):
        for exhibit in self.exhibits:
            exhibit.show_details()


# Client Code
if __name__ == "__main__":
    # TODO: Create `Painting` objects.
    # "Starry Night" by Vincent van Gogh
    # "Mona Lisa" by Leonardo da Vinci
    painting1 = Painting("Starry Night", "Vincent van Gogh")
    painting2 = Painting("Mona Lisa", "Leonardo da Vinci")

    # TODO: Create a `Gallery` object and add the `Painting` objects to it.
    gallery = Gallery()
    gallery.add(painting1)
    gallery.add(painting2)

    # TODO: Call the `show_details()` method for the `Gallery` to display the details of all exhibits.
    gallery.show_details()