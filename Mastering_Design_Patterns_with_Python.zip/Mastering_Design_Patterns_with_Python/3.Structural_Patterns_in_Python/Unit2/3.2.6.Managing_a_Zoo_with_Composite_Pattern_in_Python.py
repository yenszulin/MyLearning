from abc import ABC, abstractmethod


# TODO: Define an abstract class `Component` with an abstract method `display_details()`

## Abstract Component
class Component(ABC):
    @abstractmethod
    def display_details(self):
        pass


# TODO: Implement an `Animal` class inherited from `Component`. It should have a constructor
#       to initialize `name` and `species`, and implement the `display_details()` method that says: "Animal: <name> (<species>)".

## Leaf ##
class Animal(Component):
    def __init__(self, name, species):
        self.name = name
        self.species = species

    def display_details(self):
        print(f"Animal: {self.name} ({self.species})")


# TODO: Implement a `Zoo` class inherited from `Component`. It should have methods to add Component objects
#       and implement the `display_details()` method.

## Composite ##
class Zoo(Component):
    def __init__(self, name="Zoo Section"):
        self.name = name
        self.components = []

    def add(self, component):
        self.components.append(component)

    def remove(self, component):
        self.components.remove(component)

    def display_details(self):
        print(f"--- {self.name} ---")
        for component in self.components:
            component.display_details()

if __name__ == "__main__":
    # TODO: Create `Animal` objects like "Leo, the Lion", "Tina, the Tiger" and "Benny, the Bear".
    ## Create animals
    lion = Animal("Leo", "Lion")
    tiger = Animal("Tina", "Tiger")
    bear = Animal("Benny", "Bear")

    # TODO: Create a `Zoo` object representing the main zoo
    main_zoo = Zoo("Main Zoo")

    # TODO: Create sub-zoo big_cats_section representing the section for big cats.
    big_cats_section = Zoo("Big Cats Section")

    # TODO: Add the big cats (lion and tiger) to the big_cats_section.
    big_cats_section.add(lion)
    big_cats_section.add(tiger)

    # TODO: Add the bear to the main zoo.
    main_zoo.add(bear)

    # TODO: Add the big_cats_section to the main zoo.
    main_zoo.add(big_cats_section)

    # TODO: Display the details of the main_zoo.
    main_zoo.display_details()