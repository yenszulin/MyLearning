from abc import ABC, abstractmethod


class Employee(ABC):
    @abstractmethod
    def show_details(self):
        pass


class Developer(Employee):
    def __init__(self, name, position):
        self.name = name
        self.position = position

    def show_details(self):
        print(f"{self.name} works as {self.position}.")


class Manager(Employee):
    def __init__(self):
        self.employees = []

    def add(self, employee):
        self.employees.append(employee)

    def remove(self, employee):
        self.employees.remove(employee)

    # TODO: Implement the show_details method to display employee details for all employees
    def show_details(self):
        for employee in self.employees:
            employee.show_details()


if __name__ == "__main__":
    dev1 = Developer("John Doe", "Senior Developer")
    dev2 = Developer("Jane Smith", "Junior Developer")

    # TODO: Create a Manager object and add the developers to it
    manager = Manager()
    manager.add(dev1)
    manager.add(dev2)
    # TODO: Call the show_details method for the manager to display employee details
    manager.show_details()