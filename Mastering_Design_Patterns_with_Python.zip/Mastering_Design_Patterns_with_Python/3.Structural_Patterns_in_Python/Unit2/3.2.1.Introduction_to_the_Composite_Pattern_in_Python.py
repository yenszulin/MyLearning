from abc import ABC, abstractmethod

class Employee(ABC):
    @abstractmethod
    def show_details(self):
        pass

class Developer(Employee):
    def __init__(self, name, position):
        self.name = name
        self.position = position

    def show_details(self):
        print(f"{self.name} works as {self.position}.")

class Manager(Employee):
    def __init__(self):
        self.employees = []

    def add(self, employee):
        self.employees.append(employee)

    def remove(self, employee):
        self.employees.remove(employee)

    def show_details(self):
        for employee in self.employees:
            employee.show_details()