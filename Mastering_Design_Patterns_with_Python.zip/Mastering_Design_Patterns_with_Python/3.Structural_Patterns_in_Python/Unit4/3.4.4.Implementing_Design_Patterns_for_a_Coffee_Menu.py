# Your goal is to implement a set of classes to represent coffee items on a menu using both the Decorator
# Pattern and the Composite Pattern. Follow the TODO instructions to complete the task. You'll design various
# coffee items, decorate them with additives like vanilla and milk, and create a set of coffee items.

from abc import ABC, abstractmethod


# TODO: Define the base Coffee class inheriting from ABC with abstract methods get_description and cost
# Abstract Component
class Coffee(ABC):
    @abstractmethod
    def get_description(self):
        pass

    @abstractmethod
    def cost(self):
        pass


# TODO: Define the SimpleCoffee class inheriting from Coffee
# Concrete Component
class SimpleCoffee(Coffee):
    def get_description(self):
        return "Simple Coffee"

    def cost(self):
        return 2.0


# TODO: Define the CoffeeDecorator class inheriting from Coffee with an init method that takes a Coffee object
# Abstract Decorator
class CoffeeDecorator(Coffee):
    def __init__(self, coffee):
        self.coffee = coffee

    def get_description(self):
        return self.coffee.get_description()

    def cost(self):
        return self.coffee.cost()


# TODO: Define the VanillaDecorator class inheriting from CoffeeDecorator and overriding get_description and cost methods
# Concrete Decorators
class VanillaDecorator(CoffeeDecorator):
    def get_description(self):
        return f"{self.coffee.get_description()} with Vanilla"

    def cost(self):
        return self.coffee.cost() + 0.5


# TODO: Define the MilkDecorator class inheriting from CoffeeDecorator and overriding get_description and cost methods
class MilkDecorator(CoffeeDecorator):
    def get_description(self):
        return f"{self.coffee.get_description()} with Milk"

    def cost(self):
        return self.coffee.cost() + 0.3


# TODO: Define the CoffeeSet class inheriting from Coffee
# - This class should contain a list to store Coffee objects
# - It should implement methods to add a Coffee object, and to calculate the total cost and description of the set
# Composite-like container for multiple Coffee items
class CoffeeSet(Coffee):
    def __init__(self):
        self.coffees = []

    def add(self, coffee):
        self.coffees.append(coffee)

    def get_description(self):
        descriptions = [coffee.get_description() for coffee in self.coffees]
        return " | ".join(descriptions)

    def cost(self):
        return sum(coffee.cost() for coffee in self.coffees)


if __name__ == "__main__":
    # TODO: Create instances of SimpleCoffee, VanillaDecorator, and MilkDecorator
    # TODO: Create an instance of CoffeeSet and add the created coffee items
    # TODO: Print the description and total cost of the CoffeeSet
    # Create individual decorated coffees
    coffee1 = SimpleCoffee()
    coffee2 = VanillaDecorator(SimpleCoffee())
    coffee3 = MilkDecorator(VanillaDecorator(SimpleCoffee()))

    # Create a coffee set and add the drinks
    set_of_coffee = CoffeeSet()
    set_of_coffee.add(coffee1)
    set_of_coffee.add(coffee2)
    set_of_coffee.add(coffee3)

    # Display final results
    print("Coffee Set Description:")
    print(set_of_coffee.get_description())
    print(f"Total Cost: ${set_of_coffee.cost():.2f}")