# Your task is to enrich a GUI library with images by applying the Adapter and Composite patterns.
# You'll start by implementing basic image classes and then create a gallery to display them.
# Follow the TODO comments to complete the task.

from abc import ABC, abstractmethod


# TODO: Define the BaseImage class with a virtual display() method
# Abstract Component
class BaseImage(ABC):
    @abstractmethod
    def display(self):
        pass


# TODO: Define the WinImage class inheriting from BaseImage and overriding the display() method
# Concrete Component - Windows Image
class WinImage(BaseImage):
    def display(self):
        return "Win Image"


# TODO: Define the MacImage class inheriting from BaseImage and overriding the display() method
# Concrete Component - Mac Image
class MacImage(BaseImage):
    def display(self):
        return "Mac Image"


# TODO: Define the WinToMacAdapter class inheriting from MacImage
# and implementing the display() method to call WinImage's display() method
# Adapter: Adapts WinImage to MacImage behavior (if needed in a Mac-only context)
class WinToMacAdapter(MacImage):
    def __init__(self, win_image):
        self.win_image = win_image

    def display(self):
        return self.win_image.display()


# TODO: Define the ImageGallery class inheriting from BaseImage
# - Implement methods to add and remove BaseImage objects
# - Implement the display() method that iterates over added images and calls their display() method
# Composite: Gallery of BaseImage objects
class ImageGallery(BaseImage):
    def __init__(self):
        self.images = []

    def add(self, image: BaseImage):
        self.images.append(image)

    def remove(self, image: BaseImage):
        self.images.remove(image)

    def display(self):
        for img in self.images:
            print(img.display())


if __name__ == "__main__":
    # TODO: Create instances of WinImage, MacImage, and WinToMacAdapter
    # TODO: Create an instance of ImageGallery using MacImage and WinToMacAdapter
    win_image = WinImage()
    mac_image = MacImage()
    win_to_mac_adapter = WinToMacAdapter(win_image)

    # TODO: Display the ImageGallery to show all the images
    my_image_gallery = ImageGallery()
    my_image_gallery.add(win_image)
    my_image_gallery.add(mac_image)

    my_image_gallery.display()