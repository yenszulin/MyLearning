# Let's have some fun combining the Decorator and Adapter patterns to create a GUI library.
# Follow these steps:
# Enhance the Checkbox with a Label: Implement a CheckboxDecorator and a CheckboxWithLabel class to enhance a
# checkbox component with a label.
# Create a Mac-to-Windows Adapter: Implement the MacToWinCheckboxAdapter class to render a Mac-style checkbox
# using the Windows checkbox component.
# You will find TODO comments in the starter code to guide you through the process.
#

from abc import ABC, abstractmethod

# Decorator Pattern for GUI Library
# === Abstract Component ===
class Checkbox(ABC):
    @abstractmethod
    def render(self):
        pass


# Adapter Pattern for GUI Library
# === Concrete Components ===
class WinCheckbox(Checkbox):
    def render(self):
        print("Rendering a checkbox in a Windows style.")


class MacCheckbox(Checkbox):
    def render(self):
        print("Rendering a checkbox in a Mac style.")


# TODO: Define the MacToWinCheckboxAdapter class inheriting from Checkbox and implementing the render() method to call MacCheckbox's render() method
# Adapter: Adapts a MacCheckbox to act like a WinCheckbox
class MacToWinCheckboxAdapter(Checkbox):
    def __init__(self, mac_Checkbox):
        self.mac_Checkbox = mac_Checkbox

    def render(self):
        self.mac_Checkbox.render()


# TODO: Define the CheckboxDecorator class inheriting from Checkbox and implementing the render() method
# Abstract Decorator
class CheckboxDecorator(Checkbox):
    def __init__(self, decorated_checkbox):
        self.decorated_checkbox = decorated_checkbox

    def render(self):
        self.decorated_checkbox.render()


# TODO: Define the CheckboxWithLabel class inheriting from CheckboxDecorator and adding label behavior to the render() method
# Concrete Decorator: Adds label rendering
class CheckboxWithLable(CheckboxDecorator):
    def render(self):
        self.decorated_checkbox.render()
        print("-> with Lable")

# === Client Code ===
if __name__ == "__main__":
    # TODO: Create instances of WinCheckbox, MacCheckbox, and MacToWinCheckboxAdapter
    my_winCheckbox = WinCheckbox()
    my_macCheckbox = MacCheckbox()
    my_macToWinCheckboxAdapter = MacToWinCheckboxAdapter(my_macCheckbox)

    # TODO: Create an instance of CheckboxWithLabel using MacToWinCheckboxAdapter
    my_checkboxWithLable = CheckboxWithLable(my_macToWinCheckboxAdapter)
    # TODO: Render the CheckboxWithLabel
    my_checkboxWithLable.render()