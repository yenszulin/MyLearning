# Your task is to:
# Adapter Pattern: Create adapters for each payment gateway (PayPal, Stripe, Square) to standardize the API and data format.
# Composite Pattern: Create a product catalog where products can be individual items or bundles of items.
# Decorator Pattern: Add additional features to products such as promotions, discounts, and gift wrapping.
# Follow the TODO comments to implement the necessary components.

from abc import ABC, abstractmethod


# TODO: Define a PaymentGateway interface class with a process_payment method
## === Adapter Pattern ===

## Target Interface
class PaymentGateway(ABC):
    @abstractmethod
    def process_payment(self, amount):
        pass


# TODO: Implement PayPal, Stripe, and Square classes with different payment processing methods
## Adaptees (Third-party APIs simulated)
class PayPal:
    def send_money(self, amount):
        print(f"Processing ${amount:.2f} payment through PayPal.")


class Stripe:
    def make_payment(self, amount):
        print(f"Processing ${amount:.2f} payment through Stripe.")


class Square:
    def charge(self, amount):
        print(f"Processing ${amount:.2f} payment through Square.")


# TODO: Create PayPalAdapter, StripeAdapter, and SquareAdapter classes inheriting from PaymentGateway, using Adapter pattern
## Adapters
class PayPalAdapter(PaymentGateway):
    def __init__(self, paypal):
        self.paypal = paypal

    def process_payment(self, amount):
        self.paypal.send_money(amount)


class StripeAdapter(PaymentGateway):
    def __init__(self, stripe):
        self.stripe = stripe

    def process_payment(self, amount):
        self.stripe.make_payment(amount)


class SquareAdapter(PaymentGateway):
    def __init__(self, square):
        self.square = square

    def process_payment(self, amount):
        self.square.charge(amount)


# TODO: Define a ProductComponent interface class with a show_details method
## === Composite Pattern ===

## Component
class ProductComponent(ABC):
    @abstractmethod
    def show_details(self):
        pass

    @abstractmethod
    def get_price(self):
        pass


# TODO: Implement Product class inheriting from ProductComponent with name and price attributes
## Leaf
class Product(ProductComponent):
    def __init__(self, name, price):
        self.name = name
        self.price = price

    def show_details(self):
        print(f"Product: {self.name}, Price: ${self.price:.2f}")

    def get_price(self):
        return self.price


# TODO: Implement ProductBundle class inheriting from ProductComponent with a list of ProductComponent
class ProductBundle(ProductComponent):
    def __init__(self, name):
        self.name = name
        self.items = []

    # TODO: Implement add, remove methods, and show_details method in ProductBundle class
    ## Composite
    def add(self, item):
        self.items.append(item)

    def remove(self, item):
        self.items.remove(item)

    def show_details(self):
        print(f"Bundle: {self.name}")
        for item in self.items:
            item.show_details()

    def get_price(self):
        return sum(item.get_price() for item in self.items)


# TODO: Implement a ProductFeature class inheriting from ProductComponent, using Decorator pattern
## === Decorator Pattern ===

## Decorator Base
class ProductFeature(ProductComponent):
    def __init__(self, product):
        self.product = product

    def show_details(self):
        self.product.show_details()

    def get_price(self):
        return self.product.get_price()


# TODO: Implement DiscountFeature and GiftWrapFeature classes inheriting from ProductFeature, adding specific behaviors
# Concrete Decorators
class DiscountFeature(ProductFeature):
    def __init__(self, product, discount):
        super().__init__(product)
        self.discount = discount

    def show_details(self):
        super().show_details()
        print(f" -> with ${self.discount:.2f} discount")

    def get_price(self):
        return self.product.get_price() - self.discount


class GiftWrapFeature(ProductFeature):
    def show_details(self):
        super().show_details()
        print(" -> Gift wrapped")

    def get_price(self):
        return self.product.get_price() + 2.00  # flat gift wrap fee


# TODO: In the main function, create instances of payment adapters and process payments
# TODO: Create products, bundles, apply decorators, and display their details
if __name__ == "__main__":
    # TODO: Implement the main function as described with creation of instances and method calls
    # Payment Gateways
    paypal = PayPalAdapter(PayPal())
    stripe = StripeAdapter(Stripe())
    square = SquareAdapter(Square())

    # Products
    product1 = Product("Book", 15.00)
    product2 = Product("Pen", 2.00)

    # Bundle
    bundle = ProductBundle("Back-to-School Kit")
    bundle.add(product1)
    bundle.add(product2)

    # Decorated product
    wrapped_discounted_bundle = GiftWrapFeature(DiscountFeature(bundle, 3.00))

    # Display and total cost
    wrapped_discounted_bundle.show_details()
    total = wrapped_discounted_bundle.get_price()
    print(f"Total price: ${total:.2f}\n")

    # Payment
    print("Processing with PayPal:")
    paypal.process_payment(total)

    print("\nProcessing with Stripe:")
    stripe.process_payment(total)

    print("\nProcessing with Square:")
    square.process_payment(total)




