from abc import ABC, abstractmethod


class WinButton:
    def render(self):
        print("Rendering a button in a Windows style.")


class MacButton:
    def display(self):
        print("Rendering a button in a Mac style.")


class ButtonAdapter(WinButton):
    def __init__(self, button):
        self.button = button

    def render(self):
        self.button.display()


class Component(ABC):
    @abstractmethod
    def render(self):
        pass


class Container(Component):
    def __init__(self):
        self.components = []

    def add(self, component):
        self.components.append(component)

    def remove(self, component):
        self.components.remove(component)

    def render(self):
        for component in self.components:
            component.render()


class Button(Component):
    def render(self):
        print("Rendering a button.")


class ButtonDecorator(Component):
    def __init__(self, button):
        self.button = button

    def render(self):
        self.button.render()


class BorderDecorator(ButtonDecorator):
    def render(self):
        self.button.render()
        self.add_border()

    def add_border(self):
        print("Adding border.")


class EnabledDecorator(ButtonDecorator):
    def render(self):
        if self.is_enabled():
            self.button.render()
        else:
            print("Button is disabled.")

    def is_enabled(self):
        # Assuming some logic here to determine if the button is enabled
        return True


if __name__ == "__main__":
    # Intermediate Adapter Steps. First, let's create the MacButton and wrap it with the ButtonAdapter:
    mac_button = MacButton()
    win_button = ButtonAdapter(mac_button)
    win_button.render()  # Output: Rendering a button in a Mac style.

    # Intermediate Composite Steps. Next, we create a Container and add multiple Button elements to it:
    container = Container()
    container.add(Button())
    container.add(Button())
    container.render()
    # Output:
    # Rendering a button.
    # Rendering a button.

    #　Intermediate Decorator Steps.　Let's see how to use these decorators with a Button:
    button = Button()
    decorated_button = BorderDecorator(button)
    decorated_button.render()
    # Output:
    # Rendering a button.
    # Adding border.

    # Combining with Composite and Adapter Patterns
    mac_button = MacButton()
    win_button = ButtonAdapter(mac_button)
    decorated_win_button = BorderDecorator(win_button)
    decorated_win_button.render()
    # Output:
    # Rendering a button in a Mac style.
    # Adding border.

    container = Container()
    button1 = Button()
    button2 = Button()
    decorated_button1 = BorderDecorator(button1)
    decorated_button2 = EnabledDecorator(button2)
    container.add(decorated_button1)
    container.add(decorated_button2)
    container.render()
    # Output:
    # Rendering a button.
    # Adding border.
    # Rendering a button.