# In this task, you'll prove your skills by implementing a robust messaging system using the Adapter, Composite, and
# Decorator patterns. You'll create adapters for various platforms, manage individual and composite messages, and
# enhance messages with decorators:
#
# Adapter Pattern:
# Create adapters for different messaging platforms (WhatsAppAdapter, TelegramAdapter, SlackAdapter) to provide a
# consistent interface for sending messages.
#
# Composite Pattern:
# Implement a MessageComponent class where individual messages (e.g., TextMessage, ImageMessage) and composite messages
# (e.g., MessageGroup) can be managed uniformly.
#
# Decorator Pattern:
# Use decorators to add features like ReadReceiptDecorator and TimestampDecorator to existing messages.

from abc import ABC, abstractmethod
from datetime import datetime


# TODO: Define a MessagingPlatform interface class with a send_message method
# === Adapter Pattern ===

# Target interface
class MessagingPlatform(ABC):
    @abstractmethod
    def send_message(self, content):
        pass


# TODO: Implement WhatsApp, Telegram, and Slack classes with different messaging methods
# Adaptees (third-party message implementations)
class WhatsApp:
    def send(self, message):
        print(f"[WhatsApp] {message}")


class Telegram:
    def transmit(self, message):
        print(f"[Telegram] {message}")


class Slack:
    def post(self, message):
        print(f"[Slack] {message}")


# TODO: Create WhatsAppAdapter, TelegramAdapter, and SlackAdapter classes inheriting from MessagingPlatform, using Adapter pattern
# Adapters
class WhatsAppAdapter(MessagingPlatform):
    def __init__(self, whats_app):
        self.whats_app = whats_app

    def send_message(self, content):
        self.whats_app.send(content)


class TelegramAdapter(MessagingPlatform):
    def __init__(self, telegram):
        self.telegram = telegram

    def send_message(self, content):
        self.telegram.transmit(content)


class SlackAdapter(MessagingPlatform):
    def __init__(self, slack):
        self.slack = slack

    def send_message(self, content):
        self.slack.post(content)


# TODO: Define a MessageComponent interface class with show_details method
# Component
class MessageComponent(ABC):
    @abstractmethod
    def show_details(self):
        pass


# TODO: Implement TextMessage and ImageMessage classes inheriting from MessageComponent with content/path attributes
# Leaf: Text Message
class TextMessage(MessageComponent):
    def __init__(self, content):
        self.content = content

    def show_details(self):
        return f"Text: {self.content}"


# Leaf: Image Message
class ImageMessage(MessageComponent):
    def __init__(self, path):
        self.path = path

    def show_details(self):
        return f"Image: {self.path}"


# TODO: Implement MessageGroup class inheriting from MessageComponent with a list of MessageComponent*
# Composite: Group of messages
class MessageGroup(MessageComponent):
    def __init__(self, name):
        self.name = name
        self.messages = []

    # TODO: Implement add, remove, show_details methods in MessageGroup class
    def add(self, message):
        self.messages.append(message)

    def remove(self, message):
        self.messages.remove(message)

    def show_details(self):
        result = [f"--- Message Group: {self.name} ---"]
        for msg in self.messages:
            result.append(msg.show_details())
        return "\n".join(result)


# TODO: Implement a MessageDecorator class inheriting from MessageComponent, using Decorator pattern
# Base Decorator
class MessageDecorator(MessageComponent):
    def __init__(self, message):
        self.message = message

    def show_details(self):
        return self.message.show_details()


# TODO: Implement ReadReceiptDecorator and TimestampDecorator classes inheriting from MessageDecorator, adding specific behaviors
# Concrete Decorator: Read receipt
class ReadReceiptDecorator(MessageDecorator):
    def show_details(self):
        return self.message.show_details() + " [Read]"


# Concrete Decorator: Timestamp
class TimestampDecorator(MessageDecorator):
    def show_details(self):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return self.message.show_details() + f" [Sent at {now}]"


# TODO: In the main function, create instances of messaging adapters and send messages
# TODO: Create messages, message groups, apply decorators, and display their details
# === Main Application ===
if __name__ == "__main__":
    # TODO: Implement the main function as described with the creation of instances and method calls
    # Setup adapters
    whatsapp = WhatsAppAdapter(WhatsApp())
    telegram = TelegramAdapter(Telegram())
    slack = SlackAdapter(Slack())

    # Create messages
    msg1 = TextMessage("Good morning!")
    msg2 = ImageMessage("/images/sunrise.jpg")

    # Apply decorators
    msg1 = ReadReceiptDecorator(msg1)
    msg2 = TimestampDecorator(msg2)

    # Create a group and add messages
    group = MessageGroup("Morning Broadcast")
    group.add(msg1)
    group.add(msg2)

    # Show group details
    print(group.show_details())

    # Send messages using different platforms
    print("\n--- Sending Messages ---")
    whatsapp.send_message(msg1.show_details())
    telegram.send_message(msg2.show_details())
    slack.send_message("Don't forget the team meeting at 10 AM!")
