class Employee:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def details(self):
        print(f"Name: {self.name}, Age: {self.age}")


# TODO: Define the Manager class that extends Employee
# - Add a constructor that initializes the name, age, and level attributes
# - Override the details() method to print the level in addition to the name and age
class Manager(Employee):
    def __init__(self, name, age, level):
        super().__init__(name, age)
        self.level = level

    def details(self):
        super().details()
        print(f"Level: {self.level}")


# TODO: Define the Engineer class that extends Employee
# - Add a constructor that initializes the name, age, and field attributes
# - Override the details() method to print the field in addition to the name and age
class Engineer(Employee):
    def __init__(self, name, age, field):
        super().__init__(name, age)
        self.field = field

    def details(self):
        super().details()
        print(f"Field: {self.field}")


def main():
    # TODO: Create an instance of Manager with the name "John", age 45, and level "Senior"
    manager = Manager("John", 45, "Senior")
    # TODO: Create an instance of Engineer with the name "Doe", age 32, and field "Software"
    engineer = Engineer("Doe", 32, "Software")
    # TODO: Call the details() method for each instance
    manager.details()
    engineer.details()


if __name__ == "__main__":
    main()