# class Animal:
#     def speak(self):
#         print("Animal speaks")
#
# class Dog(Animal):
#     def bark(self):
#         print("Dog barks")
#
#
# if __name__ == "__main__":
#     d = Dog()
#     d.speak()  # inherited from Animal
#     d.bark()   # defined in Dog
#
#     # In this snippet, the Dog class overrides the speak method of the Animal class.When the speak method is called on
#     # an instance of Dog, the overridden method in Dog is executed instead of the method in Animal.In contrast to the
#     # previous lesson's example, we do not call super().speak() here because we intend to completely override the method
#     # from the parent class.
#

class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def display(self):
        print(f"Name: {self.name}, Age: {self.age}")


class Student(Person):
    def __init__(self, name, age, major):
        super().__init__(name, age)
        self.major = major

    def display(self):
        super().display()
        print(f"Major: {self.major}")


class Teacher(Person):
    def __init__(self, name, age, subject):
        super().__init__(name, age)
        self.subject = subject

    def display(self):
        super().display()
        print(f"Subject: {self.subject}")


def show_person_info(person):
    person.display()


if __name__ == "__main__":
    student = Student("Alice", 30, "Computer Science")
    teacher = Teacher("Bob", 25, "Mathematics")

    show_person_info(student)
    # Output:
    # Name: Alice, Age: 30
    # Major: Computer Science

    show_person_info(teacher)
    # Output:
    # Name: Bob, Age: 25
    # Subject: Mathematics





