# TODO: Define a class Device with the following:
# - A constructor that initializes the device name and power status
# - A method 'status' that prints the device name and power status
class Device:
    def __init__(self, name, power_status):
        self.name = name
        self.power_status = power_status

    def status(self):
        print(f"Device Name: {self.name}, Power Status: {self.power_status}")


# TODO: Define a class Laptop that extends Device with the following:
# - A constructor that initializes the name, power status, and OS
# - A 'status' method that prints device info and the OS in addition to the base class info
class Laptop(Device):
    def __init__(self, name, power_status, os):
        super().__init__(name, power_status)
        self.os = os

    def status(self):
        super().status()
        print(f"Operating System: {self.os}")


# TODO: Define a class Smartphone that extends Device with the following:
# - A constructor that initializes the name, power status, and carrier
# - A 'status' method that prints device info and the carrier in addition to the base class info
class Smartphone(Device):
    def __init__(self, name, power_status, carrier):
        super().__init__(name, power_status)
        self.carrier = carrier

    def status(self):
        super().status()
        print(f"Carrier: {self.carrier}")


# TODO: In the main function, create a Laptop and a Smartphone instance
# Print their statuses using the 'status' method

def main():
    # TODO: Create instances of Laptop with the name "MacBook Pro", power status "On", and OS "macOS"
    # TODO: Create instances of Smartphone with the name "iPhone", power status "Off", and carrier "Verizon"
    # Call their 'status' method to display their details
    laptop = Laptop("MacBook Pro", "On", "macOS")
    smartphone = Smartphone("iPhone", "Off", "Verizon")

    # Display their statuses
    laptop.status()
    print()  # Just to separate the output visually
    smartphone.status()


if __name__ == "__main__":
    main()
