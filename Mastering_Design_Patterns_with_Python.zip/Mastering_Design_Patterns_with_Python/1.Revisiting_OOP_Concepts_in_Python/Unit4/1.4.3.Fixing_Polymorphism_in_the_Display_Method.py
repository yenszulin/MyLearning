class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def display(self):
        print(f"Name: {self.name}, Age: {self.age}")


class Student(Person):
    def __init__(self, name, age, major):
        super().__init__(name, age)
        self.major = major

    def display(self):
        super().display()
        print(f"Major: {self.major}")


class Teacher(Person):
    def __init__(self, name, age, subject):
        super().__init__(name, age)
        self.subject = subject

    def display(self):
        super().display()
        print(f"Subject: {self.subject}")


def main():
    people = [
        Person("Alice", 30),
        Student("Bob", 20, "Computer Science"),
        Teacher("Charlie", 40, "Mathematics")
    ]

    for person in people:
        person.display()


if __name__ == "__main__":
    main()