class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def display(self):
        print(f"Name: {self.name}, Age: {self.age}")

    # TODO: Add the introduce() method here
    # It should print "Hello, I am a person"
    def introduce(self):
        print("Hello, I am a person")


class Student(Person):
    def __init__(self, name, age, major):
        super().__init__(name, age)
        self.major = major

    def display(self):
        super().display()
        print(f"Major: {self.major}")

    # TODO: Add the introduce() method here
    # It should print "Hello, I am a student"
    def introduce(self):
        print("Hello, I am a student")


class Teacher(Person):
    def __init__(self, name, age, subject):
        super().__init__(name, age)
        self.subject = subject

    def display(self):
        super().display()
        print(f"Subject: {self.subject}")


if __name__ == "__main__":
    person1 = Student("Alice", 30, "Computer Science")
    person2 = Teacher("Bob", 25, "Mathematics")

    person1.display()
    # TODO: Call the introduce() method for the Student object
    person1.introduce()

    person2.display()
    # TODO: Call the introduce() method for the Teacher object (you should see Person class methods instead)
    person2.introduce()

    # Name: Alice, Age: 30
    # Major: Computer Science
    # Hello, I am a student
    # Name: Bob, Age: 25
    # Subject: Mathematics
    # Hello, I am a person