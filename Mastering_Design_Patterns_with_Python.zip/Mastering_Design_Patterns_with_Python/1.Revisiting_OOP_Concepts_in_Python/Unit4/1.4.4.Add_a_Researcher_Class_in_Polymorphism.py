class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def display(self):
        print(f"Name: {self.name}, Age: {self.age}")


class Student(Person):
    def __init__(self, name, age, major):
        super().__init__(name, age)
        self.major = major

    def display(self):
        super().display()
        print(f"Major: {self.major}")


class Teacher(Person):
    def __init__(self, name, age, subject):
        super().__init__(name, age)
        self.subject = subject

    def display(self):
        super().display()
        print(f"Subject: {self.subject}")


# TODO: Define the Researcher class as a derived class of Teacher with custom `field` attribute
# TODO: Add a constructor that initializes the name, age, subject, and field attributes,
# TODO: Override the display method to include the field attribute
class Researcher(Teacher):
    def __init__(self, name, age, subject, field):
        super().__init__(name, age, subject)
        self.field = field

    def display(self):
        super().display()
        print(f"Field: {self.field}")


def main():
    person1 = Student("Alice", 30, "Computer Science")
    person2 = Teacher("Bob", 25, "Mathematics")
    # TODO: Create a Researcher object with the name "Eve", age 35, subject "Machine Learning", and field "Artificial Intelligence"
    person3 = Researcher("Eve", 35, "Machine Learning", "Artificial Intelligence")

    person1.display()
    person2.display()
    # TODO: Display the Researcher object
    person3.display()


if __name__ == "__main__":
    main()