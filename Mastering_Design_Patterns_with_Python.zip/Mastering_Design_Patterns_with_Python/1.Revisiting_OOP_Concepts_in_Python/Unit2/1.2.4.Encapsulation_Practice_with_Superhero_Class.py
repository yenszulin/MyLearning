class Superhero:
    def __init__(self, alias, strength):
        self.__alias = alias
        self.__strength = strength

    # TODO: Define the set_alias method
    def set_alias(self, alias):
        self.__alias = alias

    # TODO: Define the set_strength method
    def set_strength(self, strength):
        self.__strength = strength

    # TODO: Define the get_alias method
    def get_alias(self):
        return self.__alias

    # TODO: Define the get_strength method
    def get_strength(self):
        return self.__strength


if __name__ == "__main__":
    # Create an instance of Superhero
    hero = Superhero("Iron Man", 85)

    # TODO: Use set_alias and set_strength methods to change the values to "Doctor Strange" and 95
    hero.set_alias("Doctor Strange")
    hero.set_strength(95)
    # TODO: Print the alias and strength using get_alias and get_strength methods
    print(hero.get_alias())
    print(hero.get_strength())