from abc import ABC, abstractmethod

class Shape(ABC):
    @abstractmethod
    def area(self):
        pass

    @abstractmethod
    def perimeter(self):
        pass


class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return 3.14159 * self.radius * self.radius

    def perimeter(self):
        return 2 * 3.14159 * self.radius


class Rectangle(Shape):
    def __init__(self, width, height):
        self.width = width
        self.height = height

    def area(self):
        return self.width * self.height

    def perimeter(self):
        return 2 * (self.width + self.height)


if __name__ == "__main__":
    circle = Circle(5)
    rectangle = Rectangle(4, 6)

    print(f"Circle Area: {circle.area()}, Perimeter: {circle.perimeter()}")
    # Output: Circle Area: 78.53975, Perimeter: 31.4159
    print(f"Rectangle Area: {rectangle.area()}, Perimeter: {rectangle.perimeter()}")
    # Output: Rectangle Area: 24, Perimeter: 20

#
# Here, the Shape class is an abstract class that sets a blueprint with two abstract methods: area and perimeter.
# Subclasses must implement these methods. The Circle class inherits from Shape, using its constructor to initialize
# the radius and providing specific implementations for calculating the circle's area and perimeter based on the radius.
# The Rectangle class also inherits from Shape, initializing its width and height in the constructor, and implementing
# methods to compute its area and perimeter.
#
# In the __main__ block, instances of Circle and Rectangle are created, and their areas and perimeters are printed,
# demonstrating the concrete implementations in each subclass. Importantly, the Shape class cannot be instantiated directly;
# only its subclasses with concrete method implementations can be instantiated. This ensures a consistent interface,
# enhancing code maintainability and readability by enforcing a structured and predictable way of defining shapes.