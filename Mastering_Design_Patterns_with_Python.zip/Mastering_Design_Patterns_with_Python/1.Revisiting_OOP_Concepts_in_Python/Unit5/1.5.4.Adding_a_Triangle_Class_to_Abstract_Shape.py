from abc import ABC, abstractmethod
from math import sqrt


class Shape(ABC):
    @abstractmethod
    def area(self):
        pass

    @abstractmethod
    def perimeter(self):
        pass


class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return 3.14159 * self.radius * self.radius

    def perimeter(self):
        return 2 * 3.14159 * self.radius


class Rectangle(Shape):
    def __init__(self, width, height):
        self.width = width
        self.height = height

    def area(self):
        return self.width * self.height

    def perimeter(self):
        return 2 * (self.width + self.height)


# TODO: Add the Triangle class
class Triangle(Shape):
    # TODO: It should inherit from the Shape class and have a custom field for the side length
    # TODO: It should have a constructor that takes the side length as an argument
    def __init__(self, side):
        self.side = side

    # TODO: Override the area function to return the area of an equilateral triangle: (sqrt(3) / 4) * side * side
    def area(self):
        return (sqrt(3) / 4) * self.side * self.side

    # TODO: Override the perimeter function to return the perimeter of an equilateral triangle: 3 * side
    def perimeter(self):
        return 3 * self.side


if __name__ == "__main__":
    shape = Circle(3)
    print(f"Shape Area: {shape.area()}, Perimeter: {shape.perimeter()}")

    rectangle = Rectangle(4, 6)
    print(f"Rectangle Area: {rectangle.area()}, Perimeter: {rectangle.perimeter()}")

    # TODO: Instantiate Triangle class with side length 3
    # TODO: Output its area and perimeter
    triangle = Triangle(3)
    print(f"Triangle Area: {triangle.area()}, Perimeter: {triangle.perimeter()}")