from abc import ABC, abstractmethod


class Shape(ABC):
    @abstractmethod
    def area(self):
        pass

    @abstractmethod
    def perimeter(self):
        pass

    # TODO: Add an abstract method 'description'
    @abstractmethod
    def description(self):
        pass


class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return 3.14159 * self.radius * self.radius

    def perimeter(self):
        return 2 * 3.14159 * self.radius

    # TODO: Implement the description method for Circle
    # return "This is a circle."
    def description(self):
        return "This is a circle."


class Rectangle(Shape):
    def __init__(self, width, height):
        self.width = width
        self.height = height

    def area(self):
        return self.width * self.height

    def perimeter(self):
        return 2 * (self.width + self.height)

    # TODO: Implement the description method for Rectangle
    # return "This is a rectangle."
    def description(self):
        return "This is rectangle."


if __name__ == "__main__":
    shape = Circle(3)
    print(f"Shape Area: {shape.area()}, Perimeter: {shape.perimeter()}")
    # TODO: Print the description of the shape
    print(f"Description: {shape.description()}")

    shape = Rectangle(4, 6)
    print(f"Shape Area: {shape.area()}, Perimeter: {shape.perimeter()}")
    # TODO: Print the description of the shape
    print(f"Description: {shape.description()}")