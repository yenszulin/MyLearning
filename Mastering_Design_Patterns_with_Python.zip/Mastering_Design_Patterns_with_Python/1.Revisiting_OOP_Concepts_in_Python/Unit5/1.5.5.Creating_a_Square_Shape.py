from abc import ABC, abstractmethod


class Shape(ABC):
    @abstractmethod
    def area(self):
        pass

    @abstractmethod
    def perimeter(self):
        pass


class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return 3.14159 * self.radius * self.radius

    def perimeter(self):
        return 2 * 3.14159 * self.radius


class Rectangle(Shape):
    def __init__(self, width, height):
        self.width = width
        self.height = height

    def area(self):
        return self.width * self.height

    def perimeter(self):
        return 2 * (self.width + self.height)


# TODO: Add the Square class
class Square(Rectangle):
    # TODO: It should inherit from the Rectangle class
    # TODO: Override the constructor to take a single side length and pass it as both width and height to the Rectangle constructor
    def __init__(self, side):
        super().__init__(side, side)


if __name__ == "__main__":
    shape = Circle(3)
    print(f"Shape Area: {shape.area()}, Perimeter: {shape.perimeter()}")

    rectangle = Rectangle(4, 6)
    print(f"Rectangle Area: {rectangle.area()}, Perimeter: {rectangle.perimeter()}")

    # TODO: Instantiate Square class with side length 3
    # TODO: Output its area and perimeter
    square = Square(3)
    print(f"Square Area: {square.area()}, Square Perimeter: {square.perimeter()}")