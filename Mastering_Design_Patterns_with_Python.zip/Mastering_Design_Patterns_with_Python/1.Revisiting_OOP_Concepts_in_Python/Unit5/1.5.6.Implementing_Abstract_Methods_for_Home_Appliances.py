from abc import ABC, abstractmethod


# TODO: Define an abstract class Appliance with abstract methods turn_on and turn_off
class Appliance(ABC):
    @abstractmethod
    def turn_on(self):
        pass

    @abstractmethod
    def turn_off(self):
        pass


# TODO: Define a class Television that inherits from Appliance and implements turn_on and turn_off
class Television(Appliance):
    # The turn_on method should print "The television is now ON."
    def turn_on(self):
        print("The television is now ON.")

        # The turn_off method should print "The television is now OFF."

    def turn_off(self):
        print("The television is now OFF.")


# TODO: Define a class WashingMachine that inherits from Appliance and implements turn_on and turn_off
class WashingMachine(Appliance):
    # The turn_on method should print "The washing machine is now ON."
    def turn_on(self):
        print("The washing machine is now ON.")

    # The turn_off method should print "The washing machine is now OFF."
    def turn_off(self):
        print("The washing machine is now OFF.")


if __name__ == "__main__":
    # TODO: Create an instance of Television and call its methods
    television = Television()
    television.turn_on()
    television.turn_off()

    # TODO: Create an instance of WashingMachine and call its methods
    washingMachine = WashingMachine()
    washingMachine.turn_on()
    washingMachine.turn_off()