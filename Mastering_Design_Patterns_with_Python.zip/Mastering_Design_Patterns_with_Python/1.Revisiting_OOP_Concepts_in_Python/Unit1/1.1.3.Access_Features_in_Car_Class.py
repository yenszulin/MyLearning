class Car:
    number_of_wheels = 4  # Class attribute

    def __init__(self, brand):
        self.brand = brand  # Instance attribute

    def display(self):
        print(f"Brand: {self.brand}, Wheels: {self.number_of_wheels}")


if __name__ == "__main__":
    car1 = Car("Tesla")
    car2 = Car("Toyota")

    car1.display()  # Output: Brand: Tesla, Wheels: 4
    car2.display()  # Output: Brand: Toyota, Wheels: 4

    # TODO: Modify attributes so the expected output is produced
    car1.number_of_wheels = 6
    car2.number_of_wheels = 6
    car1.display()  # Expected Output: Brand: Tesla, Wheels: 6
    car2.display()  # Expected Output: Brand: Toyota, Wheels: 6

    # TODO: Modify attributes so the expected output is produced
    car1.brand = "Ford"
    car1.number_of_wheels = 2
    car1.display()  # Expected Output: Brand: Ford, Wheels: 2
    car2.display()  # Expected Output: Brand: Toyota, Wheels: 6
