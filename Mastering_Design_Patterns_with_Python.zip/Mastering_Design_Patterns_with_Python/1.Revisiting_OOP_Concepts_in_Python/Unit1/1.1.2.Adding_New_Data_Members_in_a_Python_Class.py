class Musician:
    def __init__(self, name, instrument, years_active):
        self.name = name
        self.instrument = instrument
        self.years_active = years_active

    def display(self):
        # TODO: Update the display method to include the years_active data member
        print(f"Name: {self.name}, Instrument: {self.instrument}, Years active: {self.years_active}")


if __name__ == "__main__":
    # TODO: Update the instance of Musician to include the years_active data member with a value of 10
    musician = Musician("John", "Guitar", 10)
    musician.display()