class Person:
    species = "Homo sapiens"  # Class attribute shared by all instances

    def __init__(self, name, age):
        self.name = name
        self.age = age

    def display(self):
        print(f"Name: {self.name}, Age: {self.age}")

    def update_age(self, new_age):
        self.age = new_age





if __name__ == "__main__":
    person = Person("Alice", 30)  # Creating an object
    person.display()  # Print the object's data: "Name: Alice, Age: 30"

    person_copy = Person(person.name, person.age)  # Copying the object
    person_copy.display()

    person1 = Person("Alice", 30)
    person2 = Person("Bob", 25)

    print(person1.species)  # Output: Homo sapiens
    print(person2.species)  # Output: Homo sapiens

    Person.species = "Neanderthal"

    print(person1.species)  # Output: Neanderthal
    print(person2.species)  # Output: Neanderthal

    person1.species = "Chimpanzee"

    print(person1.species)  # Output: Chimpanzee
    print(person2.species)  # Output: Neanderthal



