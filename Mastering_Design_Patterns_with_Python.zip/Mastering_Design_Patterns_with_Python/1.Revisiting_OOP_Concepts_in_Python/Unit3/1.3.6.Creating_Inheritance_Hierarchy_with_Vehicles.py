# TODO: Define the Vehicle class with attributes make and year
class Vehicle:
    # Define a constructor to initialize make and year
    # Define a display method that shows the make and year as "Make: make, Year: year"
    def __init__(self, make, year):
        self.make = make
        self.year = year

    def display(self):
        print(f"Make: {self.make}, Year: {self.year}")


# TODO: Define the Car class that inherits from Vehicle with an additional attribute model
# Define a constructor to initialize make, year, and model
# Define a display method to show the make, year, and model
class Car(Vehicle):
    def __init__(self, make, year, model):
        super().__init__(make, year)
        self.model = model

    def display(self):
        super().display()
        print(f"Model: {self.model}")


if __name__ == "__main__":
    # TODO: Create an object of Car and call the display method to show its details
    Car1 = Car("Volvo", 2025, "XC60")
    Car1.display()