# Introduction to Inheritance
# Inheritance is a way to establish a relationship between a new class (derived class) and an existing
# class (base class). The derived class inherits properties and behaviors (methods) from the base class.

class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def display(self):
        print(f"Name: {self.name}, Age: {self.age}")


class Student(Person):
    def __init__(self, name, age, major):
        super().__init__(name, age)
        self.major = major

    def display(self):
        super().display()
        print(f"Major: {self.major}")


class Employee(Person):
    def __init__(self, name, age, position):
        super().__init__(name, age)
        self.position = position

    def display(self):
        super().display()
        print(f"Position: {self.position}")

    def work(self):
        print(f"{self.name} is working as a {self.position}")

if __name__ == "__main__":
    student = Student("Bob", 25, "Computer Science")
    student.display()
    # Output:
    # Name: Bob, Age: 25
    # Major: Computer Science

    employee = Employee("Alice", 30, "Engineer")
    employee.display()
    employee.work()
    # Output:
    # Name: Alice, Age: 30
    # Position: Engineer
    # Alice is working as a Engineer

# ✅ Code Structure Summary
# You have:
#
# A base class: Person
#
# A subclass: Student, which inherits from Person
#
# A test in __main__ that creates a Student object and calls its display() method.

# 🔍 Explanation:
# __init__: This is the constructor for the Person class. It initializes two attributes: name and age.
#
# display(): This method prints the name and age of the person in a formatted string.

# 🔍 Explanation:
# class Student(Person): This means Student is a subclass of Person. It inherits all attributes and
# methods from Person.
#
# __init__: This constructor adds an extra parameter major and uses super().__init__(...) to call the
# constructor of Person. So it reuses the logic from the base class and then adds its own
# (self.major = major).
#
# display(): This overrides the display method in the base class.
#
# It first calls super().display() to print name and age using the base class method.
#
# Then it prints the student's major.

# How Inheritance Works
# When you declare a derived class, you specify the base class it inherits from using the class
# DerivedClass(BaseClass) syntax. The derived class extends or overrides the functionality of the base
# class.
#
# In our example, the Person class serves as the base class, while the Student class is the derived
# class, inheriting name and age attributes from the Person class. The Student class also introduces
# an additional attribute, major, and overrides the display method to provide information about the
# major.
#
# Notice how Student.display() calls Person.display() using super() to reuse the base class
# functionality before adding its own details. By overriding, you have the ability to completely
# redefine the method's function in the derived class, which means the base class method will not
# automatically be executed. If you still want the base class's method to be part of the derived
# class's method execution, you have to explicitly call it using super(). This is crucial for
# maintaining the fundamental behavior of the base class while introducing new or extended features
# in the derived class.
