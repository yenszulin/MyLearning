class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def display(self):
        print(f"Name: {self.name}, Age: {self.age}")


class Student(Person):
    def __init__(self, name, age, major):
        super().__init__(name, age)
        self.major = major

    def display(self):
        super().display()
        print(f"Major: {self.major}")


# TODO: Add a new class GraduateStudent that inherits from Student
# TODO: Add a new attribute, thesisTitle, to GraduateStudent
# TODO: Implement the constructor for GraduateStudent to initialize name, age, major, and thesisTitle
# TODO: Override the display method in GraduateStudent to include thesisTitle in the displayed information
class GraduateStudent(Student):
    def __init__(self, name, age, major, thesisTitle):
        super().__init__(name, age, major)
        self.thesisTitle = thesisTitle

    def display(self):
        super().display()
        print(f"Thesis Title: {self.thesisTitle}")


if __name__ == "__main__":
    # TODO: Create an instance of GraduateStudent with name "Alice", age 28, major "Biology", and thesisTitle "The Effect of Sunlight on Plant Growth"
    grad_student = GraduateStudent("Alice", 28, "Biology", "The Effect of Sunlight on Plant Growth")

    # TODO: Call the display method on the instance of GraduateStudent
    grad_student.display()