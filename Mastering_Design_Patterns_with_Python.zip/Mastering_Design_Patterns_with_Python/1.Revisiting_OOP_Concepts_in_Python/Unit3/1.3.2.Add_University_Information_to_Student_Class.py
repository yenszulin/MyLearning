class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def display(self):
        print(f"Name: {self.name}, Age: {self.age}")


class Student(Person):
    def __init__(self, name, age, major, university):
        super().__init__(name, age)
        self.major = major
        # TODO: Modify the constructor to include the university of the student
        # TODO: Add a university member variable `university`
        self.university = university

    def display(self):
        super().display()
        # TODO: Update the display method to show the university
        print(f"Major: {self.major}, Univeristy: {self.university}")


if __name__ == "__main__":
    # TODO: Modify the constructor call to include the university of the student "Stanford University"
    student = Student("Bob", 25, "Computer Science", "Stanford University")
    student.display()