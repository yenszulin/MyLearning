class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def display(self):
        print(f"Name: {self.name}, Age: {self.age}")


class Student(Person):
    def __init__(self, name, age, major, studentID):
        super().__init__(name, age)
        self.major = major
        # TODO: Add an initialization for studentID of type int
        self.studentID = studentID

    def display(self):
        super().display()
        # TODO: Display student ID in addition to name, age, and major
        # TODO: Display everything with a singular print statement
        print(f"Name: {self.name}, Age: {self.age}, Major: {self.major}, Student ID: {self.studentID}")


if __name__ == "__main__":
    # TODO: Modify the constructor call to also pass a studentID of 101
    student = Student("Bob", 25, "Computer Science", 101)
    student.display()