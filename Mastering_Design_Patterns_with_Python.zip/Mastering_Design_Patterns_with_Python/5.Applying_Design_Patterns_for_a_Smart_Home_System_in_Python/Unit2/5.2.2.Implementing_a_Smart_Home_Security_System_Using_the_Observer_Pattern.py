# Now, let's dive into an exciting challenge by fully implementing a smart home security system using the Observer Pattern.
# Your goal is to create a security system (SecuritySystem) that can notify homeowners (HomeOwner) of intrusion detection.
# Focus on defining observer and subject classes, linking them, and demonstrating their interaction

from abc import ABC, abstractmethod


# TODO: Define the abstract Observer class with a method 'update'
# Abstract Observer class
class Observer(ABC):
    @abstractmethod
    def update(self, message):
        pass


# TODO: Define the HomeOwner class that inherits from Observer and implements the update method
# HomeOwner class implementing Observer
class HomeOwner(Observer):
    def __init__(self, name):
        self.name = name

    def update(self, message):
        print(f"{self.name} received alert: {message}")


# TODO: Define the Subject class with attach, detach, and notify methods
# Hint: Remember to keep a list of observers to notify them
# Subject class
class Subject:
    def __init__(self):
        self._observers = []

    def attach(self, observer):
        if observer not in self._observers:
            self._observers.append(observer)

    def detach(self, observer):
        if observer in self._observers:
            self._observers.remove(observer)

    def notify(self, message):
        for observer in self._observers:
            observer.update(message)


# TODO: Define the SecuritySystem class that inherits from Subject and detects an intrusion
# SecuritySystem class implementing Subject
class SecuritySystem(Subject):
    def detect_intrusion(self):
        print("SecuritySystem: Intrusion detected!")
        self.notify("Intrusion detected! Please check your property.")


if __name__ == "__main__":
    # TODO: Implement the main function to create SecuritySystem and HomeOwner instances, and demonstrate the Observer Pattern
    # Create security system
    security = SecuritySystem()

    # Create homeowners
    alice = HomeOwner("Alice")
    bob = HomeOwner("Bob")

    # Attach homeowners to the security system
    security.attach(alice)
    security.attach(bob)

    # Trigger intrusion detection
    security.detect_intrusion()

    # Detach Bob and simulate another event
    security.detach(bob)
    print("\nBob unsubscribed from alerts.\n")
    security.detect_intrusion()