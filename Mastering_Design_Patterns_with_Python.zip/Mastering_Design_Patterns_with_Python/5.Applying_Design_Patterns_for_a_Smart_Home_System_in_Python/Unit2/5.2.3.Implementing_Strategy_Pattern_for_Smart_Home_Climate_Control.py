# Now, let's implement a flexible climate control system using the Strategy Pattern for a smart home.
# Your task is to write a complete Python solution that sets up a Climate Control system for heating and cooling.
# Create an abstract base class to represent different strategies (heating and cooling), and a controller class to
# manage and apply these strategies.

from abc import ABC, abstractmethod


# TODO: Define the abstract base class TemperatureControlStrategy with an abstract method control_temperature
class TemperatureControlStrategy(ABC):
    @abstractmethod
    def control_temperature(self, target_temp):
        pass


# TODO: Create the HeatingStrategy class inheriting from TemperatureControlStrategy
# Heating strategy
class HeatingStrategy(TemperatureControlStrategy):
    def control_temperature(self, target_temp):
        print(f"Heating up to {target_temp}°C.")


# TODO: Create the CoolingStrategy class inheriting from TemperatureControlStrategy
# Cooling strategy
class CoolingStrategy(TemperatureControlStrategy):
    def control_temperature(self, target_temp):
        print(f"Cooling down to {target_temp}°C.")


# TODO: Create the context class ClimateControl
# Context class
class ClimateControl:
    def __init__(self, strategy: TemperatureControlStrategy):
        self._strategy = strategy

    def set_strategy(self, strategy: TemperatureControlStrategy):
        self._strategy = strategy

    def apply_temperature(self, target_temp):
        self._strategy.control_temperature(target_temp)


if __name__ == "__main__":
    # TODO: Create a ClimateControl object with the Heating strategy
    # Create ClimateControl with HeatingStrategy
    climate = ClimateControl(HeatingStrategy())

    # TODO: Use the ClimateControl object to heat to 22 degrees
    # Heat to 22 degrees
    climate.apply_temperature(22)

    # TODO: Switch the strategy to Cooling
    # Switch to CoolingStrategy
    climate.set_strategy(CoolingStrategy())

    # TODO: Use the ClimateControl object to cool to 18 degrees
    # Cool to 18 degrees
    climate.apply_temperature(18)