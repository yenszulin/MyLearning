# Define the Subject class
class Subject:
    def __init__(self):
        self.__observers = []

    def register_observer(self, observer):
        self.__observers.append(observer)

    def unregister_observer(self, observer):
        self.__observers.remove(observer)

    def notify_observers(self):
        for observer in self.__observers:
            observer.update(self)


# Define the SecuritySystem class
class SecuritySystem(Subject):
    def __init__(self):
        super().__init__()
        self.__state = None

    def set_state(self, state):
        self.__state = state
        self.notify_observers()

    def get_state(self):
        return self.__state


# Define the Observer interface
class Observer:
    def update(self, subject):
        pass


# Implement the SecurityApp observer
class SecurityApp(Observer):
    def update(self, subject):
        if isinstance(subject, SecuritySystem):
            print(f"SecurityApp notified. New state: {subject.get_state()}")


# Implement the SecurityLight observer
class SecurityLight(Observer):
    def update(self, subject):
        if isinstance(subject, SecuritySystem):
            print(f"SecurityLight activated! State: {subject.get_state()}")


# Define the TemperatureControlStrategy interface
class TemperatureControlStrategy:
    def control_temperature(self, temperature):
        pass


# Implement the HeatingStrategy
class HeatingStrategy(TemperatureControlStrategy):
    def control_temperature(self, temperature):
        print(f"Heating to {temperature} degrees.")


# Implement the CoolingStrategy
class CoolingStrategy(TemperatureControlStrategy):
    def control_temperature(self, temperature):
        print(f"Cooling to {temperature} degrees.")


# Define the ClimateControl context
class ClimateControl:
    def __init__(self, strategy: TemperatureControlStrategy):
        self.__strategy = strategy

    def set_strategy(self, strategy: TemperatureControlStrategy):
        self.__strategy = strategy

    def control_temperature(self, temperature):
        self.__strategy.control_temperature(temperature)


if __name__ == "__main__":
    # Example usage
    security_system = SecuritySystem()
    app = SecurityApp()
    light = SecurityLight()
    security_system.register_observer(app)
    security_system.register_observer(light)
    security_system.set_state("Intrusion Detected")

    # Expected Output:
    # SecurityApp notified. New state: Intrusion Detected
    # SecurityLight activated! State: Intrusion Detected

    # Example usage
    climate_control = ClimateControl(HeatingStrategy())
    climate_control.control_temperature(22)  # Expected Output: Heating to 22 degrees.

    climate_control.set_strategy(CoolingStrategy())
    climate_control.control_temperature(18)  # Expected Output: Cooling to 18 degrees.