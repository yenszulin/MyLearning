class SmartHomeDevice:
    def __init__(self):
        self.sensors = []
        self.actuators = []
        self.name = ""


class SmartHomeDeviceBuilder:
    def __init__(self):
        self.__device = SmartHomeDevice()

    def add_sensors(self, sensors):
        self.__device.sensors = sensors
        return self

    def add_actuators(self, actuators):
        self.__device.actuators = actuators
        return self

    def set_name(self, name):
        self.__device.name = name
        return self

    def build(self):
        return self.__device


if __name__ == "__main__":
    # Usage
    builder = SmartHomeDeviceBuilder()
    device = (builder
              .set_name('Smart Light')
              .add_sensors(['Light Sensor'])
              .add_actuators(['LED'])
              .build())
    print(device.name)  # Output: Smart Light