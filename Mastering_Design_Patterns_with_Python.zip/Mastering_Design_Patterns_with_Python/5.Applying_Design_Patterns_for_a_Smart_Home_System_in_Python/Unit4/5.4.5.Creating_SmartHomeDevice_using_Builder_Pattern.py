# TODO: Implement the SmartHomeDevice class with sensors and actuators that should only be set using Builders.
# TODO: Initialize sensors and actuators as empty lists.
# === SmartHomeDevice Class ===
class SmartHomeDevice:
    def __init__(self):
        self._sensors = []
        self._actuators = []

    # TODO: Implement the set_sensors method.
    def set_sensors(self, sensors):
        self._sensors = sensors

    # TODO: Implement the set_actuators method.
    def set_actuators(self, actuators):
        self._actuators = actuators

    # TODO: Implement the show_details method to print sensors and actuators.
    def show_details(self):
        print(f"SmartHomeDevice Sensors: {self._sensors}, Actuators: {self._actuators}")


# TODO: Implement the SmartHomeDeviceBuilder class with methods to add sensors and actuators to the device and build it.
# TODO: Initialize SmartHomeDevice instance.
# === SmartHomeDeviceBuilder Class ===
class SmartHomeDeviceBuilder:
    def __init__(self):
        self._device = SmartHomeDevice()
        self._sensors = []
        self._actuators = []

    # TODO: Implement the add_sensors method.
    def add_sensors(self, *sensors):
        self._sensors.extend(sensors)
        return self  # Enable method chaining

    # TODO: Implement the add_actuators method.
    def add_actuators(self, *actuators):
        self._actuators.extend(actuators)
        return self  # Enable method chaining

    # TODO: Implement the build method.
    def build(self):
        self._device.set_sensors(self._sensors)
        self._device.set_actuators(self._actuators)
        return self._device


# === Usage ===
if __name__ == "__main__":
    # TODO: Create a SmartHomeDevice with sensors "Light Sensor", "Temperature Sensor" and actuators "LED", "Heater" using Builder pattern.
    # TODO: Verify that the device has been properly built using the show_details method.
    # Output should be: SmartHomeDevice Sensors: ['Light Sensor', 'Temperature Sensor'], Actuators: ['LED', 'Heater']
    builder = SmartHomeDeviceBuilder()
    device = (builder
              .add_sensors("Light Sensor", "Temperature Sensor")
              .add_actuators("LED", "Heater")
              .build())

    device.show_details()