from abc import ABC, abstractmethod


# TODO: Define the base abstract class for all types of notifications. It should contain an abstract send method.
# === Abstract Base Class ===
class Notification(ABC):
    @abstractmethod
    def send(self):
        pass


# TODO: Implement the class for sending text notifications by subclasses the Notification class and implements the send method
# === Concrete Notification: Text ===
class TextNotification(Notification):
    def __init__(self, message):
        self.message = message

    def send(self):
        print(f"Sending text: {self.message}")


# TODO: Implement the class for sending email notifications by subclasses the Notification class and implements the send method
# === Concrete Notification: Email ===
class EmailNotification(Notification):
    def __init__(self, subject, body):
        self.subject = subject
        self.body = body

    def send(self):
        print(f"Sending email with subject: '{self.subject}' and body: '{self.body}'")


# TODO: Implement a composite class that can contain multiple notifications and manage them.
# === Composite Notification Group ===
class NotificationGroup(Notification):
    def __init__(self):
        self.notifications = []

    def add(self, notification: Notification):
        self.notifications.append(notification)

    def remove(self, notification: Notification):
        self.notifications.remove(notification)

    def send(self):
        for notification in self.notifications:
            notification.send()


if __name__ == "__main__":
    # TODO: Create and test a notification group that includes a text notification and an email notification, then call the send method to send all notifications in the group.
    # Create individual notifications
    text = TextNotification("Your package has been delivered.")
    email = EmailNotification("Delivery Confirmation", "Your order #12345 was delivered today.")

    # Create a notification group and add notifications
    group = NotificationGroup()
    group.add(text)
    group.add(email)

    # Send all notifications
    print("Sending all notifications in the group:")
    group.send()