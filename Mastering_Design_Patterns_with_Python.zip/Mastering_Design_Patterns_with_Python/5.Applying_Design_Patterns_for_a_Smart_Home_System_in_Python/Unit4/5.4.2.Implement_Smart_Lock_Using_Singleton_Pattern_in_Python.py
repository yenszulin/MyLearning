class SmartKeyManager:
    __instance = None

    @staticmethod
    def get_instance():
        # TODO: Implement Singleton pattern here
        if SmartKeyManager.__instance is None:
            SmartKeyManager.__instance = SmartKeyManager()
        return SmartKeyManager.__instance

    def __init__(self):
        if SmartKeyManager.__instance is not None:
            raise Exception("This class is a singleton. Use get_instance() to access it.")
        self._door_locked = True

    # TODO: Add methods like 'unlock_door' and 'lock_door' to simulate unlocking and locking the door.
    def unlock_door(self):
        if not self._door_locked:
            print("Door is already unlocked.")
        else:
            self._door_locked = False
            print("Door is now unlocked.")

    def lock_door(self):
        if self._door_locked:
            print("Door is already locked.")
        else:
            self._door_locked = True
            print("Door is now locked.")


# Usage
if __name__ == "__main__":
    # TODO: Retrieve the singleton instance of SmartKeyManager and use it to call unlocking and locking methods.
    key_manager1 = SmartKeyManager.get_instance()
    key_manager1.unlock_door()

    key_manager2 = SmartKeyManager.get_instance()
    key_manager2.lock_door()

    print(key_manager1 is key_manager2)  # Should output: True

