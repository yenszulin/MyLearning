from abc import ABC, abstractmethod


# TODO: Define an abstract SmartDeviceFactory class with methods create_sensor and create_actuator
# === Abstract Interfaces ===
class Sensor(ABC):
    @abstractmethod
    def read(self):
        pass


class Actuator(ABC):
    @abstractmethod
    def activate(self):
        pass


class SmartDeviceFactory(ABC):
    @abstractmethod
    def create_sensor(self) -> Sensor:
        pass

    @abstractmethod
    def create_actuator(self) -> Actuator:
        pass


# TODO: Define Sensor and Actuator classes, and implement specific sensor and actuator classes like LightSensor, LEDActuator, TemperatureSensor, and MotorActuator
# === Concrete Sensor Classes ===
class LightSensor(Sensor):
    def read(self):
        print("Light Sensor created")


class TemperatureSensor(Sensor):
    def read(self):
        print("Temperature Sensor created")


# === Concrete Actuator Classes ===
class LEDActuator(Actuator):
    def activate(self):
        print("LED Actuator created")


class MotorActuator(Actuator):
    def activate(self):
        print("Motor Actuator created")


# TODO: Implement concrete factory classes like LightFactory and FanFactory that inherit from SmartDeviceFactory
# === Concrete Factory Classes ===
class LightFactory(SmartDeviceFactory):
    def create_sensor(self) -> Sensor:
        sensor = LightSensor()
        sensor.read()
        return sensor

    def create_actuator(self) -> Actuator:
        actuator = LEDActuator()
        actuator.activate()
        return actuator


class FanFactory(SmartDeviceFactory):
    def create_sensor(self) -> Sensor:
        sensor = TemperatureSensor()
        sensor.read()
        return sensor

    def create_actuator(self) -> Actuator:
        actuator = MotorActuator()
        actuator.activate()
        return actuator


if __name__ == "__main__":
    # Usage for LightFactory
    light_factory = LightFactory()
    light_sensor = light_factory.create_sensor()  # Output: Light Sensor created
    light_actuator = light_factory.create_actuator()  # Output: LED Actuator created

    # Usage for FanFactory
    fan_factory = FanFactory()
    fan_sensor = fan_factory.create_sensor()  # Output: Temperature Sensor created
    fan_actuator = fan_factory.create_actuator()  # Output: Motor Actuator created