# In this exercise, you'll implement a smart home system in Python using the Factory Method and Adapter patterns.
# Your goal is to create smart devices (Light and Fan) and make them compatible with a method called plug_into_eu_socket.
# Follow the TODO comments to achieve this task.

# Define the device base class
class Device:
    def operate(self):
        pass


# TODO: Define the Light class inheriting from Device, overriding the operate method
# TODO: Define the Fan class inheriting from Device, overriding the operate method
# Light class inheriting from Device
class Light(Device):
    def operate(self):
        return "Light is operating."


# Fan class inheriting from Device
class Fan(Device):
    def operate(self):
        return "Fan is operating."


# Define the factory class
class DeviceFactory:
    @staticmethod
    def create_device(device_type):
        if device_type == "light":
            return Light()
        elif device_type == "fan":
            return Fan()
        else:
            raise ValueError(f"Unknown device type: {device_type}")


# Define the adapter interface
class EUPlugInterface:
    def plug_into_eu_socket(self):
        pass


# TODO: Define the DeviceAdapter class inheriting from EUPlugInterface
#       - Implement the __init__ method to initialize with a device
#       - Implement the plug_into_eu_socket method to call the device's operate method
# DeviceAdapter implementing the EUPlugInterface
class DeviceAdapter(EUPlugInterface):
    def __init__(self, device):
        self.device = device

    def plug_into_eu_socket(self):
        return self.device.operate()


if __name__ == "__main__":
    # Example usage of factory and adapter
    factory = DeviceFactory()

    # TODO: Create an instance of a light device using the factory
    # TODO: Create an adapter for the light device and print the output
    # Create a light device using the factory
    light = factory.create_device("light")
    light_adapter = DeviceAdapter(light)
    print(light_adapter.plug_into_eu_socket())

    # TODO: Create an instance of a fan device using the factory
    # TODO: Create an adapter for the fan device and print the output
    # Create a fan device using the factory
    fan = factory.create_device("fan")
    fan_adapter = DeviceAdapter(fan)
    print(fan_adapter.plug_into_eu_socket())