# Define the Device base class
class Device:
    def operate(self):
        pass

# Define the specific Light and Fan device classes
class Light(Device):
    def operate(self):
        return "Light is turned on"

class Fan(Device):
    def operate(self):
        return "Fan is spinning"

# DeviceFactory class to generate device instances
class DeviceFactory:
    def create_device(self, device_type):
        if device_type == "light":
            return Light()
        elif device_type == "fan":
            return Fan()
        else:
            raise ValueError("Unknown device type")

# Define the Adapter interface
class USPlugInterface:
    def plug_into_us_socket(self):
        pass

# LightAdapter class to adapt Light to work with USPlugInterface
class LightAdapter(USPlugInterface):
    def __init__(self, light):
        self.light = light

    def plug_into_us_socket(self):
        return self.light.operate()

# FanAdapter class to adapt Fan to work with USPlugInterface
class FanAdapter(USPlugInterface):
    def __init__(self, fan):
        self.fan = fan

    def plug_into_us_socket(self):
        return self.fan.operate()


if __name__ == "__main__":
    # Example of using the factory to create devices
    factory = DeviceFactory()

    device1 = factory.create_device("light")
    print(device1.operate())  # Expected Output: Light is turned on

    device2 = factory.create_device("fan")
    print(device2.operate())  # Expected Output: Fan is spinning

    # Example of using the LightAdapter
    light = Light()
    light_adapter = LightAdapter(light)
    print(light_adapter.plug_into_us_socket())  # Expected Output: Light is turned on


    # Example of using the FanAdapter
    fan = Fan()
    fan_adapter = FanAdapter(fan)
    print(fan_adapter.plug_into_us_socket())  # Expected Output: Fan is spinning