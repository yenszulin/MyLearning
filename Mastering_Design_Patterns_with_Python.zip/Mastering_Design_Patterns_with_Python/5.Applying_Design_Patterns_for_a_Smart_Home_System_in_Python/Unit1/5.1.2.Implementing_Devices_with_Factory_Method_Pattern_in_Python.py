# You'll create an abstract class Device with methods operate_on and operate_off. Define concrete classes
# Light and Fan that inherit from Device. Then, create factory classes LightFactory and FanFactory to
# handle the creation process. Follow the TODO comments for guidance.

from abc import ABC, abstractmethod


# TODO: Define the abstract Device class with abstract methods operate_on and operate_off
class Device(ABC):
    @abstractmethod
    def operate_on(self):
        pass

    @abstractmethod
    def operate_off(self):
        pass


# TODO: Define the Light class inheriting from Device and implement the operate_on and operate_off methods
# Light class
class Light(Device):
    def operate_on(self):
        print("Light is turned ON.")

    def operate_off(self):
        print("Light is turned OFF.")


# TODO: Define the Fan class inheriting from Device and implement the operate_on, operate_off, and set_speed methods
# Fan class
class Fan(Device):
    def __init__(self):
        self.speed = 0

    def operate_on(self):
        print("Fan is turned ON.")

    def operate_off(self):
        print("Fan is turned OFF.")

    def set_speed(self, speed):
        self.speed = speed
        print(f"Fan speed is set to {self.speed}.")


# TODO: Define the abstract DeviceFactory class with an abstract create_device method
# Abstract Factory
class DeviceFactory(ABC):
    @abstractmethod
    def create_device(self):
        pass


# TODO: Define the LightFactory and FanFactory classes inheriting from DeviceFactory and implement the create_device method
# LightFactory class
class LightFactory(DeviceFactory):
    def create_device(self):
        return Light()


# FanFactory class
class FanFactory(DeviceFactory):
    def create_device(self):
        return Fan()


if __name__ == "__main__":
    # TODO: Create an instance of LightFactory and use it to create a Light object
    # TODO: Turn on and off the Light object
    # Create and use a Light via LightFactory
    light_factory = LightFactory()
    light = light_factory.create_device()
    light.operate_on()
    light.operate_off()

    # TODO: Create an instance of FanFactory and use it to create a Fan object
    # TODO: Turn on, set speed, and turn off the Fan object
    # Create and use a Fan via FanFactory
    fan_factory = FanFactory()
    fan = fan_factory.create_device()
    fan.operate_on()
    fan.set_speed(3)
    fan.operate_off()