# Let's bring everything together by creating a smart home automation system using the Command Pattern in Python!
# Start by designing abstract and concrete classes for devices like lights and fans with methods to turn them on and off.
# Then, create a factory pattern for these devices. Next, implement the Command pattern to issue commands to these devices
# using a RemoteControl class. Finally, write a main function to bring it all together in a smart home automation demo.

from abc import ABC, abstractmethod


# TODO: Create an abstract class Device with turn_on and turn_off methods
# Abstract Device class
class Device(ABC):
    @abstractmethod
    def turn_on(self):
        pass

    @abstractmethod
    def turn_off(self):
        pass


# TODO: Create the Light class that inherits from Device and implements the turn_on and turn_off methods
# Concrete Light class
class Light(Device):
    def turn_on(self):
        print("Light is ON")

    def turn_off(self):
        print("Light is OFF")


# TODO: Create the Fan class that inherits from Device and implements the turn_on and turn_off methods
# Concrete Fan class
class Fan(Device):
    def turn_on(self):
        print("Fan is ON")

    def turn_off(self):
        print("Fan is OFF")


# TODO: Create an abstract class DeviceFactory with a create_device method
# Abstract DeviceFactory class
class DeviceFactory(ABC):
    @abstractmethod
    def create_device(self):
        pass


# TODO: Create the LightFactory class that inherits from DeviceFactory and implements the create_device method
# LightFactory class
class LightFactory(DeviceFactory):
    def create_device(self):
        return Light()


# TODO: Create the FanFactory class that inherits from DeviceFactory and implements the create_device method
# FanFactory class
class FanFactory(DeviceFactory):
    def create_device(self):
        return Fan()


# TODO: Create an abstract class Command with an execute method
# Abstract Command class
class Command(ABC):
    @abstractmethod
    def execute(self):
        pass


# TODO: Create the TurnOnCommand class that inherits from Command and implements the execute method
# TurnOnCommand class
class TurnOnCommand(Command):
    def __init__(self, device: Device):
        self.device = device

    def execute(self):
        self.device.turn_on()


# TODO: Create the TurnOffCommand class that inherits from Command and implements the execute method
# TurnOffCommand class
class TurnOffCommand(Command):
    def __init__(self, device: Device):
        self.device = device

    def execute(self):
        self.device.turn_off()


# TODO: Create the RemoteControl class to set a Command and execute it when a button is pressed
# RemoteControl class
class RemoteControl:
    def __init__(self):
        self.command = None

    def set_command(self, command: Command):
        self.command = command

    def press_button(self):
        if self.command:
            self.command.execute()
        else:
            print("No command is set.")


# TODO: Write the main function to create smart home automation using the Command pattern
# Main function
if __name__ == "__main__":
    # Create factories
    light_factory = LightFactory()
    fan_factory = FanFactory()

    # Create devices
    light = light_factory.create_device()
    fan = fan_factory.create_device()

    # Create commands
    light_on_command = TurnOnCommand(light)
    light_off_command = TurnOffCommand(light)

    fan_on_command = TurnOnCommand(fan)
    fan_off_command = TurnOffCommand(fan)

    # Use remote control
    remote = RemoteControl()

    print("---- Remote Control Actions ----")
    remote.set_command(light_on_command)
    remote.press_button()

    remote.set_command(fan_on_command)
    remote.press_button()

    remote.set_command(light_off_command)
    remote.press_button()

    remote.set_command(fan_off_command)
    remote.press_button()