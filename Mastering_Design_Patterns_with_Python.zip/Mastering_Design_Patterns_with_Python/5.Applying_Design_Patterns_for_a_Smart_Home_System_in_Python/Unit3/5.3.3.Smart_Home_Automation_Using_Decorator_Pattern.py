# Welcome to this exciting task on smart home automation using the Decorator Pattern! Your mission is to create
# a system that enhances the functionality of lights in a smart home by adding new features dynamically.
# You'll define a base Light class, implement decorators for additional functionalities, and demonstrate the
# use of these decorators in a main function.

from abc import ABC, abstractmethod


# Abstract Light interface
class Light(ABC):
    @abstractmethod
    def turn_on(self):
        pass


# TODO: Create the Basic Light class
# BasicLight class
class BasicLight(Light):
    def turn_on(self):
        print("Basic Light is ON")


# TODO: Implement the LightDecorator class
# Base LightDecorator class
class LightDecorator(Light):
    def __init__(self, decorated_light: Light):
        self._decorated_light = decorated_light

    def turn_on(self):
        self._decorated_light.turn_on()


# TODO: Implement the ColorChangeDecorator class
# ColorChangeDecorator class
class ColorChangeDecorator(LightDecorator):
    def turn_on(self):
        super().turn_on()
        self.change_color()

    def change_color(self):
        print("Color-changing feature activated: Cycling through colors!")


# TODO: Write the main function to demonstrate the use of decorators
# Main function to demonstrate decorator use
if __name__ == "__main__":
    print("---- Basic Light ----")
    basic_light = BasicLight()
    basic_light.turn_on()

    print("\n---- Decorated Light (Color Change) ----")
    color_light = ColorChangeDecorator(basic_light)
    color_light.turn_on()
