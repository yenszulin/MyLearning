from abc import ABC, abstractmethod

# Define the Command interface
class Command(ABC):
    @abstractmethod
    def execute(self):
        pass

# Concrete command classes for turning the light on and off
class LightOnCommand(Command):
    def __init__(self, light):
        self.light = light

    def execute(self):
        self.light.turn_on()

class LightOffCommand(Command):
    def __init__(self, light):
        self.light = light

    def execute(self):
        self.light.turn_off()

# Receiver class encapsulating the light functionalities
class Light:
    def turn_on(self):
        print("The light is on")

    def turn_off(self):
        print("The light is off")

# Invoker class to store and execute commands
class RemoteControl:
    def __init__(self):
        self.slots = {}

    def set_command(self, command_name, command):
        self.slots[command_name] = command

    def press_button(self, command_name):
        if command_name in self.slots:
            self.slots[command_name].execute()
        else:
            print(f"No command found for {command_name}")

# Example of setting up and using the command pattern
if __name__ == "__main__":
    living_room_light = Light()

    light_on_command = LightOnCommand(living_room_light)
    light_off_command = LightOffCommand(living_room_light)

    remote_control = RemoteControl()

    remote_control.set_command("light_on", light_on_command)
    remote_control.set_command("light_off", light_off_command)

    remote_control.press_button("light_on")  # Expected Output: The light is on
    remote_control.press_button("light_off") # Expected Output: The light is off