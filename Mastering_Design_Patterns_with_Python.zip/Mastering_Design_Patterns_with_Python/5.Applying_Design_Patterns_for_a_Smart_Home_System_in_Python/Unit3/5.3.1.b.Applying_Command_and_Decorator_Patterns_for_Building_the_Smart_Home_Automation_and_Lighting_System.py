# Basic Light class
class Light:
    def operate(self):
        return "Basic light operation"

# Base Decorator class
class LightDecorator(Light):
    def __init__(self, decorated_light):
        self.decorated_light = decorated_light

    def operate(self):
        return self.decorated_light.operate()

# Concrete Decorator for adding color-changing functionality
class ColorChangeDecorator(LightDecorator):
    def operate(self):
        return f"{super().operate()} with color change"

# Example of using the decorator pattern
if __name__ == "__main__":
    basic_light = Light()
    print(basic_light.operate())  # Expected Output: Basic light operation

    color_light = ColorChangeDecorator(basic_light)
    print(color_light.operate())  # Expected Output: Basic light operation with color change