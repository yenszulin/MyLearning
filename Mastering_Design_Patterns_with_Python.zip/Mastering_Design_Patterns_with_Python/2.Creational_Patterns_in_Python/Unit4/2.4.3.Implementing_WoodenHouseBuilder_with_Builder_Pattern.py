from abc import ABC, abstractmethod


class House:
    def __init__(self):
        self.foundation = None
        self.structure = None
        self.roof = None

    def set_foundation(self, foundation):
        self.foundation = foundation

    def set_structure(self, structure):
        self.structure = structure

    def set_roof(self, roof):
        self.roof = roof

    def show_house(self):
        print(f"House with {self.foundation}, {self.structure}, and {self.roof}.")


class HouseBuilder(ABC):
    @abstractmethod
    def build_foundation(self):
        pass

    @abstractmethod
    def build_structure(self):
        pass

    @abstractmethod
    def build_roof(self):
        pass

    @abstractmethod
    def get_house(self):
        pass


# TODO: Implement the complete WoodenHouseBuilder class that extends HouseBuilder
class WoodenHouseBuilder(HouseBuilder):
    def __init__(self):
        self.house = House()

    # TODO: Implement the build_foundation method to set the foundation of the house to "Wooden Foundation"
    def build_foundation(self):
        self.house.set_foundation("Wooden Foundation")

    # TODO: Implement the build_structure method to set the structure of the house to "Wooden Structure"
    def build_structure(self):
        self.house.set_structure("Wooden Structure")

    def build_roof(self):
        self.house.set_roof("Wooden Roof")

    # TODO: Implement the get_house method to return the house object
    def get_house(self):
        return self.house


class Director:
    def __init__(self):
        self.builder = None

    def set_builder(self, builder):
        self.builder = builder

    def construct_house(self):
        self.builder.build_foundation()
        self.builder.build_structure()
        self.builder.build_roof()
        return self.builder.get_house()


if __name__ == "__main__":
    director = Director()
    builder = WoodenHouseBuilder()  # TODO: Replace with an instance of WoodenHouseBuilder after implementation
    director.set_builder(builder)

    house = director.construct_house()
    house.show_house()