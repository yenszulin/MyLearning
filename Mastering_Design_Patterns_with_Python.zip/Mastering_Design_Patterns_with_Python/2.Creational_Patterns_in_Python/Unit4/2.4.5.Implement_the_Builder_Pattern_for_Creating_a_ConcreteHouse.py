from abc import ABC, abstractmethod

# TODO: Define the House class with the following methods
#       - set_foundation, set_structure, set_roof for setting types of the foundation, structure, and roof
#       - show_house to display the house attributes in the format "House with <foundation>, <structure>, and <roof>."
# === Product ===
class House:
    def __init__(self):
        self.foundation = None
        self.structure = None
        self.roof = None

    def set_foundation(self, foundation):
        self.foundation = foundation

    def set_structure(self, structure):
        self.structure = structure

    def set_roof(self, roof):
        self.roof = roof

    def show_house(self):
        print(f"House with {self.foundation}, {self.structure}, and {self.roof}.")

# TODO: Define the abstract HouseBuilder class with build_foundation, build_structure, build_roof, and get_house methods
# === Abstract Builder ===
class HouseBuilder(ABC):
    @abstractmethod
    def build_foundation(self):
        pass

    @abstractmethod
    def build_structure(self):
        pass

    @abstractmethod
    def build_roof(self):
        pass

    @abstractmethod
    def get_house(self):
        pass

# === Concrete Builder ===
# TODO: Implement the ConcreteHouseBuilder class derived from HouseBuilder to construct a house with a concrete foundation, structure, and roof
#       The methods should set the foundation, structure, and roof attributes of the house with "Concrete Foundation", "Concrete Structure", and "Concrete Roof"
class ConcreteHouseBuilder(HouseBuilder):
    def __init__(self):
        self.house = House()

    def build_foundation(self):
        self.house.set_foundation("Concrete Foundation")

    def build_structure(self):
        self.house.set_structure("Concrete Structure")

    def build_roof(self):
        self.house.set_roof("Concrete Roof")

    def get_house(self):
        return self.house

# === Director ===
# TODO: Implement the Director class that will use HouseBuilder to construct a house
#       It should have a set_builder method to set the builder and a construct_house method to build the house and return it
class Director:
    def __init__(self):
        self.builder = None

    def set_builder(self, builder: HouseBuilder):
        self.builder = builder

    def construct_house(self):
        self.builder.build_foundation()
        self.builder.build_structure()
        self.builder.build_roof()
        return self.builder.get_house()


# === Main Code ===
if __name__ == "__main__":
    director = Director()
    builder = ConcreteHouseBuilder()
    director.set_builder(builder)

    house = director.construct_house()
    house.show_house()