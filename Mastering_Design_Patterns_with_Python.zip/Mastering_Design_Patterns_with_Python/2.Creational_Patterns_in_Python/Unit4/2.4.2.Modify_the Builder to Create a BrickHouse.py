from abc import ABC, abstractmethod

class House:
    def __init__(self):
        self.foundation = None
        self.structure = None
        self.roof = None

    def set_foundation(self, foundation):
        self.foundation = foundation

    def set_structure(self, structure):
        self.structure = structure

    def set_roof(self, roof):
        self.roof = roof

    def show_house(self):
        print(f"House with {self.foundation}, {self.structure}, and {self.roof}.")

class HouseBuilder(ABC):
    @abstractmethod
    def build_foundation(self):
        pass

    @abstractmethod
    def build_structure(self):
        pass

    @abstractmethod
    def build_roof(self):
        pass

    @abstractmethod
    def get_house(self):
        pass

# TODO: Modify this class to BrickHouseBuilder to build a Brick House
class BrickHouseBuilder(HouseBuilder):
    def __init__(self):
        self.house = House()

    def build_foundation(self):
        # TODO: Modify this method to set the foundation to "Brick Foundation"
        self.house.set_foundation("Brick Foundation")

    def build_structure(self):
        # TODO: Modify this method to set the structure to "Brick Structure"
        self.house.set_structure("Brick Structure")

    def build_roof(self):
        # TODO: Modify this method to set the roof to "Brick Roof"
        self.house.set_roof("Brick Roof")

    def get_house(self):
        return self.house

class Director:
    def __init__(self):
        self.builder = None

    def set_builder(self, builder):
        self.builder = builder

    def construct_house(self):
        self.builder.build_foundation()
        self.builder.build_structure()
        self.builder.build_roof()
        return self.builder.get_house()

# Example usage
if __name__ == "__main__":
    director = Director()
    # TODO: Change this to BrickHouseBuilder
    builder = BrickHouseBuilder()
    director.set_builder(builder)

    house = director.construct_house()
    house.show_house()