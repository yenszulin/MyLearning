from abc import ABC, abstractmethod

# TODO: Implement the Robot class
#       Add methods to set material, type, and power source, and to show the robot's details.
# === Product ===
class Robot:
    def __init__(self):
        self.material = None
        self.type = None
        self.power_source = None

    def set_material(self, material):
        self.material = material

    def set_type(self, robot_type):
        self.robot_type = robot_type

    def set_power_source(self, power_source):
        self.power_source = power_source

    def show_robot(self):
        print("Robot Details:")
        print(f"  Material: {self.material}")
        print(f"  Type: {self.robot_type}")
        print(f"  Power Source: {self.power_source}")

# === Abstract Builder ===
class RobotBuilder(ABC):
    @abstractmethod
    def build_material(self):
        pass

    @abstractmethod
    def build_type(self):
        pass

    @abstractmethod
    def build_power_source(self):
        pass

    @abstractmethod
    def get_robot(self):
        pass


# TODO: Implement the SteelRobotBuilder class
#       Add a constructor to initialize the robot object, and implement the build methods to set
#       the material to "Steel", type to "Warrior", and power source to "Nuclear".
#       Add a method to return the robot object.
# === Concrete Builder ===
class SteelRobotBuilder(RobotBuilder):
    def __init__(self):
        self.robot = Robot()

    def build_material(self):
        self.robot.set_material("Steel")

    def build_type(self):
        self.robot.set_type("Warrior")

    def build_power_source(self):
        self.robot.set_power_source("Nuclear")

    def get_robot(self):
        return self.robot

# === Director ===
class RobotDirector:
    def __init__(self):
        self.builder = None

    def set_builder(self, builder):
        self.builder = builder

    def construct_robot(self):
        self.builder.build_material()
        self.builder.build_type()
        self.builder.build_power_source()
        return self.builder.get_robot()

# === Client Code ===
if __name__ == "__main__":
    director = RobotDirector()
    builder = SteelRobotBuilder()
    director.set_builder(builder)

    robot = director.construct_robot()
    robot.show_robot()