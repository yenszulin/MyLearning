from abc import ABC, abstractmethod


# TODO: Define the Robot class with the following methods
#       - set_head, set_body, set_legs for setting types of the head, body, and legs
#       - show_robot to display the robot attributes in the format "Robot with <head>, <body>, and <legs>.
#
## Product ##
class Robot:
    def __init__(self):
        self.head = None
        self.body = None
        self.legs = None

    def set_head(self, head):
        self.head = head

    def set_body(self, body):
        self.body = body

    def set_legs(self, legs):
        self.legs = legs

    def show_robot(self):
        print(f"Robot with {self.head}, {self.body}, {self.legs}")


# TODO: Define the abstract RobotBuilder class with build_head, build_body, build_legs, and get_robot methods
## abstract builder ##
class Robortbuilder(ABC):
    @abstractmethod
    def build_head(self):
        pass

    @abstractmethod
    def build_body(self):
        pass

    @abstractmethod
    def build_legs(self):
        pass

    @abstractmethod
    def get_robot(self):
        pass


# TODO: Implement the MetalRobotBuilder class derived from RobotBuilder to construct a robot
#       The methods should set the head, body, and legs attributes of the robot with "Metallic Head", "Metallic Body", and "Metallic Legs"
## Concrete Builder ##
class MetalRobotBuilder(Robortbuilder):
    def __init__(self):
        self.robot = Robot()

    def build_head(self):
        self.robot.set_head("Metallic Head")

    def build_body(self):
        self.robot.set_body("Metallic Body")

    def build_legs(self):
        self.robot.set_legs("Metallic Legs")

    def get_robot(self):
        return self.robot


# TODO: Implement the Computer class that will use RobotBuilder to construct a robot
#       It should have a set_builder method to set the builder and a construct_robot method to build the robot and return it

## Director ##
class Computer:
    def __init__(self):
        self.builder = None

    def set_builder(self, builder: Robortbuilder):
        self.builder = builder

    def construct_robot(self):
        self.builder.build_head()
        self.builder.build_body()
        self.builder.build_legs()
        return self.builder.get_robot()


# TODO: Write the main section to:
#       - Create an instance of Computer
#       - Create an instance of MetalRobotBuilder
#       - Set the builder in the computer
#       - Use the computer to construct the robot
#       - Display the robot's attributes using show_robot

if __name__ == "__main__":
    # Your code starts here
    computer = Computer()
    builder = MetalRobotBuilder()
    computer.set_builder(builder)
    robot = computer.construct_robot()
    robot.show_robot()