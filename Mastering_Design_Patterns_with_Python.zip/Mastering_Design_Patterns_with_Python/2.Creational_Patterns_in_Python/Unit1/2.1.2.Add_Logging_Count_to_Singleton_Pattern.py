class Logger:
    __instance = None
    # TODO: Add a counter to keep track of log messages
    __log_count = 0  # Counter to keep track of log messages

    @staticmethod
    def getInstance():
        if Logger.__instance is None:
            Logger.__instance = Logger()
        return Logger.__instance

    def log(self, message):
        # TODO: In addition to the message, print the log count in the format: "{message} (Log count: {count})"
        Logger.__log_count += 1
        print(f"{message} (Log count: {Logger.__log_count})")


if __name__ == "__main__":
    logger = Logger.getInstance()
    logger.log("First log message.")
    another_logger = Logger.getInstance()
    another_logger.log("Second log message.")


# In C++, the concept most similar to Python's @staticmethod is a static member function of a class.
#
# ✅ In Python:
#
# class MyClass:
#     @staticmethod
#     def greet():
#         print("Hello from static method")
# Can be called without an instance: MyClass.greet()
#
# Cannot access self or cls (i.e., no instance or class context).
#
# ✅ Equivalent in C++:
#
# #include <iostream>
# class MyClass {
# public:
#     static void greet() {
#         std::cout << "Hello from static method" << std::endl;
#     }
# };
#
# int main() {
#     MyClass::greet();  // Call without creating an object
#     return 0;
# }
# Marked with static keyword inside the class.
#
# Called using the class name (like MyClass::greet()).
#
# Cannot access non-static member variables or functions.
#
# 🔁 Comparison Summary:
# Feature	Python (@staticmethod)	C++ (static method)
# Called via class	    ✅ MyClass.method()	    ✅ MyClass::method()
# No self / instance	✅	                    ✅
# Access to instance	❌	                    ❌
# Access to class vars	❌ (use @classmethod)	❌ (use static or pass manually)

