# TODO: Define the Logger class - ensure it adheres to the Singleton Pattern
class Logger:
    __instance = None  # Class-level variable to hold the singleton instance

    @staticmethod
    # TODO: Implement the getInstance method to control the instantiation of the class
    def getInstance():
        if Logger.__instance is None:
            Logger.__instance = Logger()
        return Logger.__instance

    # TODO: Implement the log method to take a message and print it
    def Log(self, message):
        print(f"Message: {message}")


if __name__ == "__main__":
    # TODO: Create an instance of Logger using getInstance and call the log method with the message "Server started"
    logger = Logger.getInstance()
    logger.Log("Server started")