class Logger:
    __instance = None

    @staticmethod
    def getInstance():
        if Logger.__instance is None:
            Logger.__instance = Logger()
        return Logger.__instance

    # TODO: Modify the log method to accept second parameter 'level' for severity level
    def log(self, message, level):
        # TODO: Prefix the message with the severity level "<level>: <message>"
        print(f"{level} : {message}")

if __name__ == "__main__":
    # TODO: Update the log calls to include the severity level as the second parameter "INFO", "WARNING", and "ERROR"
    logger = Logger.getInstance()
    logger.log("Singleton pattern example with Logger.", "INFO")
    logger.log("This is a warning message.", "WARNING")
    logger.log("This is an error message.", "ERROR")