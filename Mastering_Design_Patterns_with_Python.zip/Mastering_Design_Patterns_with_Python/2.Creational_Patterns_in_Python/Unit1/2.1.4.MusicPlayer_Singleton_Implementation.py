class MusicPlayer:
    __instance = None

    @staticmethod
    def getInstance():
        # TODO: Implement the getInstance method to return the instance of the MusicPlayer
        if MusicPlayer.__instance is None:
            MusicPlayer.__instance = MusicPlayer()
        return MusicPlayer.__instance

    def play(self, song):
        # TODO: Implement the play method that takes a song name and prints "Playing: <song>"
        print(f"Playing: {song}")

# Testing the Singleton pattern
if __name__ == "__main__":
    MusicPlayer.getInstance().play("Song1.mp3")