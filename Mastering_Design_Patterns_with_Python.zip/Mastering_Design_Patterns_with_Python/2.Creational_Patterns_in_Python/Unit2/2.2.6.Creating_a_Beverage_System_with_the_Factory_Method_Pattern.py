from abc import ABC, abstractmethod


# TODO: Create an abstract product class named Beverage with an abstract method 'drink'.
class Beverage(ABC):
    @abstractmethod
    def drink(self):
        pass


# TODO: Create a class named Coffee that inherits from Beverage and implements the 'drink' method.
class Coffee(Beverage):
    def drink(self):
        print("Drinking Coffee.")


# TODO: Create a class named Tea that inherits from Beverage and implements the 'drink' method.
class Tea(Beverage):
    def drink(self):
        print("Drinking Tea.")


# TODO: Create a class named Juice that inherits from Beverage and implements the 'drink' method.
class Juice(Beverage):
    def drink(self):
        print("Drinking juice.")


# TODO: Create an abstract creator class named BeverageCreator with an abstract method 'create_beverage'.
class BeverageCreator(ABC):
    @abstractmethod
    def create_beverage(self):
        pass


# TODO: Create a class named CoffeeCreator that inherits from BeverageCreator and implements the 'create_beverage' method.
class CoffeeCreator(BeverageCreator):
    def create_beverage(self):
        return Coffee()


# TODO: Create a class named TeaCreator that inherits from BeverageCreator and implements the 'create_beverage' method.
class TeaCreator(BeverageCreator):
    def create_beverage(self):
        return Tea()


# TODO: Create a class named JuiceCreator that inherits from BeverageCreator and implements the 'create_beverage' method.
class JuiceCreator(BeverageCreator):
    def create_beverage(self):
        return Juice()


if __name__ == "__main__":
    # TODO: Instantiate CoffeeCreator, use it to create a Coffee object, and call the 'drink' method.
    # TODO: Instantiate TeaCreator, use it to create a Tea object, and call the 'drink' method.
    # TODO: Instantiate JuiceCreator, use it to create a Juice object, and call the 'drink' method.
    coffee_creator = CoffeeCreator()
    tea_creator = TeaCreator()
    juice_creator = JuiceCreator()

    coffee = coffee_creator.create_beverage()
    coffee.drink()  # Output: Drinking coffee.

    tea = tea_creator.create_beverage()
    tea.drink()  # Output: Drinking tea.

    juice = juice_creator.create_beverage()
    juice.drink()  # Output: Drinking juice.