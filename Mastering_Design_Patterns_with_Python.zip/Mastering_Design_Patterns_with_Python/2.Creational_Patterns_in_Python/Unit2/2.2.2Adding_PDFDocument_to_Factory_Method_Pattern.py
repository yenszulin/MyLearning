from abc import ABC, abstractmethod


class Document(ABC):
    @abstractmethod
    def open(self):
        pass


class WordDocument(Document):
    def open(self):
        print("Opening Word document.")


class ExcelDocument(Document):
    def open(self):
        print("Opening Excel document.")


# TODO: Add the new PDFDocument class here with `open` method, that says "Opening PDF document."
class PdfDocument(Document):
    def open(self):
        print("Opening PDF document.")


class DocumentCreator(ABC):
    @abstractmethod
    def create_document(self):
        pass


class WordDocumentCreator(DocumentCreator):
    def create_document(self):
        return WordDocument()


class ExcelDocumentCreator(DocumentCreator):
    def create_document(self):
        return ExcelDocument()


# TODO: Add the new PDFDocumentCreator class here with `create_document` method, that returns a new PDFDocument.
class PdfDocumentCreator(DocumentCreator):
    def create_document(self):
        return PdfDocument()


if __name__ == "__main__":
    creator = WordDocumentCreator()
    doc = creator.create_document()
    doc.open()

    creator = ExcelDocumentCreator()
    doc = creator.create_document()
    doc.open()

    # TODO: Create PDFDocument and PDFDocumentCreator classes, and use them to open a PDF document.
    creator = PdfDocumentCreator()
    doc = creator.create_document()
    doc.open()