from abc import ABC, abstractmethod


class Car(ABC):
    @abstractmethod
    def drive(self):
        pass


class Sedan(Car):
    def drive(self):
        print("Driving a sedan.")


class SUV(Car):
    def drive(self):
        print("Driving an SUV.")


class CarFactory(ABC):
    @abstractmethod
    def create_car(self):
        pass


class SedanFactory(CarFactory):
    def create_car(self):
        return Sedan()


class SUVFactory(CarFactory):
    def create_car(self):
        return SUV()


# TODO: Implement the function create_and_drive_cars(factory) to create a car using the provided factory and call its 'drive' method.
def create_and_drive_cars(factory: CarFactory):
    car = factory.create_car()
    car.drive()


# TODO: Write the main code to use the above factory classes and the create_and_drive_cars function to create and drive both types of cars.
if __name__ == "__main__":
    sedan_factory = SedanFactory()
    suv_factory = SUVFactory()

    create_and_drive_cars(sedan_factory)  # Output: Driving a sedan.
    create_and_drive_cars(suv_factory)  # Output: Driving an SUV.