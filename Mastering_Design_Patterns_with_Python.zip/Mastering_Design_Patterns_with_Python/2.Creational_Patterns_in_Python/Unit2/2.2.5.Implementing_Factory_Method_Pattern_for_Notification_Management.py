from abc import ABC, abstractmethod

# Abstract Product
# TODO: Create an abstract base class named Notification with an abstract method named 'send'.
class Notification(ABC):
    @abstractmethod
    def send(self):
        pass

# Concrete Products
# TODO: Create a class named EmailNotification that inherits from Notification and implements the 'send' method to output "Sending Email notification."
class EmailNotification(Notification):
    def send(self):
        print("Sending Email notification.")


# TODO: Create a class named SMSNotification that inherits from Notification and implements the 'send' method to output "Sending SMS notification."
class SMSNotification(Notification):
    def send(self):
        print("Sending SMS notification.")

# Abstract Creator
# TODO: Create an abstract base class named NotificationCreator with an abstract method named 'create_notification'.
class NotificationCreator(ABC):
    @abstractmethod
    def create_notification(self):
        pass

# Concrete Creators
class EmailNotificationCreator(NotificationCreator):
    def create_notification(self):
        return EmailNotification()


class SMSNotificationCreator(NotificationCreator):
    def create_notification(self):
        return SMSNotification()

# Main Code
# TODO: Write the main code to use the above creator classes to create both types of notifications and call their 'send' methods.
def main():
    creators = [EmailNotificationCreator(), SMSNotificationCreator()]

    for creator in creators:
        notification = creator.create_notification()
        notification.send()


if __name__ == "__main__":
    main()
