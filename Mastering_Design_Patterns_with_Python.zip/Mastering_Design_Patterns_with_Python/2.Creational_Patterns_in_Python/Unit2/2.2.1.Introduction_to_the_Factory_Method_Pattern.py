from abc import ABC, abstractmethod

## Abstract Product ##
class Document(ABC):
    @abstractmethod
    def open(self):
        pass

## Concrete Products ##
class WordDocument(Document):
    def open(self):
        print("Opening Word document.")

## Concrete Products ##
class ExcelDocument(Document):
    def open(self):
        print("Opening Excel document.")

## Abstract Creator ##
class DocumentCreator(ABC):
    @abstractmethod
    def create_document(self):
        pass

## Concrete Creators ##
class WordDocumentCreator(DocumentCreator):
    def create_document(self):
        return WordDocument()

## Concrete Creators ##
class ExcelDocumentCreator(DocumentCreator):
    def create_document(self):
        return ExcelDocument()

if __name__ == "__main__":
    creator = WordDocumentCreator()
    doc = creator.create_document()
    doc.open()
    # Output: Opening Word document.

    creator = ExcelDocumentCreator()
    doc = creator.create_document()
    doc.open()
    # Output: Opening Excel document.

    # Flexibility and Extensibility
    # One of the key advantages of the Factory Method Pattern is its flexibility and extensibility. For instance, adding
    # a new type of document, such as a PdfDocument, does not require changes to the existing DocumentCreator or Document
    # classes. Instead, you can create a new subclass of Document and a corresponding subclass of DocumentCreator.
    #
    # Python
    #
    # class PdfDocument(Document):
    #     def open(self):
    #         print("Opening PDF document.")
    #
    # class PdfDocumentCreator(DocumentCreator):
    #     def create_document(self):
    #         return PdfDocument()