from abc import ABC, abstractmethod


# Abstract Product
class Transport(ABC):
    @abstractmethod
    def drive(self):
        pass

# Concrete Products
# TODO: Add Car
class Car(Transport):
    def drive(self):
        print("Driving a car.")


# TODO: Add Bike
class Bike(Transport):
    def drive(self):
        print("Riding a bike.")


# Creator
class TransportFactory(ABC):
    @abstractmethod
    def create_vehicle(self):
        pass

# Concrete Creators
# TODO: Add CarFactory
class CarFactory(TransportFactory):
    def create_vehicle(self):
        return Car()


# TODO: Add BikeFactory
class BikeFactory(TransportFactory):
    def create_vehicle(self):
        return Bike()


# Client Code
def main():
    # TODO: Add instances of the CarFactory and BikeFactory classes
    factories = [CarFactory(), BikeFactory()]

    for factory in factories:
        vehicle = factory.create_vehicle()
        print(vehicle.drive())


if __name__ == "__main__":
    main()