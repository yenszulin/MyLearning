from abc import ABC, abstractmethod


# TODO: Implement Singleton Pattern for 'Logger' in Bank System
# Singleton Pattern for Logger
class Logger:
    __instance = None

    @staticmethod
    def getInstance():
        if Logger.__instance is None:
            Logger.__instance = Logger()
        return Logger.__instance

    def log(self, message):
        print(f"LOG: {message}")


# TODO: Define abstract Account and DebitCard classes using ABC and abstractmethod
# Abstract Product A - Account
class Account(ABC):
    @abstractmethod
    def account_type(self):
        pass


# Abstract Product B - DebitCard
class DebitCard(ABC):
    @abstractmethod
    def card_type(self):
        pass


# TODO: Define SavingsAccount class derived from Account with an overridden account_type method
# Concrete Products for Savings
class SavingsAccount(Account):
    def account_type(self):
        return "Savings Account"


# TODO: Define CurrentAccount class derived from Account with an overridden account_type method
# Concrete Products for Current
class CurrentAccount(Account):
    def account_type(self):
        return "Current Account"


# TODO: Define SavingsDebitCard class derived from DebitCard with an overridden card_type method
class SavingsDebitCard(DebitCard):
    def card_type(self):
        return "Savings Debit Card"


# TODO: Define CurrentDebitCard class derived from DebitCard with an overridden card_type method
class CurrentDebitCard(DebitCard):
    def card_type(self):
        return "Current Debit Card"


# TODO: Define abstract AccountFactory class with create_account and create_debit_card methods
# Abstract Factory
class AccountFactory(ABC):
    @abstractmethod
    def create_account(self):
        pass

    @abstractmethod
    def create_debit_card(self):
        pass


# TODO: Define SavingsAccountFactory class derived from AccountFactory with the required methods
# Concrete Factory for Savings
class SavingsAccountFactory(AccountFactory):
    def create_account(self):
        return SavingsAccount()

    def create_debit_card(self):
        return SavingsDebitCard()


# TODO: Define CurrentAccountFactory class derived from AccountFactory with the required methods
# Concrete Factory for Current
class CurrentAccountFactory(AccountFactory):
    def create_account(self):
        return CurrentAccount()

    def create_debit_card(self):
        return CurrentDebitCard()


# Client Code
if __name__ == "__main__":
    savings_factory = SavingsAccountFactory()
    savings_account = savings_factory.create_account()
    savings_debit_card = savings_factory.create_debit_card()
    Logger.getInstance().log(savings_account.account_type())
    Logger.getInstance().log(savings_debit_card.card_type())

    current_factory = CurrentAccountFactory()
    current_account = current_factory.create_account()
    current_debit_card = current_factory.create_debit_card()
    Logger.getInstance().log(current_account.account_type())
    Logger.getInstance().log(current_debit_card.card_type())