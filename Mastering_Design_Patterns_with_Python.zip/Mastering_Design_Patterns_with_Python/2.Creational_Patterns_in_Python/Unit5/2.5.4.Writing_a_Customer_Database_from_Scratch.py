from abc import ABC, abstractmethod


# TODO: Implement a singleton Logger class with log method
# TODO: Implement getInstance to ensure a single instance
# TODO: Implement log method
# Singleton Logger
class Logger:
    __instance = None

    @staticmethod
    def getInstance():
        if Logger.__instance is None:
            Logger.__instance = Logger()
        return Logger.__instance

    def log(self, message):
        print(f"LOG: {message}")


# TODO: Define abstract Customer class with a show_info method
# TODO: Define show_info method
# Abstract Customer class
class Customer(ABC):
    @abstractmethod
    def show_info(self):
        pass


# TODO: Define PremiumCustomer class derived from Customer
# TODO: Create __init__ method with name, id, and email fields
# TODO: Create set_name, set_id, and set_email methods
# TODO: Log message when show_info is called "Premium Customer: name with ID: id and Email: email"
# PremiumCustomer class
class PremiumCustomer(Customer):
    def __init__(self):
        self.name = None
        self.id = None
        self.email = None

    def set_name(self, name):
        self.name = name

    def set_id(self, id):
        self.id = id

    def set_email(self, email):
        self.email = email

    def show_info(self):
        message = f"Premium Customer: {self.name} with ID: {self.id} and Email: {self.email}"
        Logger.getInstance().log(message)


# TODO: Define RegularCustomer class derived from Customer
# TODO: Create __init__ method with name, id, and email fields
# TODO: Create set_name, set_id, and set_email methods
# TODO: Log message when show_info is called "Regular Customer: name with ID: id and Email: email"
# RegularCustomer class
class RegularCustomer(Customer):
    def __init__(self):
        self.name = None
        self.id = None
        self.email = None

    def set_name(self, name):
        self.name = name

    def set_id(self, id):
        self.id = id

    def set_email(self, email):
        self.email = email

    def show_info(self):
        message = f"Regular Customer: {self.name} with ID: {self.id} and Email: {self.email}"
        Logger.getInstance().log(message)


# TODO: Define CustomerBuilder with build_name, build_id, build_email, and get_customer methods
# TODO: Define build_name method
# TODO: Define build_id method
# TODO: Define build_email method
# TODO: Define get_customer method
# Abstract CustomerBuilder
class CustomerBuilder(ABC):
    @abstractmethod
    def build_name(self, name): pass

    @abstractmethod
    def build_id(self, id): pass

    @abstractmethod
    def build_email(self, email): pass

    @abstractmethod
    def get_customer(self): pass


# TODO: Define PremiumCustomerBuilder derived from CustomerBuilder
# TODO: Implement build_name, build_id, build_email, and get_customer methods
# PremiumCustomerBuilder
class PremiumCustomerBuilder(CustomerBuilder):
    def __init__(self):
        self.customer = PremiumCustomer()

    def build_name(self, name):
        self.customer.set_name(name)

    def build_id(self, id):
        self.customer.set_id(id)

    def build_email(self, email):
        self.customer.set_email(email)

    def get_customer(self):
        return self.customer


# TODO: Define RegularCustomerBuilder derived from CustomerBuilder
# TODO: Implement build_name, build_id, build_email, and get_customer methods
# RegularCustomerBuilder
class RegularCustomerBuilder(CustomerBuilder):
    def __init__(self):
        self.customer = RegularCustomer()

    def build_name(self, name):
        self.customer.set_name(name)

    def build_id(self, id):
        self.customer.set_id(id)

    def build_email(self, email):
        self.customer.set_email(email)

    def get_customer(self):
        return self.customer


# TODO: Define CustomerDirector with set_builder and construct_customer methods
# TODO: Implement set_builder method
# TODO: Implement construct_customer method
# Director
class CustomerDirector:
    def __init__(self):
        self.builder = None

    def set_builder(self, builder: CustomerBuilder):
        self.builder = builder

    def construct_customer(self, name, id, email):
        self.builder.build_name(name)
        self.builder.build_id(id)
        self.builder.build_email(email)
        return self.builder.get_customer()


# Main section
if __name__ == "__main__":
    director = CustomerDirector()

    # Build Premium Customer
    premium_builder = PremiumCustomerBuilder()
    director.set_builder(premium_builder)
    premium_customer = director.construct_customer("John Doe", 123, "john.doe@example.com")
    premium_customer.show_info()

    # Build Regular Customer
    regular_builder = RegularCustomerBuilder()
    director.set_builder(regular_builder)
    regular_customer = director.construct_customer("Jane Doe", 456, "jane.doe@example.com")
    regular_customer.show_info()