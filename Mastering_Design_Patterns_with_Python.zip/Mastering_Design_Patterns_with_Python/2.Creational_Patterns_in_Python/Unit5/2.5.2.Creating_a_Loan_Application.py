from abc import ABC, abstractmethod


# Singleton Pattern for Logger in Bank System
class Logger:
    __instance = None

    @staticmethod
    def getInstance():
        if Logger.__instance is None:
            Logger.__instance = Logger()
        return Logger.__instance

    # TODO: Implement log method
    def log(self, message):
        print(f"Log: {message}")


# Abstract Loan class with a display method
class Loan(ABC):
    @abstractmethod
    def display(self):
        pass


# TODO: Define HomeLoan class derived from Loan with an overridden display method
# Log message: "Home Loan created."
class HomeLoan(Loan):
    def display(self):
        Logger.getInstance().log("Home Loan created.")
        print("Displaying Home Loan details.")


# TODO: Define CarLoan class derived from Loan with an overridden display method
# Log message: "Car Loan created."
class CarLoan(Loan):
    def display(self):
        Logger.getInstance().log("Car Loan created.")
        print("Displaying Car Loan details.")


# Abstract LoanFactory class with a create_loan method
class LoanFactory(ABC):
    @abstractmethod
    def create_loan(self):
        pass


# TODO: Define HomeLoanFactory class derived from LoanFactory with an overridden create_loan method
class HomeLoanFactory(LoanFactory):
    def create_loan(self):
        return HomeLoan()


# TODO: Define CarLoanFactory class derived from LoanFactory with an overridden create_loan method
class CarLoanFactory(LoanFactory):
    def create_loan(self):
        return CarLoan()


if __name__ == "__main__":
    home_loan_factory = HomeLoanFactory()
    home_loan = home_loan_factory.create_loan()
    home_loan.display()

    car_loan_factory = CarLoanFactory()
    car_loan = car_loan_factory.create_loan()
    car_loan.display()
    