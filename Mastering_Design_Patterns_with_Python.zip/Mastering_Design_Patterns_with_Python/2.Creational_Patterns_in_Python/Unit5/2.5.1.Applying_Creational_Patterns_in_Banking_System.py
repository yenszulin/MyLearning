from abc import ABC, abstractmethod


class Logger:
    __instance = None

    @staticmethod
    def getInstance():
        if Logger.__instance == None:
            Logger.__instance = Logger()
        return Logger.__instance

    def log(self, message):
        print(message)


# Abstract products
class Account(ABC):
    @abstractmethod
    def account_type(self):
        pass


class DebitCard(ABC):
    @abstractmethod
    def card_type(self):
        pass


# Concrete products for Savings Account
class SavingsAccount(Account):
    def account_type(self):
        return "Savings Account"


class SavingsDebitCard(DebitCard):
    def card_type(self):
        return "Savings Debit Card"


# Concrete products for Current Account
class CurrentAccount(Account):
    def account_type(self):
        return "Current Account"


class CurrentDebitCard(DebitCard):
    def card_type(self):
        return "Current Debit Card"


# Abstract Factory
class AccountFactory(ABC):
    @abstractmethod
    def create_account(self):
        pass

    @abstractmethod
    def create_debit_card(self):
        pass


# Concrete Factory for Savings Account
class SavingsAccountFactory(AccountFactory):
    def create_account(self):
        return SavingsAccount()

    def create_debit_card(self):
        return SavingsDebitCard()


# Concrete Factory for Current Account
class CurrentAccountFactory(AccountFactory):
    def create_account(self):
        return CurrentAccount()

    def create_debit_card(self):
        return CurrentDebitCard()


if __name__ == "__main__":
    savings_factory = SavingsAccountFactory()
    savings_account = savings_factory.create_account()
    savings_debit_card = savings_factory.create_debit_card()
    Logger.getInstance().log(savings_account.account_type())
    Logger.getInstance().log(savings_debit_card.card_type())
    # Output: Savings Account
    # Output: Savings Debit Card

    current_factory = CurrentAccountFactory()
    current_account = current_factory.create_account()
    current_debit_card = current_factory.create_debit_card()
    Logger.getInstance().log(current_account.account_type())
    Logger.getInstance().log(current_debit_card.card_type())
    # Output: Current Account
    # Output: Current Debit Card