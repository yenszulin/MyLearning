from abc import ABC, abstractmethod


# Abstract Product A
class Controller(ABC):
    @abstractmethod
    def connect(self):
        pass


# Concrete Product A1
class PlayStationController(Controller):
    def connect(self):
        print("Connecting PlayStation controller.")


# Concrete Product A2
class XboxController(Controller):
    def connect(self):
        print("Connecting Xbox controller.")


# Abstract Product B
class Headset(ABC):
    @abstractmethod
    def connect(self):
        pass


# Concrete Product B1
class PlayStationHeadset(Headset):
    def connect(self):
        print("Connecting PlayStation headset.")


# Concrete Product B2
class XboxHeadset(Headset):
    def connect(self):
        print("Connecting Xbox headset.")


# TODO: Implement the AccessoryFactory abstract class with create_controller() and create_headset() methods
class AccessoryFactory(ABC):
    @abstractmethod
    def create_controller(self):
        pass

    def create_headset(self):
        pass


# TODO: Implement the PlayStationFactory concrete class that inherits from AccessoryFactory and implements create_controller() and create_headset() methods
class PlayStationFactory(AccessoryFactory):
    def create_controller(self):
        return PlayStationController()

    def create_headset(self):
        return PlayStationHeadset()


# TODO: Implement the XboxFactory concrete class that inherits from AccessoryFactory and implements create_controller() and create_headset() methods
class XboxFactory(AccessoryFactory):
    def create_controller(self):
        return XboxController()

    def create_headset(self):
        return XboxHeadset()


# Client code
class GameSetup:
    def __init__(self, factory):
        self.factory = factory
        self.controller = self.factory.create_controller()
        self.headset = self.factory.create_headset()

    def setup(self):
        self.controller.connect()
        self.headset.connect()


if __name__ == '__main__':
    system_type = "PlayStation"  # Change to "Xbox" to see Xbox setup
    factory = None

    if system_type == "PlayStation":
        factory = PlayStationFactory()  # TODO: Ensure this class is implemented
    elif system_type == "Xbox":
        factory = XboxFactory()  # TODO: Ensure this class is implemented

    if factory:
        setup = GameSetup(factory)
        setup.setup()
    else:
        print("Unknown system type.")