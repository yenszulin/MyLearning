from abc import ABC, abstractmethod


# TODO: Define an abstract class Spaceship with an abstract method blast_off()
class Spaceship(ABC):
    @abstractmethod
    def blast_off(self):
        pass


# TODO: Define NASASpaceship class that inherits from Spaceship and implements blast_off()
class NASASpaceship(Spaceship):
    def blast_off(self):
        print("NASA spaceship blasting off!")


# TODO: Define SpaceXSpaceship class that inherits from Spaceship and implements blast_off()
class SpaceXSpaceship(Spaceship):
    def blast_off(self):
        print("SpaceX spaceship blasting off!")


# TODO: Define an abstract class SpaceSuit with an abstract method wear()
class SpaceSuit(ABC):
    @abstractmethod
    def wear(self):
        pass


# TODO: Define NASASpaceSuit class that inherits from SpaceSuit and implements wear()
class NASASpaceSuit(SpaceSuit):
    def wear(self):
        print("Wearing NASA space suit.")


# TODO: Define SpaceXSpaceSuit class that inherits from SpaceSuit and implements wear()
class SpaceXSpaceSuit(SpaceSuit):
    def wear(self):
        print("Wearing SpaceX space suit.")


# TODO: Define an abstract class SpaceFactory with abstract methods create_spaceship() and create_space_suit()
class SpaceFactory(ABC):
    @abstractmethod
    def create_spaceship(self):
        pass

    @abstractmethod
    def create_space_suit(self):
        pass


# TODO: Define NASAFactory class that inherits from SpaceFactory and implements create_spaceship() and create_space_suit()
class NASAFactory(SpaceFactory):
    def create_spaceship(self):
        return NASASpaceship()

    def create_space_suit(self):
        return NASASpaceSuit()


# TODO: Define SpaceXFactory class that inherits from SpaceFactory and implements create_spaceship() and create_space_suit()
class SpaceXFactory(SpaceFactory):
    def create_spaceship(self):
        return SpaceXSpaceship()

    def create_space_suit(self):
        return SpaceXSpaceSuit()


# TODO: Define a SpaceMission class with a constructor accepting SpaceFactory, and a method prepare()
class SpaceMission:
    def __init__(self, factory: SpaceFactory):
        self.spaceship = factory.create_spaceship()
        self.space_suit = factory.create_space_suit()

    def prepare(self):
        self.space_suit.wear()
        self.spaceship.blast_off()


if __name__ == '__main__':
    # TODO: Create a variable of type SpaceFactory and set it to None
    factory: SpaceFactory = None  # Initialize factory to None

    # TODO: Create a string variable named agency_type and set it to "NASA" (change to "SpaceX" for SpaceX setup)
    agency_type = "NASA"  # Change to "SpaceX" to test SpaceX setup

    # TODO: Depending on the value of agency_type, initialize the factory variable to NASAFactory or SpaceXFactory
    if agency_type == "NASA":
        factory = NASAFactory()
    elif agency_type == "SpaceX":
        factory = SpaceXFactory()
    # TODO: If factory is not None, create a SpaceMission object using factory, call its prepare() method
    if factory:
        mission = SpaceMission(factory)
        mission.prepare()
    # TODO: If factory is None, print "Unknown agency type."
    else:
        print("Unknown agency type.")