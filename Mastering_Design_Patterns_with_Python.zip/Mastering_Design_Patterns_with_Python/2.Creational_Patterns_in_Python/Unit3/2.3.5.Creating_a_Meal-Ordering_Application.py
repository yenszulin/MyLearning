from abc import ABC, abstractmethod


# TODO: Define an abstract class MainCourse with an abstract method serve()
class MainCourse(ABC):
    @abstractmethod
    def serve(self):
        pass


# TODO: Define an abstract class Drink with an abstract method pour()
class Drink(ABC):
    @abstractmethod
    def pour(self):
        pass


# TODO: Define Pasta class that inherits from MainCourse and implements serve()
class Pasta(MainCourse):
    def serve(self):
        print("Serving Italian pasta.")


# TODO: Define Steak class that inherits from MainCourse and implements serve()
class Steak(MainCourse):
    def serve(self):
        print("Serving grilled steak.")


# TODO: Define Wine class that inherits from Drink and implements pour()
class Wine(Drink):
    def pour(self):
        print("Pouring a glass of wine.")


# TODO: Define Juice class that inherits from Drink and implements pour()
class Juice(Drink):
    def pour(self):
        print("Pouring a glass of juice.")


# TODO: Define an abstract class MealFactory with abstract methods create_main_course() and create_drink()
class MealFactory(ABC):
    @abstractmethod
    def create_main_course(self):
        pass

    @abstractmethod
    def create_drink(self):
        pass


# TODO: Define ItalianMealFactory class that inherits from MealFactory and implements create_main_course() and create_drink()
class ItalianMealFactory(MealFactory):
    def create_main_course(self):
        return Pasta()

    def create_drink(self):
        return Wine()


# TODO: Define SteakhouseMealFactory class that inherits from MealFactory and implements create_main_course() and create_drink()
class SteakhouseMealFactory(MealFactory):
    def create_main_course(self):
        return Steak()

    def create_drink(self):
        return Juice()


# TODO: Define a MealOrderingApp class with a constructor accepting MealFactory, and a method order_meal()
class MealOrderingApp:
    def __init__(self, factory: MealFactory):
        self.main_course = factory.create_main_course()
        self.drink = factory.create_drink()

    def order_meal(self):
        self.main_course.serve()
        self.drink.pour()


if __name__ == '__main__':
    meal_type = "Italian"  # Change to "Steakhouse" to see Steakhouse setup
    factory = None

    if meal_type == "Italian":
        factory = ItalianMealFactory()
    elif meal_type == "Steakhouse":
        factory = SteakhouseMealFactory()

    if factory:
        app = MealOrderingApp(factory)
        app.order_meal()
    else:
        print("Unknown meal type.")