# Your task is to implement a simple text serialization system where different serialization strategies
# can be applied to convert an object to a string.
# You will use the Strategy Pattern to implement this system. You need to define the
# SerializationStrategy interface and two concrete strategy classes: JsonSerialization and
# XmlSerialization. Each strategy will define how the given object's content should be serialized
# (either in JSON or XML format). You will also need to create a Serializer class that can set a
# serialization strategy and use it to serialize an object.

from abc import ABC, abstractmethod


# TODO: Define the SerializationStrategy interface with an abstract method `serialize` that accepts an object
## Define the SerializationStrategy interface
class SerializationStrategy(ABC):
    @abstractmethod
    def serialize(self, obj):
        pass


# TODO: Define the JsonSerialization class that inherits from SerializationStrategy
# The method `serialize` should return a string "JSON representation of {obj}"
## Define the JsonSerialization class
class JsonSerialization(SerializationStrategy):
    def serialize(self, obj):
        return f"JSON representation of {obj}"


# TODO: Define the XmlSerialization class that inherits from SerializationStrategy
# The method `serialize` should return a string "XML representation of {obj}"
## Define the XmlSerialization class
class XmlSerialization(SerializationStrategy):
    def serialize(self, obj):
        return f"XML representation of {obj}"


# TODO: Define the Serializer class
class Serializer:
    def __init__(self):
        self.strategy = None

    # It should have a method `set_serialization_strategy` that accepts a SerializationStrategy object
    def set_serialization_strategy(self, strategy):
        self.strategy = strategy

    # It should have a method `serialize` that accepts an object and applies the current strategy's `serialize` method to the object
    def serialize(self, obj):
        if self.strategy:
            return self.strategy.serialize(obj)
        else:
            return "No serialization strategy set."


## Main execution
if __name__ == "__main__":
    # TODO: Create a Serializer object
    ## Create Serializer object
    serializer = Serializer()

    # TODO: Create JsonSerialization and XmlSerialization objects
    ## Create serialization strategy objects
    json_strategy = JsonSerialization()
    xml_strategy = XmlSerialization()

    # Create a sample dictionary {"name": "John", "age": 30, "city": "New York"}
    ## Sample data
    data = {"name": "John", "age": 30, "city": "New York"}

    # TODO: Set the serialization strategy of the Serializer object to JsonSerialization and serialize the data, then print it
    ## Serialize with JSON strategy
    serializer.set_serialization_strategy(json_strategy)
    print(serializer.serialize(data))

    # TODO: Set the serialization strategy of the Serializer object to XmlSerialization and serialize the data, then print it
    ## Serialize with XML strategy
    serializer.set_serialization_strategy(xml_strategy)
    print(serializer.serialize(data))