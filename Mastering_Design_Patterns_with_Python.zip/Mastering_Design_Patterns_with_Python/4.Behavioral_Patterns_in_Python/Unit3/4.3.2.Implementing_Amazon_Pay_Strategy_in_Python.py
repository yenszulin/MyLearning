# In this exercise, you'll implement the Strategy Pattern to create a flexible payment system. Your goal
# is to follow the TODO instructions to add an Amazon Pay Strategy to an existing Python codebase.
from abc import ABC, abstractmethod


class PaymentStrategy(ABC):
    @abstractmethod
    def pay(self, amount):
        pass


class CreditCardStrategy(PaymentStrategy):
    def __init__(self, card_number):
        self.card_number = card_number

    def pay(self, amount):
        print(f"Paid {amount} using Credit Card: {self.card_number}")


class PayPalStrategy(PaymentStrategy):
    def __init__(self, email):
        self.email = email

    def pay(self, amount):
        print(f"Paid {amount} using PayPal: {self.email}")


# TODO: Define the AmazonPayStrategy class that inherits from PaymentStrategy
class AmazonPayStrategy(PaymentStrategy):
    # TODO: Define a constructor that takes an email address as a parameter and initializes the email member variable
    def __init__(self, email):
        self.email = email

    # TODO: Implement the pay method that prints the payment amount and the email address: "Paid <amount> using Amazon Pay: <email>"
    def pay(self, amount):
        print(f"Paid {amount} using Amazon Pay: {self.email}")


class ShoppingCart:
    def __init__(self):
        self.strategy = None

    def set_payment_strategy(self, strategy):
        self.strategy = strategy

    def checkout(self, amount):
        if self.strategy:
            self.strategy.pay(amount)
        else:
            print("No payment strategy set.")


if __name__ == "__main__":
    cart = ShoppingCart()

    credit_card = CreditCardStrategy("1234-5678-9876-5432")
    paypal = PayPalStrategy("user@example.com")

    # TODO: Create an AmazonPayStrategy object with the email "amazon@user.com"
    amazon_pay = AmazonPayStrategy("amazon@user.com")

    cart.set_payment_strategy(credit_card)
    cart.checkout(100)

    cart.set_payment_strategy(paypal)
    cart.checkout(150)

    # TODO: Set the payment strategy to amazon_pay and call the checkout method with an amount of 200
    cart.set_payment_strategy(amazon_pay)
    cart.checkout(200)