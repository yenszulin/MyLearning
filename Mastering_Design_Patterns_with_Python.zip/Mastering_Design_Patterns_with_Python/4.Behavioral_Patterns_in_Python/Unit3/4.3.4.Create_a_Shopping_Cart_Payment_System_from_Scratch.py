# You will build a payment system for a shopping cart, managing both Credit Card and PayPal payments.
# Create the necessary classes and methods, ensuring seamless functionality.

from abc import ABC, abstractmethod

# TODO: Define the PaymentStrategy class
# This should be an abstract base class with a single abstract method pay that takes an amount as a parameter
## Define the PaymentStrategy class
class PaymentStrategy(ABC):
    @abstractmethod
    def pay(self, amount):
        pass


# TODO: Define the CreditCardStrategy class that inherits from PaymentStrategy
## Define the CreditCardStrategy class
class CreditCardStrategy(PaymentStrategy):
    # The constructor should accept a card_number
    def __init__(self, card_number):
        self.card_number = card_number

    # The pay method should output the payment amount and card number: "Paid <amount> using Credit Card: <card_number>"
    def pay(self, amount):
        print(f"Paid {amount} using Credit Card: {self.card_number}")


# TODO: Define the PayPalStrategy class that inherits from PaymentStrategy
## Define the PayPalStrategy class
class PayPalStrategy(PaymentStrategy):
    # The constructor should accept an email
    def __init__(self, email):
        self.email = email

    # The pay method should output the payment amount and email: "Paid <amount> using PayPal: <email>"
    def pay(self, amount):
        print(f"Paid {amount} using PayPal: {self.email}")


# TODO: Define the ShoppingCart class
## Define the ShoppingCart class
class ShoppingCart:
    def __init__(self):
        self.payment_strategy = None

    # It should have a method set_payment_strategy that accepts a PaymentStrategy instance
    def set_payment_strategy(self, strategy):
        self.payment_strategy = strategy

    # It should have a method checkout that accepts an amount and executes the strategy's pay method if available, otherwise print "No payment strategy set."
    def checkout(self, amount):
        if self.payment_strategy:
            self.payment_strategy.pay(amount)
        else:
            print("No payment strategy set.")


if __name__ == "__main__":
    cart = ShoppingCart()

    credit_card = CreditCardStrategy("1234-5678-9876-5432")
    paypal = PayPalStrategy("user@example.com")

    cart.set_payment_strategy(credit_card)
    cart.checkout(100)

    cart.set_payment_strategy(paypal)
    cart.checkout(200)