# Welcome to the world of payment processing with the Strategy Pattern! Dive into this task where you'll implement a
# ShoppingCart class that uses strategies like CreditCardStrategy, PayPalStrategy, and BitcoinStrategy.
# Follow the TODO comments in the starter code to bring the ShoppingCart to life and enable seamless payments.

from abc import ABC, abstractmethod


class PaymentStrategy(ABC):
    @abstractmethod
    def pay(self, amount):
        pass


class CreditCardStrategy(PaymentStrategy):
    def __init__(self, card_number):
        self.card_number = card_number

    def pay(self, amount):
        print(f"Paid {amount} using Credit Card: {self.card_number}")


class PayPalStrategy(PaymentStrategy):
    def __init__(self, email):
        self.email = email

    def pay(self, amount):
        print(f"Paid {amount} using PayPal: {self.email}")


class BitcoinStrategy(PaymentStrategy):
    def __init__(self, wallet_address):
        self.wallet_address = wallet_address

    def pay(self, amount):
        print(f"Paid {amount} using Bitcoin: {self.wallet_address}")


# TODO: Implement the ShoppingCart class below
# The ShoppingCart class should have set_payment_strategy method to set the payment strategy
# The ShoppingCart class should have checkout method to process the payment using the selected strategy or print "No payment strategy set." if no strategy is set
class ShoppingCart:
    def __init__(self):
        self.payment_strategy = None

    def set_payment_strategy(self, payment_strategy):
        self.payment_strategy = payment_strategy

    def checkout(self, amount):
        if self.payment_strategy:
            self.payment_strategy.pay(amount)
        else:
            print("No payment strategy set.")


if __name__ == "__main__":
    # TODO: Create an instance of the ShoppingCart class
    cart = ShoppingCart()

    payment_strategies = [
        CreditCardStrategy("1234-5678-9876-5432"),
        PayPalStrategy("user@example.com"),
        BitcoinStrategy("1A2b3C4d5E6f7G8h9I0j1K2L3m4N5o6P7")
    ]

    for strategy in payment_strategies:
        # TODO: Set the payment strategy for the cart and checkout with amount 100
        cart.set_payment_strategy(strategy)
        cart.checkout(100)