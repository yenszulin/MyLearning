# You need to create classes for User, Command, and ChatRoom, and implement their interactions.

from abc import ABC, abstractmethod


# TODO: Define the User class implementing the Observer pattern
# Class User should have:
# - A constructor to initialize the user's name
# - A method `receive_message` which takes a message parameter to display a received message
## User class implementing the Observer pattern
class User:
    def __init__(self, name):
        self.name = name

    def receive_message(self, message):
        print(f"{self.name} received: {message}")


# TODO: Define an abstract Command class with an `execute` method
## Abstract Command class
class Command(ABC):
    @abstractmethod
    def execute(self):
        pass


# TODO: Define the ChatRoom class
# Class ChatRoom should have:
# - A list to keep track of users
# - A method `show_message` to display the message to the chat room
# - A method `add_user` to add a user to the chat room
# - A method `send_message` to broadcast a message to all users
# ChatRoom class
class ChatRoom:
    def __init__(self):
        self.users = []

    def add_user(self, user):
        self.users.append(user)

    def show_message(self, message):
        print(f"ChatRoom displays: {message}")

    def send_message(self, message):
        for user in self.users:
            user.receive_message(message)


# TODO: Define the ChatCommand class inheriting from Command
# Class ChatCommand should have:
# - A constructor to initialize the chat_room and message
# - An overridden `execute` method to show and broadcast the message
# ChatCommand class inheriting from Command
class ChatCommand(Command):
    def __init__(self, chat_room, message):
        self.chat_room = chat_room
        self.message = message

    def execute(self):
        self.chat_room.show_message(self.message)
        self.chat_room.send_message(self.message)


# TODO: Implement the main function
# In the main function:
# - Create a ChatRoom instance
# - Create two User instances with names "Alice" and "Bob"
# - Add users to the chat room
# - Create a ChatCommand instance with a message "Hello, everyone!"
# - Execute the command to display and broadcast the message

# Main function
def main():
    chat_room = ChatRoom()

    alice = User("Alice")
    bob = User("Bob")

    chat_room.add_user(alice)
    chat_room.add_user(bob)

    command = ChatCommand(chat_room, "Hello, everyone!")
    command.execute()


# Run the main function
if __name__ == "__main__":
    main()