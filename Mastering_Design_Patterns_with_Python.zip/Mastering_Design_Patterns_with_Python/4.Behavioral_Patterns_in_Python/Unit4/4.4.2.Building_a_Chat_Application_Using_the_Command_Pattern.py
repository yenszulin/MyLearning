# In this task, we will be creating a chat application using the Command Pattern. You need to create
# classes for Command and ChatRoom, and implement their interactions.
# Follow the TODO instructions and you'll be up and running in no time!
from abc import ABC, abstractmethod


class User:
    def __init__(self, name):
        self.name = name

    def receive_message(self, message):
        print(f"{self.name} received message: {message}")


# TODO: Define an abstract Command class with an `execute` method
## Define abstract Command class
class Command(ABC):
    def execute(self):
        pass


# TODO: Define the ChatRoom class
## Define ChatRoom class
class ChatRoom:
    # Class ChatRoom should have:
    # - A list to keep track of users
    def __init__(self):
        self.users = []

    # - A method `show_message` to display the message to the chat room
    def show_message(self, message):
        print(f"[ChatRoom]: {message}")

    # - A method `add_user` to add a user to the chat room
    def add_user(self, user):
        self.users.append(user)

    # - A method `send_message` to broadcast a message to all users
    def send_message(self, message):
        for user in self.users:
            user.receive_message(message)


# TODO: Define the ChatCommand class inheriting from Command
## Define ChatCommand class
class ChatCommand(Command):
    # Class ChatCommand should have:
    # - A constructor to initialize the chat_room and message
    def __init__(self, chat_room, message):
        self.chat_room = chat_room
        self.message = message

    # - An overridden `execute` method to show and broadcast the message
    def execute(self):
        self.chat_room.show_message(self.message)
        self.chat_room.send_message(self.message)


if __name__ == "__main__":
    chat_room = ChatRoom()
    user1 = User("Alice")
    user2 = User("Bob")

    chat_room.add_user(user1)
    chat_room.add_user(user2)

    chat_command = ChatCommand(chat_room, "Hello, everyone!")
    chat_command.execute()