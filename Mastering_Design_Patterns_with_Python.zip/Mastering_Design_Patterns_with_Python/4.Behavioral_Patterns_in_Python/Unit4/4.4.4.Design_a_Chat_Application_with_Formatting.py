# Your task is to create a chat application using the Command, Observer, and Strategy patterns. Follow the
# TODO instructions for more details.
# Hint: You can use .upper() and .lower() on a string in Python to format it as entirely upper case or entirely
# lower case.

from abc import ABC, abstractmethod


# Strategy interface
class MessageFormatStrategy(ABC):
    @abstractmethod
    def format_message(self, message):
        pass


# TODO: Implement the UppercaseMessageFormat and LowercaseMessageFormat classes
# Create two concrete strategy classes: UppercaseMessageFormat and LowercaseMessageFormat
# Implement the `format_message` method in both classes to convert the input message to uppercase and lowercase respectively.
# Concrete strategy: uppercase formatting
class UppercaseMessageFormat(MessageFormatStrategy):
    def format_message(self, message):
        return message.upper()


# Concrete strategy: lowercase formatting
class LowercaseMessageFormat(MessageFormatStrategy):
    def format_message(self, message):
        return message.lower()


# Observer (User)
class User:
    def __init__(self, name):
        self.name = name

    def receive_message(self, message):
        print(f"{self.name} received message: {message}")


# Command interface
class Command(ABC):
    @abstractmethod
    def execute(self):
        pass


# Subject (ChatRoom)
class ChatRoom:
    def __init__(self):
        self.users = []

    def add_user(self, user):
        self.users.append(user)

    def send_message(self, message):
        for user in self.users:
            user.receive_message(message)


# TODO: Implement the ChatCommand class
# Define the ChatCommand class inheriting from Command
# ChatCommand should be initialized with a ChatRoom instance, a MessageFormatStrategy instance, and message
# Implement the `execute` method in ChatCommand to format and send the message using the strategy
## Concrete Command
class ChatCommand(Command):
    def __init__(self, chat_room, strategy, message):
        self.chat_room = chat_room
        self.strategy = strategy
        self.message = message

    def execute(self):
        formatted_message = self.strategy.format_message(self.message)
        self.chat_room.send_message(formatted_message)


# TODO: Implement the main function
# In the main function:
# - Create instances of uppercase and lowercase message format strategies
# - Create ChatCommand instances to send uppercase and lowercase messages
# - Execute the commands to send both messages

if __name__ == "__main__":
    user1 = User("Alice")
    user2 = User("Bob")

    chat_room = ChatRoom()
    chat_room.add_user(user1)
    chat_room.add_user(user2)

    # Define strategy instances and ChatCommand instances here and execute the commands

    # Strategies
    upper_strategy = UppercaseMessageFormat()
    lower_strategy = LowercaseMessageFormat()

    # Chat commands
    upper_command = ChatCommand(chat_room, upper_strategy, "Hello, World!")
    lower_command = ChatCommand(chat_room, lower_strategy, "Hello, World!")

    # Execute commands
    upper_command.execute()
    lower_command.execute()