from abc import ABC, abstractmethod

class Command(ABC):
    @abstractmethod
    def execute(self):
        pass

class User:
    def __init__(self, name):
        self.name = name

    def receive_message(self, message):
        print(f"{self.name} received message: {message}")

class ChatRoom:
    def __init__(self):
        self.users = []

    def add_user(self, user):
        self.users.append(user)

    def show_message(self, message):
        print(f"Message: {message}")

    def send_message(self, message):
        for user in self.users:
            user.receive_message(message)

class ChatCommand(Command):
    def __init__(self, chat_room, message):
        self.chat_room = chat_room
        self.message = message

    def execute(self):
        self.chat_room.show_message(self.message)
        self.chat_room.send_message(self.message)

if __name__ == "__main__":
    chat_room = ChatRoom()
    user1 = User("Alice")
    user2 = User("Bob")

    chat_room.add_user(user1)
    chat_room.add_user(user2)

    chat_command = ChatCommand(chat_room, "Hello, everyone!")
    chat_command.execute()
    # Outputs:
    # Message: Hello, everyone!
    # Alice received message: Hello, everyone!
    # Bob received message: Hello, everyone!