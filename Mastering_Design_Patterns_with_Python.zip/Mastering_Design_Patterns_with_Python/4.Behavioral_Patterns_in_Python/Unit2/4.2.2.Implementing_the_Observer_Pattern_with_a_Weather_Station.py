# Fill in the missing parts of the provided code where a WeatherStation notifies its observers about
# temperature changes.

from abc import ABC, abstractmethod


# Observer Interface
class Observer(ABC):
    @abstractmethod
    def update(self, temperature):
        pass


# Subject
class WeatherStation:
    def __init__(self):
        self.observers = []
        self.temperature = None

    # TODO: Implement the add_observer method to add a new observer to the list
    def add_observer(self, observer):
        self.observers.append(observer)

    # TODO: Implement the remove_observer method to remove an observer from the list
    def remove_observer(self, observer):
        self.observers.remove(observer)

    # TODO: Implement the set_temperature method to notify all observers about a temperature change
    def set_temperature(self, temperature):
        self.temperature = temperature
        print(f"\n[WeatherStation] Temperature set to {temperature}°C. Notifying observers...")
        for observer in self.observers:
            observer.update(temperature)


# Concrete Observer
class ConcreteObserver(Observer):
    def __init__(self, name):
        self.name = name

    def update(self, temperature):
        print(f'{self.name} received temperature update: {temperature}°C')


# Client Code
if __name__ == "__main__":
    weather_station = WeatherStation()
    observer1 = ConcreteObserver("Observer 1")
    observer2 = ConcreteObserver("Observer 2")

    weather_station.add_observer(observer1)
    weather_station.add_observer(observer2)

    weather_station.set_temperature(25)
    weather_station.remove_observer(observer1)
    weather_station.set_temperature(30)