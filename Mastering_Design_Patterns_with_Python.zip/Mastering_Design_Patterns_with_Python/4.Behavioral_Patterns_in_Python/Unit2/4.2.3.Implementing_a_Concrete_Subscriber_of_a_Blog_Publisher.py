# Fill in the missing parts of the provided code where the ConcreteSubscriber class needs to be implemented to
# receive notifications about new articles.
from abc import ABC, abstractmethod


# Observer Interface
class Subscriber(ABC):
    @abstractmethod
    def update(self, news):
        pass

# Subject
class BlogPublisher:
    def __init__(self):
        self.subscribers = []

    def add_subscriber(self, subscriber):
        self.subscribers.append(subscriber)

    def remove_subscriber(self, subscriber):
        self.subscribers.remove(subscriber)

    def publish(self, article):
        for subscriber in self.subscribers:
            subscriber.update(article)


# TODO: Implement the ConcreteSubscriber class to receive notifications
# The constructor should initialize the name of the subscriber
# The update method should print the name of the subscriber and the new article received as an argument from the publisher.
# Format: "<name> received a new article: <article>"
# Concrete Observer
class ConcreteSubscriber(Subscriber):
    def __init__(self, name):
        self.name = name

    def update(self, article):
        print(f"{self.name} received a new article: {article}")


def main():
    blog_publisher = BlogPublisher()
    subscriber1 = ConcreteSubscriber("Subscriber 1")
    subscriber2 = ConcreteSubscriber("Subscriber 2")

    blog_publisher.add_subscriber(subscriber1)
    blog_publisher.add_subscriber(subscriber2)

    blog_publisher.publish("New Article 1")
    blog_publisher.remove_subscriber(subscriber1)
    blog_publisher.publish("New Article 2")


if __name__ == "__main__":
    main()