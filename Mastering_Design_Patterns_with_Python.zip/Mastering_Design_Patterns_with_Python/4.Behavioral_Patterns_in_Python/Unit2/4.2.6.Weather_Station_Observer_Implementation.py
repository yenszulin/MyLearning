# Here's a fun task for you to practice the Observer Pattern. Your goal is to create a system where a WeatherStation
# notifies its Devices about weather updates. Follow the TODO comments in the starter code to implement the required
#  classes and methods, adding and removing devices, and simulating weather updates.

from abc import ABC, abstractmethod


## Abstract base class for devices
class Device(ABC):
    @abstractmethod
    def update(self, news):
        pass


# TODO: Implement WeatherStation class
# The add_device method should add a device to the list.
# The remove_device method should remove a device from the list.
# The set_weather method should notify all devices about the new weather update.

## WeatherStation class as the subject
class WeatherStation:
    def __init__(self):
        self.devices = []

    def add_device(self, device):
        self.devices.append(device)

    def remove_device(self, device):
        self.devices.remove(device)

    def set_weather(self, weather):
        print(f"\n[Weather Update] Now it's {weather}")
        for device in self.devices:
            device.update(weather)


# TODO: Implement ConcreteDevice class inheriting from Device
# The update method should print "<device_name> is displaying: <weather>"

## Concrete implementation of a device
class ConcreteDevice(Device):
    def __init__(self, name):
        self.name = name

    def update(self, weather):
        print(f"{self.name} is displaying: {weather}")


if __name__ == "__main__":
    station = WeatherStation()

    # TODO: Initialize devices Device 1 and Device 2
    device1 = ConcreteDevice("Device 1")
    device2 = ConcreteDevice("Device 2")
    # TODO: Add devices to the weather station's list
    station.add_device(device1)
    station.add_device(device2)
    # TODO: Set weather to "Sunny" and notify all devices
    station.set_weather("Sunny")

    # TODO: Remove Device 1 from the weather station's list
    station.remove_device(device1)
    # TODO: Set weather to "Rainy" and notify all devices
    station.set_weather("Rainy")
