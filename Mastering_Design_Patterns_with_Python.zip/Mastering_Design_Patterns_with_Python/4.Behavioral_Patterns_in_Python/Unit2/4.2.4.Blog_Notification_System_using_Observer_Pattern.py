# Here, you'll create a system where a Blog notifies its Followers about the latest posts. This exercise
# helps you understand the Observer Pattern. Your task is to create a Blog class that manages followers and notifies
# them. Additionally, you will have to implete a ConcreteFollower to simulate followers.

from abc import ABC, abstractmethod


# Observer Interface
class Follower(ABC):
    @abstractmethod
    def update(self, news):
        pass


# TODO: Implement the Blog class with:
# - an initializer method to initialize followers list
# - an add_follower method to add a follower to the followers list
# - a new_post method to notify all followers about the new blog post
# Subject
class Blog:
    def __init__(self):
        self.followers = []

    def add_follower(self, follower):
        self.followers.append(follower)

    def new_post(self, blog_post):
        print(f"\n[Blog] New post published: {blog_post}")
        for follower in self.followers:
            follower.update(blog_post)


# TODO: Implement the ConcreteFollower class that inherits from Follower and overrides the update method to say: "<name> received new blog post: <blog_post>"
# Concrete Observer
class ConcreteFollower(Follower):
    def __init__(self, name):
        self.name = name

    def update(self, blog_post):
        print(f"{self.name} received new blog post: {blog_post}")


# Client Code
if __name__ == "__main__":
    blog = Blog()
    follower1 = ConcreteFollower("Follower 1")
    follower2 = ConcreteFollower("Follower 2")

    blog.add_follower(follower1)
    blog.add_follower(follower2)

    blog.new_post("How to use Observer Pattern")
    blog.new_post("Advanced Python Tips")