# Your mission is to build a system where changes in stock prices automatically notify their subscribers.
# Take your time to follow the instructions in the starter code, piece by piece, to implement the entire system.
from abc import ABC, abstractmethod


# TODO: Create a Subscriber class with an empty update method.
class Subscriber(ABC):
    @abstractmethod
    def update(self, price):
        print


# TODO: Implement a Stock class that can add, remove, and notify subscribers.
# The add_subscriber method should add a subscriber to the list.
# The remove_subscriber method should remove a subscriber from the list.
# The set_price method should notify all subscribers about the new price.
class Stock:
    def __init__(self):
        self.subscribers = []
        self.price = None

    def add_subscriber(self, subscriber):
        self.subscribers.append(subscriber)

    def remove_subscriber(self, subscriber):
        self.subscribers.remove(subscriber)

    def set_price(self, price):
        self.price = price
        print(f"\n[Stock] New price set: {price}")
        self.notify_subscribers()

    def notify_subscribers(self):
        for subscriber in self.subscribers:
            subscriber.update(self.price)


# TODO: Implement a ConcreteSubscriber class that inherits from Subscriber and overrides the update method to print: "<subscriber_name> received new stock price: <price>".
# Concrete Observer
class ConcreteSubscriber(Subscriber):
    def __init__(self, name):
        self.name = name

    def update(self, price):
        print(f"{self.name} received new stock price: {price}")


if __name__ == "__main__":
    stock = Stock()
    subscriber1 = ConcreteSubscriber("Subscriber 1")
    subscriber2 = ConcreteSubscriber("Subscriber 2")

    stock.add_subscriber(subscriber1)
    stock.add_subscriber(subscriber2)

    stock.set_price(150.0)
    stock.remove_subscriber(subscriber1)
    stock.set_price(155.5)