# In this task, you'll create a system to control Radio and TV media players using the Command pattern.
# Implement both classes from scratch. The Radio can be turned on, turned off, and have its volume set
# to high. The TV can be turned on, turned off, and have its channel set. Use the Command pattern to manage
# these controls through a RemoteControl.
from abc import ABC, abstractmethod


# TODO: Define a Command class with an execute method.
# === Command Interface ===
class Command(ABC):
    @abstractmethod
    def execute(self):
        pass


# TODO: Implement a Radio class with on, off, and volume_high methods.
# === Receiver: Radio ===
class Radio:
    def on(self):
        print("Radio is ON.")

    def off(self):
        print("Radio is OFF.")

    def volume_high(self):
        print("Radio volume set to HIGH.")


# TODO: Implement a TV class with on, off, and set_channel methods.
# === Receiver: TV ===
class TV:
    def on(self):
        print("TV is ON.")

    def off(self):
        print("TV is OFF.")

    def set_channel(self, channel):
        print(f"TV channel set to {channel}.")


# TODO: Create RadioOnCommand, RadioOffCommand, and RadioVolumeHighCommand classes that implement Command interface and control Radio.
# === Radio Commands ===
class RadioOnCommand(Command):
    def __init__(self, radio):
        self.radio = radio

    def execute(self):
        self.radio.on()


class RadioOffCommand(Command):
    def __init__(self, radio):
        self.radio = radio

    def execute(self):
        self.radio.off()


class RadioVolumeHighCommand(Command):
    def __init__(self, radio):
        self.radio = radio

    def execute(self):
        self.radio.volume_high()


# TODO: Create TVOnCommand, TVOffCommand, and TVSetChannelCommand classes that implement Command interface and control TV.
# === TV Commands ===
class TVOnCommand(Command):
    def __init__(self, tv):
        self.tv = tv

    def execute(self):
        self.tv.on()


class TVOffCommand(Command):
    def __init__(self, tv):
        self.tv = tv

    def execute(self):
        self.tv.off()


class TVSetChannelCommand(Command):
    def __init__(self, tv, channel):
        self.tv = tv
        self.channel = channel

    def execute(self):
        self.tv.set_channel(self.channel)


# TODO: Implement a RemoteControl class that sets and executes commands.
# === Invoker ===
class RemoteControl:
    def __init__(self):
        self.command = None

    def set_command(self, command):
        self.command = command

    def press_button(self):
        if self.command:
            self.command.execute()
        else:
            print("No command has been set.")


# TODO: Write a main function to test the implementation.
# === Main ===
if __name__ == "__main__":
    # Devices
    radio = Radio()
    tv = TV()

    # Radio Commands
    radio_on = RadioOnCommand(radio)
    radio_off = RadioOffCommand(radio)
    radio_volume_high = RadioVolumeHighCommand(radio)

    # TV Commands
    tv_on = TVOnCommand(tv)
    tv_off = TVOffCommand(tv)
    tv_channel_5 = TVSetChannelCommand(tv, 5)

    # Remote Control
    remote = RemoteControl()

    # Test Radio
    remote.set_command(radio_on)
    remote.press_button()
    remote.set_command(radio_volume_high)
    remote.press_button()
    remote.set_command(radio_off)
    remote.press_button()

    print("---")

    # Test TV
    remote.set_command(tv_on)
    remote.press_button()
    remote.set_command(tv_channel_5)
    remote.press_button()
    remote.set_command(tv_off)
    remote.press_button()