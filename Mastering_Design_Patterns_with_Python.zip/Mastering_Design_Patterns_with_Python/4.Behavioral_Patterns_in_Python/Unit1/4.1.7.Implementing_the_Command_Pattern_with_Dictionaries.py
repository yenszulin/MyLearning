# In this task, we will implement a common use case of the Command pattern. Specifically, we will map commands to
# objects and execute these commands based on user input.
# Follow the TODO instructions in the starter code to complete the task.
from abc import ABC, abstractmethod


# Command interface
class Command(ABC):
    @abstractmethod
    def execute(self):
        pass


# Receiver
class Light:
    def on(self):
        print("Light is on.")

    def off(self):
        print("Light is off.")


# TODO: Implement the LightOnCommand that initializes with a Light object and turns the light on when executed
# Concrete Command to turn light on
class LightOnCommand(Command):
    def __init__(self, light):
        self.light = light

    def execute(self):
        self.light.on()


# TODO: Implement the LightOffCommand that initializes with a Light object and turns the light off when executed
# Concrete Command to turn light off
class LightOffCommand(Command):
    def __init__(self, light):
        self.light = light

    def execute(self):
        self.light.off()


# Invoker
class RemoteControl:
    def __init__(self):
        self.commands = {}

    def set_command(self, name, command):
        self.commands[name] = command

    def press_button(self, name):
        if name in self.commands:
            self.commands[name].execute()
        else:
            print(f"No command named '{name}' found.")


# Client code
if __name__ == "__main__":
    light = Light()

    # TODO: Create 'lightOn' and 'lightOff' command objects with LightOnCommand and LightOffCommand respectively
    # Create command objects
    light_on = LightOnCommand(light)
    light_off = LightOffCommand(light)

    remote = RemoteControl()

    # TODO: Set commands "lightOn" and "lightOff" in remote using remote.set_command
    remote.set_command("lightOn", light_on)
    remote.set_command("lightOff", light_off)

    # TODO: Simulate user input by pressing "lightOn" and "lightOff" buttons using remote.press_button
    # Simulate button presses
    remote.press_button("lightOn")  # Output: Light is on.
    remote.press_button("lightOff")  # Output: Light is off.
    remote.press_button("unknown")  # Output: No command named 'unknown' found.
