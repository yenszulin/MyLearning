# In this exercise, you'll implement the Command Pattern to control a Radio. Write the implementation of
# each class from scratch. The Radio should be able to be turned on, turned off, and set to a specific
# frequency using a remote control.
from abc import ABC, abstractmethod


# Command interface
class Command(ABC):
    @abstractmethod
    def execute(self):
        pass


# TODO: Implement Radio class with on, off, and set_frequency methods.
# - on method should print "Radio is on."
# - off method should print "Radio is off."
# - set_frequency method should print "Radio frequency set to <frequency>."
# Receiver: Radio
class Radio:
    def on(self):
        print(f"Radio is on.")

    def off(self):
        print(f"Radio is off.")

    def set_frequency(self, frequency):
        print(f"Radio frequency set to {frequency}.")


# Concrete Commands
class RadioOnCommand(Command):
    def __init__(self, radio):
        self.radio = radio

    def execute(self):
        self.radio.on()


class RadioOffCommand(Command):
    def __init__(self, radio):
        self.radio = radio

    def execute(self):
        self.radio.off()


class RadioSetFrequencyCommand(Command):
    def __init__(self, radio, frequency):
        self.radio = radio
        self.frequency = frequency

    def execute(self):
        self.radio.set_frequency(self.frequency)


# Invoker
class RemoteControl:
    def __init__(self):
        self.command = None

    def set_command(self, command):
        self.command = command

    def press_button(self):
        if self.command:
            self.command.execute()
        else:
            print("No command set.")


# Client Code
if __name__ == "__main__":
    radio = Radio()
    radio_on = RadioOnCommand(radio)
    radio_off = RadioOffCommand(radio)
    set_frequency = RadioSetFrequencyCommand(radio, 101.1)

    remote = RemoteControl()
    remote.set_command(radio_on)
    remote.press_button()
    remote.set_command(set_frequency)
    remote.press_button()
    remote.set_command(radio_off)
    remote.press_button()