# In this exercise, you'll fill in the missing parts of a code to implement the Remote Control example
# using the Command Pattern in Python. Follow the TODO comments in the code to complete the implementation.
from abc import ABC, abstractmethod

# Command interface
class Command(ABC):
    @abstractmethod
    def execute(self):
        pass


# Receiver: Fan
class Fan:
    def on(self):
        print("Fan is on.")

    def off(self):
        print("Fan is off.")

# Concrete Commands
class FanOnCommand(Command):
    def __init__(self, fan):
        self.fan = fan

    def execute(self):
        self.fan.on()


class FanOffCommand(Command):
    def __init__(self, fan):
        self.fan = fan

    def execute(self):
        self.fan.off()


# Invoker
class RemoteControl:
    def __init__(self):
        self.command = None

    # TODO: Implement the set_command method to set the command
    def set_command(self, command):
        self.command = command

    # TODO: Implement the press_button method to execute the command
    # Make sure the command exists before trying to execute it
    def press_button(self):
        if self.command:
            self.command.execute()
        else:
            print("There's no command.")


if __name__ == "__main__":
    fan = Fan()
    fan_on = FanOnCommand(fan)
    fan_off = FanOffCommand(fan)

    remote = RemoteControl()
    remote.set_command(fan_on)
    remote.press_button()
    remote.set_command(fan_off)
    remote.press_button()