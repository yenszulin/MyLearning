# In this task, you need to create a system that controls a TV. Write the implementation of each class
# from scratch. The TV should be able to be turned on and off using a remote control.
from abc import ABC, abstractmethod


# Command Interface
class Command(ABC):
    @abstractmethod
    def execute(self):
        pass


# TODO: Implement a TV class that has on and off methods.
# Receiver: TV with on and off functionality
class TV:
    def on(self):
        print("TV is on.")

    def off(self):
        print("TV is off.")


# TODO: Create TVOnCommand and TVOffCommand classes that implement Command interface and control TV.
# Concrete Command to turn TV on
class TVOnCommand(Command):
    def __init__(self, tv: TV):
        self.tv = tv

    def execute(self):
        self.tv.on()


# Concrete Command to turn TV off
class TVOffCommand(Command):
    def __init__(self, tv: TV):
        self.tv = tv

    def execute(self):
        self.tv.off()


# TODO: Implement a RemoteControl class that sets and executes commands.
# Invoker: Remote control that executes commands
class RemoteControl:
    def __init__(self):
        self.command = None

    def set_command(self, command):
        self.command = command

    def press_button(self):
        if self.command:
            self.command.execute()
        else:
            print("There's no command.")


# TODO: Write a main function to test the implementation.
if __name__ == "__main__":
    tv = TV()
    on_command = TVOnCommand(tv)
    off_command = TVOffCommand(tv)

    remote = RemoteControl()
    remote.set_command(on_command)
    remote.press_button()  # Should turn the TV on
    remote.set_command(off_command)
    remote.press_button()  # Should turn the TV off