from abc import ABC, abstractmethod

# Command interface
class Command(ABC):
    @abstractmethod
    def execute(self):
        pass

# Receiver: Light
class Light:
    def on(self):
        print("Light is on.")

    def off(self):
        print("Light is off.")

# Concrete Commands
class LightOnCommand(Command):
    def __init__(self, light):
        self.light = light

    def execute(self):
        self.light.on()

class LightOffCommand(Command):
    def __init__(self, light):
        self.light = light

    def execute(self):
        self.light.off()


# Invoker
class RemoteControl:
    def __init__(self):
        self.commands = {}

    def set_command(self, name, command):
        self.commands[name] = command

    def press_button(self, name):
        if name in self.commands:
            self.commands[name].execute()
        else:
            print(f"No command named '{name}' found.")

if __name__ == "__main__":
    light = Light()
    light_on = LightOnCommand(light)
    light_off = LightOffCommand(light)

    remote = RemoteControl()
    remote.set_command("lightOn", light_on)
    remote.set_command("lightOff", light_off)

    # Simulate user input
    remote.press_button("lightOn") # Output: Light is on.
    remote.press_button("lightOff") # Output: Light is off.