# In this task, you'll implement the PlayMusicCommand and StopMusicCommand classes to complete the
# RemoteControl system for a Music Player using Python. Fill in the missing parts so that the Music
# Player can be turned on or off using a remote control.
from abc import ABC, abstractmethod

# Command interface
class Command(ABC):
    @abstractmethod
    def execute(self):
        pass

# Receiver: MusicPlayer
class MusicPlayer:
    def play(self):
        print("Music Player is playing.")

    def stop(self):
        print("Music Player is stopped.")


# TODO: Implement the PlayMusicCommand class that takes a MusicPlayer object in the constructor and defines the execute method to play the music player
# Concrete Commands
class PlayMusicCommand(Command):
    def __init__(self, player):
        self.player = player

    def execute(self):
        self.player.play()


# TODO: Implement the StopMusicCommand class that takes a MusicPlayer object in the constructor and defines the execute method to stop the music player
class StopMusicCommand(Command):
    def __init__(self, player):
        self.player = player

    def execute(self):
        self.player.stop()

# Invoker
class RemoteControl:
    def __init__(self):
        self.command = None

    def set_command(self, command):
        self.command = command

    def press_button(self):
        if self.command:
            self.command.execute()


if __name__ == "__main__":
    player = MusicPlayer()
    play_music = PlayMusicCommand(player)
    stop_music = StopMusicCommand(player)

    remote = RemoteControl()
    remote.set_command(play_music)
    remote.press_button()
    remote.set_command(stop_music)
    remote.press_button()