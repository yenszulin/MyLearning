
# You are provided with two arrays of unique integers, with the lengths of arrays ranging from 1 to 100, inclusive. The task requires you
# to identify elements that appear in both arrays and return them in an array, maintaining the order from the first provided array. Each
# array's element ranges from -100 to 100, inclusive. In your function common_elements(listA, listB), listA and listB represent the two
# input arrays. The function should return an array that includes the common elements found in both listA and listB, while preserving the
# order of elements as they appear in listA. For example, if listA = [7, 2, 3, 9, 1] and listB = [2, 3, 7, 6], the output should be [7, 2,
# 3].

def common_elements(listA, listB):
    result = []
    for i in range(len(listA)):
        for j in range(len(listB)):
            if listA[i] == listB[j]:
                result.append(listA[i])
    return result

from typing import List

def common_elements_List(listA: List[int], listB: List[int]) -> List[int]:
    setB = set(listB)  # Convert listB to a set for O(1) lookups
    return [x for x in listA if x in setB]

if (__name__ == "__main__"):
    listA = [7, 2, 3, 9, 1]
    listB = [2, 3, 7, 6]
    print(common_elements(listA, listB))
    print(common_elements_List(listA, listB))
