# Imagine you've received two lists of integers. Should you choose to accept this mission, you'll need to write a function that locates and
# returns pairs of integers. The first element of the pair will come from the first list, with the second coming from the second list.
# Important to note is that the first element must be less than the second. The order of pairs in your result should follow the order in
# which they appear in the input lists. For instance, given the lists [1, 3, 7] and [2, 8, 9], the function should return [(1, 2), (1, 8),
# (1, 9), (3, 8), (3, 9), (7, 8), (7, 9)]. It's a challenge if no pairs exist, or if any input list is empty. Let's dissect this task to
# unravel the solution together!
def find_valid_pairs(list1, list2):
    result = []
    for i in list1:
        for j in list2:
            if i < j:
                result.append((i, j))
    return result


if (__name__ == "__main__"):
    print(find_valid_pairs([1, 3, 7], [2, 8, 9]))
