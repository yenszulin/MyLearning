# Imagine you've received two lists of integers. Should you choose to accept this mission, you'll need to write a function that locates and
# returns pairs of integers. The first element of the pair will come from the first list, with the second coming from the second list.
# Important to note is that the first element must be less than the second. The order of pairs in your result should follow the order in
# which they appear in the input lists. For instance, given the lists [1, 3, 7] and [2, 8, 9], the function should return [(1, 2), (1, 8),
# (1, 9), (3, 8), (3, 9), (7, 8), (7, 9)]. It's a challenge if no pairs exist, or if any input list is empty. Let's dissect this task to
# unravel the solution together!
def find_valid_pairs(list1, list2):
    result = []
    for i in list1:
        for j in list2:
            if i < j:
                result.append((i, j))
    return result


# You are provided with two arrays of unique integers, with the lengths of arrays ranging from 1 to 100, inclusive. The task requires you
# to identify elements that appear in both arrays and return them in an array, maintaining the order from the first provided array. Each
# array's element ranges from -100 to 100, inclusive. In your function common_elements(listA, listB), listA and listB represent the two
# input arrays. The function should return an array that includes the common elements found in both listA and listB, while preserving the
# order of elements as they appear in listA. For example, if listA = [7, 2, 3, 9, 1] and listB = [2, 3, 7, 6], the output should be [7, 2,
# 3].

def common_elements(listA, listB):
    result = []
    for i in range(len(listA)):
        for j in range(len(listB)):
            if listA[i] == listB[j]:
                result.append(listA[i])
    return result

from typing import List

def common_elements_List(listA: List[int], listB: List[int]) -> List[int]:
    setB = set(listB)  # Convert listB to a set for O(1) lookups
    return [x for x in listA if x in setB]


# You are given two lists: sourceArray and searchArray, consisting of n and m tuples respectively, where n is an integer such that
# 1 ≤ n ≤ 100 and m is an integer such that 1 ≤ m ≤ 500. Each tuple in both arrays contains two elements: an integer identifier and a
# string. The identifiers in both arrays range from 1 to 100, inclusive. The strings in sourceArray consist of alphanumeric characters
# with lengths ranging from 1 to 100, inclusive. The strings in searchArray have lengths ranging from 1 to 500, inclusive.Your task is to
# implement a function stringSearch(sourceArray, searchArray) that takes these two arrays as input and returns an array that includes all
# tuples from sourceArray for which its string is a substring of at least one string in any tuple from searchArray and the identifier of
# the source tuple is less than or equal to the identifier of the search tuple. The order in which the tuples appear in the result should
# reflect their original order in the sourceArray. If no matches are found, the function should return an empty array.
# For example, if sourceArray = [(1, 'abc'), (2, 'def'), (3, 'xyz')] and searchArray = [(1, 'abcdef'), (5, 'uvwxy')], the function should
# return [(1, 'abc')] since 'abc' and 'def' are substrings found in 'abcdef', but 'def' is associated with 2 in sourceArray which is not
# less than or equal to 1 in searchArray. The string 'xyz' is not found in either 'abcdef' or 'uvwxy', so it is not included in the result.
# This task requires mastery of skills in nested looping and array manipulation, especially in the context of searching for a string within
# other strings.

from typing import List, Tuple


def stringSearch(
        sourceArray: List[Tuple[int, str]],
        searchArray: List[Tuple[int, str]]
) -> List[Tuple[int, str]]:
    result = []

    for src_id, src_str in sourceArray:
        for search_id, search_str in searchArray:
            if src_id <= search_id and src_str in search_str:
                result.append((src_id, src_str))
                break  # Stop after first match (we only need one)

    return result

# You are given two lists of integers (listA and listB), each containing n elements, with n ranging from 1 to 50. Each element in both
# lists can range from -1000 to 1000, inclusive. Your task is to write a Python function that identifies pairs of integers {a, b} wherein
# a belongs to listA and b belongs to listB, and a is greater than b. The function should return all such pairs in the order in which a
# appears in listA. For instance, if listA consists of [5, 1, 8, -2, 0] and listB comprises [3, 2, 7, 10, -1], the output should be [(5, 3)
# , (5, 2), (5, -1), (1, -1), (8, 3), (8, 2), (8, 7), (8, -1), (0, -1)]. Importantly, the order of elements in the output tuples should
# reflect the sequence in which a appears in listA. A pair cannot be included more than once. If no pair meets the condition, the function
# should return an empty list.
# Hint: Solving this task requires the use of nested loops. The outer loop should iterate through listA and the inner loop through listB,
# checking the condition a > b during each iteration.

from typing import List, Tuple

def greater_pairs(listA: List[int], listB: List[int]) -> List[Tuple[int, int]]:
    """
    Return all pairs (a, b) such that a ∈ listA, b ∈ listB, and a > b.
    The pairs appear in the order each a shows up in listA, preserving
    the original order of b’s within listB.  No duplicate pairs are returned.

    Parameters
    ----------
    listA, listB : List[int]
        Lists of integers (1 ≤ len ≤ 50, values –1000 … 1000).

    Returns
    -------
    List[Tuple[int, int]]
        All qualifying (a, b) pairs, ordered by appearance of a’s.
    """
    result: List[Tuple[int, int]] = []
    seen: set[Tuple[int, int]] = set()          # prevent duplicates

    for a in listA:                             # outer loop keeps order of a
        for b in listB:                         # inner loop scans every b
            if a > b and (a, b) not in seen:    # condition + de-duplication
                result.append((a, b))
                seen.add((a, b))

    return result


# You will be given two arrays of integers. The first array has n elements, and the second array has k elements. Sizes n and k both range
# from 1 to 100, inclusive. The elements of both arrays can fall within a range of -100 to 100, inclusive. Your task is to write a Python
# function that will locate and return an array of all pairs of integers with the property that the first element of each pair comes from
# the first array and the second element of each pair comes from the second array, such that the sum of the two elements of the pair is a
# perfect square. A perfect square, as you know, is an integer that is the square of another integer.
# The order of pairs in your output should correspond to the order of the elements in the input arrays. For example, if the two arrays are
# [2, 3, 16] and [1, 9, 10], the function should return [(3, 1), (16, 9)] because 3+1=4 (which is the square of 2) and 16+9=25 (which is
# the square of 5). If no such pairs exist, or if either input array is empty, your function should return an empty list.

from typing import List, Tuple


def is_perfect_square(num: int) -> bool:
    if num < 0:
        return False
    root = int(num ** 0.5)
    return root * root == num


def perfect_square_pairs(arr1: List[int], arr2: List[int]) -> List[Tuple[int, int]]:
    result = []

    for a in arr1:
        for b in arr2:
            if is_perfect_square(a + b):
                result.append((a, b))

    return result

# Here is a detailed look at our task: We will work with a string that represents a sentence in which words are separated by spaces. Your
# task is to create a Python function that identifies the odd-indexed characters of words that have an even number of characters. Then,
# combine these characters into a single string, maintaining the order in which they appear in the sentence. Let's consider an example to
# foster a deep understanding: "Python is a high-level programming language." Here, the word 'Python' has 6 characters (an even number),
# and we will select the odd-indexed characters from this word, specifically, 'y', 'h', and 'n'. Similarly, we select 's' from 'is', and
# 'i', 'h', 'l', 'v', 'l' from 'high-level'. The words 'a', 'programming', and 'language.' have odd lengths, so they are skipped.
# So, if our function is working correctly, it should return "yhnsihlvl". This task highlights the versatility of loops and conditionals
# in solving all kinds of string challenges!

def extract_odd_index_chars(sentence):
    words = sentence.split(' ')
    result = ''
    for word in words:
        if len(word) % 2 == 0:  # check if the length of word is even
            for i in range(1, len(word), 2):  # loop over odd characters
                result += word[i]
    return result

# In this task, we are manipulating sentences and strings using nested loops. You will be given a string representing a sentence where
# words are separated by spaces. Your objective is to write a Python function that selects the even-indexed characters of words containing
# an odd number of characters. This sentence string will have a maximum length of 500 characters, including spaces.
# Subsequently, these characters must be combined into a single string in the order they appear in the sentence, but the final output
# string will be reversed end-to-end. For instance, if the input sentence is "Coding tasks are fun and required", the output string should
# be "tssaefnad", which, when reversed, becomes "danfeasst". The words "tasks", "are", "fun", and "and" are selected since they have an odd
# number of characters, and the characters 't', 's', 's', 'a', 'e', 'f', 'n', 'a', 'd' at even indexes are chosen and then reversed in the
# final string. Do not forget that Python indexing begins at 0, so 't' in "tasks" is considered to be at an even index. Single-character
# words must also be taken into consideration for this task.

def process_sentence(sentence: str) -> str:
    result_chars = []

    for word in sentence.split():
        if len(word) % 2 == 1:  # Word has an odd number of characters
            for i in range(0, len(word), 2):  # Take even-indexed characters
                result_chars.append(word[i])

    return ''.join(result_chars)[::-1]  # Reverse the final string


# You are given a string of n words, with n ranging from 1 to 100, inclusive. The words are separated by a single space in the string. Your
# task is to return the most frequently occurring character in each word that has an odd number of characters. The resulting characters
# should be concatenated into a string with their occurrences in the sentence. Please note: Each word's character count ranges from 1 to
# 500, inclusive. The string contains lowercase and uppercase alphanumeric characters, spaces, and punctuation.
# For instance, if the input string is "Hello world this is a demo string", your function should return "lwa". In this string, 'Hello',
# 'world', and 'a' have an odd number of characters. The most frequently occurring character in these words are 'l', 'w', and 'a'
# respectively. When concatenated, they form "lwa". In case of a tie in character frequency, return the character that appears first in the
# word. In the example above, we took 'w' from the word 'world'. The function should be case insensitive. The lowercase and uppercase
# characters should be counted as the same character. The output should only contain lowercase characters. For example: "Hhi" should return
# "h" because "h" appears twice in the string even though one is uppercase and one is lowercase.
# If there are no words with an odd number of characters in the input string, your function should return an empty string.
# The input string will always be at least one character long, and it cannot be just a single whitespace. Having a good understanding of
# string operations and the use of nested loops is very useful in solving this task.

from collections import Counter


def most_frequent_chars_odd_words(sentence: str) -> str:
    result = []

    for word in sentence.split():
        if len(word) % 2 == 1:
            lower_word = word.lower()
            freq = Counter(lower_word)

            max_freq = max(freq.values())
            # Find the first character in the word that has the max frequency
            for char in lower_word:
                if freq[char] == max_freq:
                    result.append(char)
                    break

    return ''.join(result)


# You are given a string that represents a sentence in which words are separated by spaces. Your task is to create a Python function that
# identifies and concatenates the second half of each word with an even number of characters, ensuring the characters of this second half
# go before the character c in the ASCII table. Then, combine these characters into a single string, maintaining the order in which they
# appear in the sentence.The input sentence consists of ASCII characters from the space character (' ') up to the tilde character ('~'),
# with its length ranging between 1 and 500, inclusive. These characters form words separated by spaces, without any consecutive space
# characters. For example, consider the sentence: "Python is a high-level programming language." and the character "n". The word 'Python'
# consists of 6 characters (an even number), and the second half of this word is 'hon'. In this second half, only 'h' is less than 'n'.
# The output of your function, in this case, should be: "h", as it's the only character that meets the conditions. For the character
# comparison ('<' character), use the ASCII values since all characters in the sentence are ASCII. ASCII codes for characters can be found
# by using Python's built-in function ord().

def collect_half_chars_before_c(sentence: str, c: str) -> str:
    result = []
    for word in sentence.split():
        if len(word) % 2 == 0:
            half = word[len(word) // 2:]  # second half of the word
            for ch in half:
                if ord(ch) < ord(c):
                    result.append(ch)
    return ''.join(result)

sentence = "Python is a high-level programming language."
char = 'n'

# In this "Move Until Obstacle" game, the player begins at the start of a linear array of integers. The number at each position indicates
# the number of steps a player can move rightward, while an obstacle number is one upon which you can't land. The aim is to move as far
# right as possible until an obstacle stops you or you reach the array's end. Your function, solution(numbers, obstacle), needs to tally
# and return the number of moves needed to reach the array's end without encountering an obstacle. If the player encounters an obstacle,
# then the function should return the index at which the obstacle lies.
# For example, if the function is given the input: numbers = [2, 3, 3, 4, 2, 4] and obstacle = 4, it should return 5. This is because the
# player starts on the 0th index, takes 2 steps as indicated by the number at the 0th index (landing on the 2nd index), and then takes 3
# more steps as indicated by the number at the 2nd index to land on the 5th index, which is the obstacle 4. If the function is given the
# input: numbers = [4, 1, 2, 2, 4, 2, 2] and obstacle = 2, the output should be 2. The player starts on the 0th index, takes 4 steps,
# lands on the 4th index, then takes 4 more steps, which brings the player outside the array, so in total the player makes 2 moves.

def move_until_obstacle(numbers, obstacle):
    position = 0
    moves = 0
    while position < len(numbers):
        if numbers[position] == obstacle:
            return position
        moves += 1
        position += numbers[position]
    return moves


# You are given an array of n integers, ranging from 1 to 100 inclusive. Each integer represents a player's progress on a linear gameboard,
# indicating how many steps they can move to the right. However, the course is fraught with challenges; there exist several obstacles,
# represented by negative integers. Your task is to return a transformed array structuring the gameboard in a new way: if an integer can
# lead the player to an obstacle on its right (within the range of its value), replace the number with the index of the obstacle. If the
# number represents an obstacle (a negative integer), replace it with -1. If none of these conditions are met, retain the original integer.
# Keep in mind, this task is an innovative take on our previous analysis lesson, implementing a "Move Until Obstacle" game. Remember, your
# array will have no more than 500 elements, and the elements in the array range from -100 to 100, inclusive. Good luck with your coding
# journey! For instance, given an array [3, 2, -3, 1, 2], the output would be [2, 2, -1, 1, 2].
# Here's how it works:
# Replace the first position with 2 because a player at the first position can move 3 steps but will hit the obstacle at the 2nd index.
# Replace the second position with 2 because a player at the second position can move 2 steps but will hit the obstacle at the 2nd index.
# Replace the negative number -3 at the third position with -1 because it represents an obstacle.
# Keep the number 1 at the fourth position as there are no obstacles in its range.
# Keep the number 2 at the fifth position as there are no further positions or obstacles to impact it.

def transform_gameboard(arr):
    result = []
    n = len(arr)
    for i in range(n):
        if arr[i] < 0:
            result.append(-1)  # It's an obstacle
        else:
            obstacle_index = -1
            # Check the next `arr[i]` steps
            for j in range(1, arr[i] + 1):
                if i + j < n and arr[i + j] < 0:
                    obstacle_index = i + j
                    break
            result.append(obstacle_index if obstacle_index != -1 else arr[i])
    return result


# Your task is to design a 1-dimensional game where a player moves along a path determined by an array of integers.
# The path is an array of integers, each ranging from -100 to 100, inclusive. The size of the array n, i.e., the total number of steps on
# the path, can range from 1 to 500, inclusive. Each integer a_i in the array signifies how many steps the player can move and in which
# initial direction: A positive integer allows the player to move that many steps to the right. A negative integer directs the player to
# move that many steps to the left. Zero signifies a blockade that prevents further movement.
# The game proceeds along the following rules: The player starts at the first position of the array (0-indexed) and moves according to the
# value at the player's current position in the array. If the value in the current position is zero, then the game ends. If the player's
# current position leads them outside of the array's boundaries, then their ability to move in the current direction ceases.
# If the latter happens, then the player reverses their direction and continues to move according to similar rules, but now the directions
# are inverted: positive integers lead the player to the left, and negative integers point to the right.
# The game ends when the player encounters a blockade or the array boundaries for the second time and so can no longer move.
# You are to implement a function titled evaluatePath(numbers). This function should take an array of integers as input, representing the
# path and its rules, and return a tuple (position, moves), where:
# position: This is the player's final position (0-indexed) when the game ends.
# moves: This is the total number of moves made by the player until the game ends.
# It's guaranteed that the game will not lead to an infinite loop, i.e. the path to the next blockade or the array boundaries would not
# require the player to visit the same position more than once. For instance, given an array [3, 4, 1, 1, -3, 1]. The output would be
# (4, 5). Here's how it works:
# The player starts at position 0, where the value is 3. They move 3 steps to the right and land on the 3rd position. Total moves till now:
# 1.At position 3, the value is 1. They move 1 step to the right, landing on the 4th position. Total moves till now: 2. At position 4, the
# value is -3. They move 3 steps to the left, landing back on position 1. Total moves meanwhile: 3. At position 1, the value is 4. They
# move 4 steps to the right, landing on position 5. Total moves thus far: 4. At position 5, the value is 1, which would lead them out of
# the array's right boundary. So, they reverse their direction. After reversing direction at position 5, they move 1 step to the left and
# land on position 4. Total moves till now: 5. Now, with the reversed direction, the player is at position 4 where the value is -3. In the
# reversed direction, -3 indicates 3 steps to the right. But this would again lead to the right boundary of the array. Since they have
# already reversed direction once, they cannot move further in any direction and the game ends. At the end of the game, the player is at
# position 4 having made a total of 5 moves, thereby, the function returns (4, 5).

def evaluatePath(numbers):
    n = len(numbers)
    position = 0
    moves = 0
    reversed_direction = False

    while True:
        value = numbers[position]

        # Stop if current position is a blockade
        if value == 0:
            break

        # Determine direction
        steps = value
        if reversed_direction:
            steps = -steps

        next_position = position + steps

        # If within bounds, make the move
        if 0 <= next_position < n:
            position = next_position
            moves += 1
        else:
            # If out of bounds and already reversed, stop
            if reversed_direction:
                break
            # Reverse direction
            reversed_direction = True
        # Loop continues

    return (position, moves)

# You are the developer of a unique board game and you need to calculate how many moves a player has to make, assuming different starting
# positions. The game is played on a linear board represented by an array of positive integers. The length of the board can range from 1 to
# 500 inclusive. Each position on the board represents the number of steps a player can make from that position. The player can only move
# towards the end of the board. The board can contain obstacles on which the player cannot land, defined by a specific integer value. The
# game ends when the player exits the board or lands on an obstacle. Your task is to implement the solution(board, obstacle) function,
# which returns an array moves. For every i in moves, the algorithm should calculate the number of moves required for a player to exit the
# board, while starting from the i-th position, without landing on an obstacle. If the player encounters an obstacle, moves[i] should be
# set to -1. The value of obstacle as well as each value in the board array ranges from 1 to 10 inclusive.
# For example, solution([5, 3, 2, 6, 2, 1, 7], 3) should return [3, -1, 3, 1, 2, 2, 1]. The moves array is calculated as follows:moves[0]
# should be 3 because: The player starts on board[0] = 5 The player then moves 5 places on to board[5] = 1 Then the player moves 1 place
# to board[6] = 7 And, finally, the player moves to exit the board, making it a total of 3 moves moves[1] should be -1 because:
# The player starts on the board[1] = 3 which is equal to obstacle And so on...

def move_counter_with_obstacle(board, obstacle):
    n = len(board)
    result = []

    for start in range(n):
        pos = start
        moves = 0
        visited = set()

        while pos < n:
            if board[pos] == obstacle:
                moves = -1
                break
            if pos in visited:
                # safeguard from infinite loops (not strictly needed for this problem)
                moves = -1
                break
            visited.add(pos)
            steps = board[pos]
            pos += steps
            moves += 1

        result.append(moves)

    return result


def isSubsequence(s: str, t: str) -> bool:
    i = 0  # Pointer for s
    for char in t:
        if i < len(s) and s[i] == char:
            i += 1
    return i == len(s)


# For this task, you are given two non-negative integers, num1 and num2. However, these are not just ordinary numbers; they are so large
# that they should be represented as strings instead of normal integers. Each can be up to 100 digits long. Your mission is to write a
# Python function that compares these two "string-numbers" without converting the entire strings into integers. Your function should
# determine whether num1 is greater than, less than, or equal to num2. Your function can only use comparison operators (such as >, <,
# or ==) on strings. So “1” < “2” is allowed, but 1 < 2 is not. The task requires that you manually compare the two strings from the most
# significant digit to the least significant. You should implement your own logic to compare two string numbers. The function should return
# the following results:
# If num1 is greater than num2, your function should return 1.
# If num2 is greater than num1, your function should return -1.
# If num1 and num2 are equal, your function should return 0.
# Let's look at the following examples:
# For `num1` = '12345' and `num2` = '1234', your function should return `1`.
# For `num1` = '1234' and `num2` = '12345', your function should return `-1`.
# For `num1` = '12345' and `num2` = '12345', your function should return `0`.
# This exercise is a great test of your understanding of how numbers and strings work and interact in a programming language. We hope you
# find it challenging and enjoyable!

def compareStringNumbers(num1: str, num2: str) -> int:
    # Remove leading zeros (optional, if you want to normalize)
    num1 = num1.lstrip('0') or '0'
    num2 = num2.lstrip('0') or '0'

    # Step 1: Compare by length
    if len(num1) > len(num2):
        return 1
    elif len(num1) < len(num2):
        return -1

    # Step 2: Compare digit by digit
    for d1, d2 in zip(num1, num2):
        if d1 > d2:
            return 1
        elif d1 < d2:
            return -1

    # Step 3: Equal case
    return 0


# You are given two exceedingly large positive decimal numbers, num1 and num2, both represented as strings. The length of these strings
# can range anywhere from 1 to 500 characters. The challenge here is to subtract num2 from num1 without directly converting the strings
# into integers. Create a Python function that performs this operation and returns the resultant string, referred to as num3.
# Please note that the subtraction will not result in a negative number, as num1 will always be greater than or equal to num2.

def subtract_large_numbers(num1: str, num2: str) -> str:
    # Pad num2 with leading zeros to match the length of num1
    num2 = num2.zfill(len(num1))

    result = []
    borrow = 0

    # Start from the least significant digit (rightmost)
    for i in range(len(num1) - 1, -1, -1):
        digit1 = int(num1[i])
        digit2 = int(num2[i])

        diff = digit1 - digit2 - borrow

        if diff < 0:
            diff += 10
            borrow = 1
        else:
            borrow = 0

        result.append(str(diff))

    # The result is currently reversed
    result = ''.join(reversed(result)).lstrip('0')

    return result if result else '0'

# You are tasked with writing a Python function to multiply two extremely large positive integers. These are not your regular-sized large
# numbers; they are represented as strings potentially up to 500 digits long. Your function should take two string parameters, representing
# the two large integers to be multiplied, and return the product as a string. The challenging part is that you should perform the multiplication
# without converting the entire strings into integers. Keep in mind that the elements of the string are digits in the range from 0 to 9,
# inclusive. Furthermore, bear in mind that when multiplying numbers manually, we align the numbers vertically and multiply each digit of
# the first number with each digit of the second number, starting from the rightmost digits, and add the results after shifting appropriately.
# Please solve this problem using similar, decision-based string manipulations instead of merely converting strings into integers, multiplying
# them, and converting the result back to a string. This approach is imperative as direct multiplication would not be feasible for very large
# numbers. Challenge yourself, and Happy Coding!

def multiply_large_numbers(num1: str, num2: str) -> str:
    # Early return for zero multiplication
    if num1 == "0" or num2 == "0":
        return "0"

    # Initialize the result array with zeros
    result = [0] * (len(num1) + len(num2))

    # Reverse both numbers to simulate manual multiplication from right to left
    num1 = num1[::-1]
    num2 = num2[::-1]

    # Multiply each digit from num1 with each from num2
    for i in range(len(num1)):
        for j in range(len(num2)):
            digit1 = ord(num1[i]) - ord('0')
            digit2 = ord(num2[j]) - ord('0')
            product = digit1 * digit2

            # Add the product to the current position
            result[i + j] += product

            # Carry over to the next digit
            result[i + j + 1] += result[i + j] // 10
            result[i + j] = result[i + j] % 10

    # Remove any leading zeros
    while len(result) > 1 and result[-1] == 0:
        result.pop()

    # Convert the result array back to a string
    result_str = ''.join(str(digit) for digit in reversed(result))
    return result_str


if (__name__ == "__main__"):
    print(find_valid_pairs([1, 3, 7], [2, 8, 9]))
    listA = [7, 2, 3, 9, 1]
    listB = [2, 3, 7, 6]
    print(common_elements(listA, listB))
    print(common_elements_List(listA, listB))
    sourceArray = [(1, 'abc'), (2, 'def'), (3, 'xyz')]
    searchArray = [(1, 'abcdef'), (5, 'uvwxy')]
    print(stringSearch(sourceArray, searchArray))
    listA = [5, 1, 8, -2, 0]
    listB = [3, 2, 7, 10, -1]
    print(greater_pairs(listA, listB))
    arr1 = [2, 3, 16]
    arr2 = [1, 9, 10]
    print(perfect_square_pairs(arr1, arr2))
    print(extract_odd_index_chars("Python is a high-level programming language."))
    print(process_sentence("Coding tasks are fun and required"))
    print(most_frequent_chars_odd_words("Hello world this is a demo string"))
    print(collect_half_chars_before_c(sentence, char))
    print(collect_half_chars_before_c("Practice makes perfect.", 'f'))
    numbers = [4, 1, 2, 2, 4, 2, 2]
    obstacle = 2
    print(move_until_obstacle(numbers, obstacle))  # Output: 2
    arr = [3, 2, -3, 1, 2]
    print(transform_gameboard(arr))
    evaluatePath([3, 4, 1, 1, -3, 1])  # Output: (4, 5)
    print(move_counter_with_obstacle([5, 3, 2, 6, 2, 1, 7], 3)) # Output: [3, -1, 3, 1, 2, 2, 1]
    # input s = "abc" , t = "ahbgdc"
    # output : true
    # input s = "axc" , t = "ahbgdcx"
    # output : false
    # input s = "zgc" , t = "zhgdc"
    # output : true
    print(isSubsequence("abc", "ahbgdc"))
    print(isSubsequence("axc", "ahbgdcx"))
    print(isSubsequence("zgc", "zhgdc"))
    print(compareStringNumbers("12345", "1234"))  # Output: 1
    print(compareStringNumbers("1234", "12345"))  # Output: -1
    print(compareStringNumbers("12345", "12345"))  # Output: 0
    print(compareStringNumbers("0000123", "123"))  # Output: 0
    print(compareStringNumbers("00000001", "1"))  # Output: 0
    print(subtract_large_numbers("987654321987654321", "123456789123456789"))
    # Output: "864197532864197532"
    print(multiply_large_numbers("123456789", "987654321"))
    # Output: "121932631112635269"


