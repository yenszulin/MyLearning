
# Here is a detailed look at our task: We will work with a string that represents a sentence in which words are separated by spaces. Your
# task is to create a Python function that identifies the odd-indexed characters of words that have an even number of characters. Then,
# combine these characters into a single string, maintaining the order in which they appear in the sentence. Let's consider an example to
# foster a deep understanding: "Python is a high-level programming language." Here, the word 'Python' has 6 characters (an even number),
# and we will select the odd-indexed characters from this word, specifically, 'y', 'h', and 'n'. Similarly, we select 's' from 'is', and
# 'i', 'h', 'l', 'v', 'l' from 'high-level'. The words 'a', 'programming', and 'language.' have odd lengths, so they are skipped.
# So, if our function is working correctly, it should return "yhnsihlvl". This task highlights the versatility of loops and conditionals
# in solving all kinds of string challenges!

def extract_odd_index_chars(sentence):
    words = sentence.split(' ')
    result = ''
    for word in words:
        if len(word) % 2 == 0:  # check if the length of word is even
            for i in range(1, len(word), 2):  # loop over odd characters
                result += word[i]
    return result

if (__name__ == "__main__"):
    print(extract_odd_index_chars("Python is a high-level programming language."))
