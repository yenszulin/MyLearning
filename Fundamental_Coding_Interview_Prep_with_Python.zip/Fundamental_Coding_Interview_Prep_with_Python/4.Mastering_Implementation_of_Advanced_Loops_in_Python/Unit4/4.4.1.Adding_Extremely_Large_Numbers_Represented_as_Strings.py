# In today's task, we'll step into the world of large numbers, where, specifically, we are given two
# exceedingly large positive integers. However, these aren't your average, everyday large numbers.
# They are so vast they're represented as strings that can be up to 10,000 digits long!
#
# Accepting our mission means writing a Python function that binds these two "string-numbers" together.
# The challenge is to perform the addition without converting the entire strings into integers.
#
# Finally, our function should return the resulting sum, represented as a string. While it might seem
# daunting at first, don't worry -- we'll break it down step by step, mimicking how we manually add numbers.

def addLargeNumbers(num1, num2):
    i, j, carry, res = len(num1) - 1, len(num2) - 1, 0, []

    while i >= 0 or j >= 0 or carry > 0:
        n1 = int(num1[i]) if i >= 0 else 0
        n2 = int(num2[j]) if j >= 0 else 0
        total = n1 + n2 + carry
        if total > 9:
            carry = 1
        else:
            carry = 0
        curr = total % 10
        res.append(str(curr))
        i, j = i - 1, j - 1

    return ''.join(res[::-1])  # reverse the list and join into a single string

if (__name__ == "__main__"):
    print(addLargeNumbers("123456789123456789", "987654321987654321"))
    # Output: "1111111111111111110"