# You are given two exceedingly large positive decimal numbers, num1 and num2, both represented as strings. The length of these strings
# can range anywhere from 1 to 500 characters. The challenge here is to subtract num2 from num1 without directly converting the strings
# into integers. Create a Python function that performs this operation and returns the resultant string, referred to as num3.
# Please note that the subtraction will not result in a negative number, as num1 will always be greater than or equal to num2.

def subtract_large_numbers(num1: str, num2: str) -> str:
    # Pad num2 with leading zeros to match the length of num1
    num2 = num2.zfill(len(num1))

    result = []
    borrow = 0

    # Start from the least significant digit (rightmost)
    for i in range(len(num1) - 1, -1, -1):
        digit1 = int(num1[i])
        digit2 = int(num2[i])

        diff = digit1 - digit2 - borrow

        if diff < 0:
            diff += 10
            borrow = 1
        else:
            borrow = 0

        result.append(str(diff))

    # The result is currently reversed
    result = ''.join(reversed(result)).lstrip('0')

    return result if result else '0'

if (__name__ == "__main__"):
    print(subtract_large_numbers("987654321987654321", "123456789123456789"))
    # Output: "864197532864197532"


