def run():
    # List of fruits to be used in fruit salad
    fruits = ['apple', 'banana', 'kiwi', 'mango']

    # TODO: Loop over the list of fruits and add them to the fruit salad with a print statement
    for fruit in fruits:
        # TODO: Print a statement for adding each fruit to the fruit salad.
        print(f"Adding {fruit} to the fruit salad.")

if __name__ == "__main__":
    run()