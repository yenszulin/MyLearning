def run():
    # List of fruits to include in a fruit salad
    fruits = ['apple', 'banana', 'orange', 'kiwi', 'melon']

    # # Using a for loop to iterate over the list of fruits
    # for fruit in fruits:
    #     print(f"Adding {fruit} to the salad.")
    # Using a for loop to iterate over the list of fruits
    index = 0
    while index < len(fruits):
        print(f"Adding {fruits[index]} to the salad.")
        index += 1


if __name__ == "__main__":
    run()