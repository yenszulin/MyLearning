def run():
    friends = ['Alice', 'Bob', 'Charlie', 'Daniel']
    # `friend` is the loop variable, taking each name in the `friends` list
    for friend in friends:
        # for each `friend`, this line is executed
        print(f"Hello, {friend}! Nice to meet you.")
    """
    Prints:
    Hello, Alice! Nice to meet you.
    Hello, Bob! Nice to meet you.
    Hello, Charlie! Nice to meet you.
    Hello, Daniel! Nice to meet you.
    """

    # `num` runs through each number in the range of 5
    for num in range(5):
        # This line will print numbers from 0 to 4
        print(num)


    num = 0
    # The loop keeps running until num is greater than or equal to 5
    while num < 5:
        print(num)
        # increase num by 1 each iteration
        num += 1

    # list of fruits
    fruits = ['apple', 'banana', 'cherry']
    # `fruit` stands for each fruit in the `fruits` list
    for fruit in fruits:
        print(fruit) # prints each fruit

    word = 'hello'
    # `letter` is each individual character in the `word`
    for letter in word:
        print(letter) # prints each letter in 'hello'

    # List of numbers
    numbers = [1, 2, 3, 4, 5]
    total = 0
    # `num` is each number in `numbers`
    for num in numbers:
        total += num # add each number in the list
    print(total) # prints the total sum

    # string
    text = 'hello'
    vowel_count = 0
    # `letter` is each character in `text`
    for letter in text:
        # If a vowel letter is found, increment the count
        if letter in 'aeiou':
            vowel_count += 1
    print(vowel_count)  # prints the count of vowels


if __name__ == "__main__":
    run()