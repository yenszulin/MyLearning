def run():
    # Define a string named 'word' to represent the phrase we'll work with
    word = 'FRUIT Salad'

    # TODO: Initialize a counter to hold the number of non-vowel characters
    non_vowel_count = 0

    # TODO: Use a 'for' loop to iterate over each character in the string
    for char in word:

        # TODO: Inside the loop, write a condition to check if it's not a vowel or a space
        # Don't forget that letters can be lowercase and uppercase
        # Check if it's not a vowel or a space (case-insensitive)
        if char.lower() not in ['a', 'e', 'i', 'o', 'u', ' ']:
            # TODO: If the condition is true, increase the counter for non-vowel characters
            # If the condition is true, increase the counter
            non_vowel_count += 1

    # TODO: Finally, print out the count of non-vowel characters
    print("Non-vowel character count:", non_vowel_count)

if __name__ == "__main__":
    run()