def run():
    # List of fruits for the fruit salad
    fruits = ["apple", "banana", "cherry", "kiwi", "mango"]
    # Count the number of fruits in the salad
    fruit_count = 0
    # Loop over each fruit in the fruits list
    for fruit in fruits:
        # The wrong operator is used here, it should increase the count
        # fruit_count = 1
        # Increase the count correctly
        fruit_count += 1
    print(fruit_count)  # This should print the total number of fruits in the salad


if __name__ == "__main__":
    run()