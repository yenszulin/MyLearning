def run():
    sentence = 'Python is fun!'
    words = sentence.split()  # no delimiter provided, splitting by whitespace
    print(words)  # Output: ['Python', 'is', 'fun!']

    data = 'John,Doe,35,Engineer'
    info = data.split(',')  # provided a ',' delimiter
    print(info)  # Output: ['John', 'Doe', '35', 'Engineer']

    words = ['Programming', 'with', 'Python', 'is', 'exciting!']
    sentence = ' '.join(words)
    print(sentence)  # Output: 'Programming with Python is exciting!'

    name = '    John Doe    \t\n'
    name = name.strip()
    print(name)  # Output: 'John Doe'


    name = '    John Doe    '
    print(name.lstrip())  # Output: 'John Doe    '
    print(name.rstrip())  # Output: '    John Doe'


if __name__ == "__main__":
    run()