def run():

    # Simple example of a list
    example_list = [1, 2, 3, 4, 5]
    print(example_list[0])  # Outputs: 1


if __name__ == "__main__":
    run()