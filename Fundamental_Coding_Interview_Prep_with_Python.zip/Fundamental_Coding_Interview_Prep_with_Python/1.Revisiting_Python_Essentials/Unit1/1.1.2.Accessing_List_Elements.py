def access_elements(my_list):
    # Access and print the first element
    print(my_list[0])

    # Access and print the last element
    print(my_list[-1])


if __name__ == "__main__":
    # Example list
    example_list = [10, 20, 30, 40, 50]
    access_elements(example_list)

    # Expected Output:
    # 10
    # 50