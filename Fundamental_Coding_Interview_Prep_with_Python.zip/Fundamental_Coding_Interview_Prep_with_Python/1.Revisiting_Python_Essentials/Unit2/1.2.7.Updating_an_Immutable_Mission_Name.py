def run():
    # Given mission name
    mission_name = "Sort"

    # TODO: Print the first and the last character of the mission name
    print("First character:", mission_name[0])
    print("Last character:", mission_name[-1])

    # TODO: The mission needs a minor update. We aim to change its first letter to 'P' and the last letter to `k`, obtaining the word "Pork".
    # Remember, strings in Python are immutable, so you cannot alter them directly.
    updated_mission_name = 'P' + mission_name[1:-1] + 'k'

    # TODO: Print the updated mission name
    print("Updated mission name:", updated_mission_name)


if __name__ == "__main__":
    run()