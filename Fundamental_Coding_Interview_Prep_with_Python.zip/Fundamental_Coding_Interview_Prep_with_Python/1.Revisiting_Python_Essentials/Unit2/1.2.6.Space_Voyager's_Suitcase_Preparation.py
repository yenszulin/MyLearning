def run():
    # Initialize an empty list named 'suitcase'
    suitcase = []

    # TODO: Add items to your suitcase
    suitcase.append("shoes")
    suitcase.append("jacket")
    suitcase.append("sunglasses")
    suitcase.append("passport")

    # Declare a string variable for your goodbye message
    # TODO: Assign a farewell message to the variable
    farewell_message = "See you soon! Safe travels!"

    # Access the first and last item in your suitcase
    # TODO: Print the first item in the suitcase
    print("First item:", suitcase[0])
    # TODO: Print the last item in the suitcase
    print("Last item:", suitcase[-1])

    # Send off with a farewell in uppercase
    # TODO: Print the farewell message in uppercase
    print(farewell_message.upper())


if __name__ == "__main__":
    run()