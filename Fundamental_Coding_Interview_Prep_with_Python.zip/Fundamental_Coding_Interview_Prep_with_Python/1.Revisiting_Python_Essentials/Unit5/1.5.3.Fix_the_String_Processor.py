def process_text(text):
    # new_text = ""
    # for char in text:
    #     if char.isalpha:
    #         new_text += char.upper()
    # print(f"Processed Text: {new_text}")

    new_text = ""
    for char in text:
        if char.isalnum():  # check if alphanumeric (letters or digits)
            new_text += char.upper()
    print(f"Processed Text: {new_text}")



if __name__ == "__main__":
    process_text("Happy Coding, Friends! 123")