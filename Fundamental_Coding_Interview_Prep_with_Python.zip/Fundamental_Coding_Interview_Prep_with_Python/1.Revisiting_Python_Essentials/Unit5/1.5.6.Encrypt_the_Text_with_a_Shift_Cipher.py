# TODO: Define a function to encrypt the text using a shift cipher
# The function should take two parameters: the text to encrypt and the shift amount
def encrypt_text(text, shift):
    encrypted = ""
    # TODO: Inside the function, create a loop that goes through each character of the text
    for char in text:
        # TODO: Check if the current character is an alphabetic character
        if char.isalpha():
            if char.islower():
                # TODO: Perform the character shift operation and append the result to the encrypted text
                # Hint: Use 'ord', 'chr', and modulo (%) operations to cyclically shift the letter by `shift`
                # Shift within lowercase letters
                shifted = chr((ord(char) - ord('a') + shift) % 26 + ord('a'))
            else:
                # Shift within uppercase letters
                shifted = chr((ord(char) - ord('A') + shift) % 26 + ord('A'))
            encrypted += shifted
        # TODO: If the character is not alphabetic, add it as is to the encrypted text
        else:
            # Add non-alphabetic characters unchanged
            encrypted += char

    return encrypted


if __name__ == "__main__":
    # TODO: Outside the function, call your `encrypt_text` function with some sample text and a shift value to test it
    # Test the function
    sample_text = "Hello, Python!"
    shift_amount = 1
    encrypted_result = encrypt_text(sample_text, shift_amount)

    print("Original:", sample_text)
    print("Encrypted:", encrypted_result)
