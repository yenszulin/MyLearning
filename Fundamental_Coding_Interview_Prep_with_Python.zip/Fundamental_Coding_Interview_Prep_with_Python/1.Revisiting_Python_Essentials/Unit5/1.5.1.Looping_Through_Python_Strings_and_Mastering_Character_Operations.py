def run():
    text = "Hello, Python!"
    for char in text:
        print(char)
    # Prints:
    # H
    # e
    # l
    # l
    # o
    # ,
    # ...

    try:
        text = "Hello, Python!"
        tenth_char = text[9]
        print('The tenth character is:', tenth_char)
    except IndexError as e:
        print("Char access error message:", e)

    print(ord('A'))  # Prints: 65
    print(chr(65))  # Prints: 'A'
    print(chr(ord('A') + 1))  # Prints: 'B'

    print('mark'.upper())  # Prints: 'MARK'
    print('Mark'.lower())  # Prints: 'mark'

    print("C".isalpha())  # Prints: True
    print("C++".isalpha())  # Prints: False
    print("239".isdigit())  # Prints: True
    print("C239".isdigit())  # Prints: False
    print("C98".isalnum())  # Prints: True
    print("C98++".isalnum())  # Prints: False


if __name__ == "__main__":
    run()