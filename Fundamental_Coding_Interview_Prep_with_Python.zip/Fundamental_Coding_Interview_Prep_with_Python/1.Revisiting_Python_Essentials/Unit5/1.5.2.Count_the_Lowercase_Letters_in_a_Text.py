def run():
    # text = "Python is fun!"
    # cleaned_text = ""
    #
    # for char in text:
    #     if char.islower():
    #         cleaned_text += char.upper()
    #     elif char.isupper():
    #         cleaned_text += char.lower()
    #     else:  # Keep non-alphabetical characters unchanged
    #         cleaned_text += char
    #
    # print(cleaned_text)  # Initially outputs: "pYTHON IS FUN!"

    text = "Python is fun!"
    lowercase_count = 0

    for char in text:
        if char.islower():
            lowercase_count += 1

    print(lowercase_count)  # Prints the number of lowercase characters


if __name__ == "__main__":
    run()