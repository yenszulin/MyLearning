# Defining a list and a string
def string_list():
    my_list = [1, 2, 3, 4]
    my_string = 'hello'

    # Now let's try to change the first element of both these collections
    my_list[0] = 100
    # Uncommenting the below line will throw an error
    # my_string[0] = 'H'
    print(my_string[0])

########################################################################################################################################################################

# Creating a list
def introduce_list():
    fruits = ['apple', 'banana', 'cherry']

    # Add a new element at the end
    fruits.append('date') # ['apple', 'banana', 'cherry', 'date']

    # Inserting an element at a specific position
    fruits.insert(1, 'bilberry') # ['apple', 'bilberry', 'banana', 'cherry', 'date']

    # Removing a particular element
    fruits.remove('banana') # ['apple', 'bilberry', 'cherry', 'date']

    # Accessing elements using indexing
    first_fruit = fruits[0] # apple
    last_fruit = fruits[-1] # date

########################################################################################################################################################################

# Creating a string
def introduce_string():
    greeting_string = "Hello, world!"

    # Accessing characters using indexing
    first_char = greeting_string[0]  # 'H'
    last_char = greeting_string[-1]  # '!'

    # Making the entire string lowercase
    lowercase_greeting = greeting_string.lower()  # 'hello, world!'

########################################################################################################################################################################

def slicing_list_string():
    # Define a list and a string
    my_list = [1, 2, 3, 4, 5]
    my_string = "Hello"

    # Slicing: my_list[start:end], `start` inclusive, `end` exclusive
    slice_list = my_list[2:4] # [3, 4]
    slice_string = my_string[1:3] # "el"

    # Concatenation: my_list + another_list
    concatenate_list = my_list + [6, 7, 8] # [1, 2, 3, 4, 5, 6, 7, 8]
    concatenate_string = my_string + ", world!" # "Hello, world!"

    # Repetition: my_list * n #
    repeat_list = my_list * 2 # [1, 2, 3, 4, 5, 1, 2, 3, 4, 5]
    repeat_string = my_string * 2 # "HelloHello"

    # Finding the first occurrence of an element in a list or a string
    # Note that if the element is not found, `index` throws an exception
    # So we should initially check the existence by the operator `in`,
    # Then use the `index` method if it exists using the `if-else` construction.
    # If the element is not found, the indices are assigned to `-1`
    found_1_in_list = 1 in my_list # Returns: True
    found_8_in_list = 8 in my_list # Returns: False
    found_in_string = 'l' in my_string.lower() # Returns True
    index_1_in_list = my_list.index(1) if found_1_in_list else -1 # Returns: 0
    index_8_in_list = my_list.index(8) if found_8_in_list else -1 # Returns: -1
    index_in_string = my_string.lower().index('l') if found_in_string else -1 # Returns: 2

    # Sorting items in a list
    sorted_list = sorted(my_list, reverse=True) # [5, 4, 3, 2, 1]

########################################################################################################################################################################

# Travel Packing List and Selection
def travel_packing_list_selection():
    packing_list = ['clothes', 'toothbrush', 'passport', 'camera']
    item_to_check = 'sunglassed'

    # TODO: Write a line of code to check if the item_to_check is in the packing_list
    if item_to_check in packing_list:
        is_item_packed = True
        print("Is the item packed?", is_item_packed)
    else:
        is_item_packed = False
        print("Is the item packed?", is_item_packed)

    ########################################################################################################################################################################
    ## use one line to replace if else statement
    is_item_packed = True if item_to_check in packing_list else False
    print("Is the item packed?", is_item_packed)

    ########################################################################################################################################################################

    # TODO: Find the index of item_to_check in the list if it is packed, otherwise set it to -1
    if is_item_packed:
        item_index = packing_list.index(item_to_check)
    else:
        item_index = -1
    print("Item index:", item_index)

########################################################################################################################################################################

# Initialize an empty list named 'suitcase'
def suitcase_list():
    suitcase = []
    # TODO: Add items to your suitcase
    suitcase = ['clothes', 'sunglasses', 'brushes']
    # Declare a string variable for your goodbye message
    # TODO: Assign a farewell message to the variable
    goodbye_message = 'Farewell'
    # Access the first and last item in your suitcase
    # TODO: Print the first item in the suitcase
    # TODO: Print the last item in the suitcase
    print('firt item: ', suitcase[0])
    print('last item: ', suitcase[-1])

    # Send off with a farewell in uppercase
    # TODO: Print the farewell message in uppercase
    print(goodbye_message.upper())

########################################################################################################################################################################

# Given mission name
def given_mission_name():
    mission_name = "Sort"

    # TODO: Print the first and the last character of the mission name
    print('first character: ' + mission_name[0])
    print('last character: ' + mission_name[-1])

    # TODO: The mission needs a minor update. We aim to change its first letter to 'P' and the last letter to `k`, obtaining the word "Pork".
    # Remember, strings in Python are immutable, so you cannot alter them directly.
    updated_mission_name = 'p' + mission_name[1:-1] + 'k'

    # TODO: Print the updated mission name
    print(updated_mission_name)

########################################################################################################################################################################

def friends_list():
    friends = ['Alice', 'Bob', 'Charlie', 'Daniel']
    # `friend` is the loop variable, taking each name in the `friends` list
    for friend in friends:
        # for each `friend`, this line is executed
        print(f"Hello, {friend}! Nice to meet you.")
    #"""
    #Prints:
    #Hello, Alice! Nice to meet you.
    #Hello, Bob! Nice to meet you.
    #Hello, Charlie! Nice to meet you.
    #Hello, Daniel! Nice to meet you.
    #"""


########################################################################################################################################################################

# `num` runs through each number in the range of 5
def for_loop():
    for num in range(5):
        # This line will print numbers from 0 to 4
        print(num)
    
########################################################################################################################################################################

def while_loop():
    num = 0
    # The loop keeps running until num is greater than or equal to 5
    while num < 5:
        print(num)
        # increase num by 1 each iteration
        num += 1
    
########################################################################################################################################################################

def examples_for_while():
    # list of fruits
    fruits = ['apple', 'banana', 'cherry']
    # `fruit` stands for each fruit in the `fruits` list
    for fruit in fruits:
        print(fruit) # prints each fruit

    ########################################################################################################################################################################

    word = 'hello'
    # `letter` is each individual character in the `word`
    for letter in word:
        print(letter) # prints each letter in 'hello'

    ########################################################################################################################################################################

    # List of numbers
    numbers = [1, 2, 3, 4, 5]
    total = 0
    # `num` is each number in `numbers`
    for num in numbers:
        total += num # add each number in the list
    print(total) # prints the total sum

    ########################################################################################################################################################################

    # string
    text = 'hello'
    vowel_count = 0
    # `letter` is each character in `text`
    for letter in text:
        # If a vowel letter is found, increment the count
        if letter in 'aeiou':
            vowel_count += 1
    print(vowel_count) # prints the count of vowels

    ########################################################################################################################################################################

    # List of fruits to include in a fruit salad
    fruits = ['apple', 'banana', 'orange', 'kiwi', 'melon']
    # List of fruits to be used in fruit salad
    fruits = ['apple', 'banana', 'kiwi', 'mango']

    # TODO: Loop over the list of fruits and add them to the fruit salad with a print statement
    fruit_salad = []
    for fruit in fruits:
        # TODO: Print a statement for adding each fruit to the fruit salad.
        print (f"Adding {fruit} to the fruit salad")
        fruit_salad.append(fruit)
        print (f"The fruit salad:  {fruit_salad}")
    # Using a for loop to iterate over the list of fruits
    for fruit in fruits:
        print(f"Adding {fruit} to the salad.")

    ########################################################################################################################################################################

    # This code will create a simplified fruit salad with the provided fruits
    fruits = ['apple', 'banana', 'cherry', 'date']
    fruits_in_salad = ""

    index = 0
    # Create a while loop that assembles a string of fruit names separated by spaces, without adding a space after the last fruit
    while index < len(fruits):
        fruits_in_salad += fruits[index]
        if index < len(fruits) - 1:
            fruits_in_salad += " "
        index += 1

    print(f"Fruit salad contains: {fruits_in_salad}")

    # Using a while loop to iterate over the list of fruits
    index = 0
    while index < len(fruits):
        print(f"Adding {fruits[index]} to the salad.")
        index += 1

    ########################################################################################################################################################################

    # List of fruits to be used in fruit salad
    fruits = ['apple', 'banana', 'kiwi', 'mango']

    # TODO: Loop over the list of fruits and add them to the fruit salad with a print statement
    fruit_salad = []
    for fruit in fruits:
        # TODO: Print a statement for adding each fruit to the fruit salad.
        print(f"Adding {fruit} to the fruit salad")
        fruit_salad.append(fruit)
        print(f"The fruit salad:  {fruit_salad}")
    
########################################################################################################################################################################

def iteration_string():
    # Define a string named 'word' to represent the phrase we'll work with
    word = 'FRUIT Salad'

    # Initialize a counter to hold the number of non-vowel characters
    non_vowel_count = 0

    # Use a 'for' loop to iterate over each character in the string
    for char in word:
        # Check if it's not a vowel and not a space
        if char.lower() not in 'aeiou' and char != ' ':
            # Increase the counter for non-vowel characters
            non_vowel_count += 1

    # Print out the count of non-vowel characters
    print(f"Number of non-vowel characters: {non_vowel_count}")

########################################################################################################################################################################

def comparison_example():
    temperature = 15
    if temperature > 20:
        print("Wear light clothes.") # This will print if temperature is over 20.
    else:
        print("Bring a jacket.") # This will print otherwise.

########################################################################################################################################################################

    if temperature > 30:
        print("It's hot outside!") # Prints if temperature is over 30.
    elif temperature > 20:
        print("The weather is nice.") # Prints if temperature is between 21 and 30.
    else:
        print("It might be cold outside.") # Prints if temperature is 20 or below.
    
########################################################################################################################################################################

def break_continue_1():
    # We use the break statement whenever we want to exit a loop prematurely once a condition is met
    numbers = [1, 3, 7, 9, 12, 15]

    for number in numbers:
        if number % 2 == 0:
            print("The first even number is:", number) # Prints the first even number.
            break # Stops the loop after printing the first even number.
        print("Number:", number)
    # Prints:
    # Number: 1
    # Number: 3
    # Number: 7
    # Number: 9
    # The first even number is: 12

########################################################################################################################################################################

def break_continue_2():
    #The continue statement bypasses the rest of the loop code for the current iteration only
    for i in range(6):
        if i == 3:
            continue # Skips the print command for '3'.
        print(i) # Prints the numbers 0 to 5 except 3.
    # Prints:
    # 0
    # 1
    # 2
    # 4
    # 5

########################################################################################################################################################################

def break_continue_3():
    names = ["Alice", "Bob", "Charlie", "David"]

    for name in names:
        if name == "Charlie":
            print("Found Charlie!") # Prints when 'Charlie' is found.
            break # Stops the loop after finding Charlie.
        
        
########################################################################################################################################################################

def break_continue_4():
    # We'll check a series of temperatures and print a message accordingly
    temperatures = [18, 22, 30, 35]

    for temp in temperatures:
        if temp > 32:
            print('It is very hot.')
            break
        elif temp > 25:
            print('It is warm outside.')
            continue
        #elif temp < 20:
        #    print('It is cold.')
        #    break
        print('Might be chilly, dress appropriately.')

########################################################################################################################################################################

def break_continue_5():
    # List of temperatures with mixed weather conditions
    temperatures = [32, 18, 21, 28, 35, 19, 22]

    for temp in temperatures:
        # TODO: Print "It's really hot." and exit the loop if temperature is above 30
        if temp > 30:
            print("It's really hot.")
            break
        # TODO: Print "It's quite chilly." and skip to the next iteration if temperature is below 20
        elif temp < 20:
            print("It's quite chilly.")
            continue
        print("Lovely weather.")
    
########################################################################################################################################################################

def break_continue_6():
    # Sequence of temperatures throughout the day
    temperatures = [16, 14, 20, 22, 19, 13]

    # TODO: Loop through temperatures to suggest clothing
    for temp in temperatures:
        if temp < 15:
            print("Wear warm clothes.")
            # TODO: If it's cold outside, we stop checking the temperatures. Add the needed line to interrupt the loop.
            break
        elif temp >= 20:
            # TODO: Add a line here that will skip the final print statement when it's warm enough for light clothes.
            continue
        print("Consider a light jacket.")  # Suggestion for in-between temperatures

########################################################################################################################################################################

def break_continue_7():
    # TODO: Define a list of temperatures
    temperatures =[24, 17, 13, 18, 25, 27, 32]
    # TODO: Write a loop to go through each temperature in the list
    for temp in temperatures:
        # TODO: Add an 'if' statement to check if the temperature is over a really hot threshold
        if temp > 30:
            # TODO: Print a message for being really hot and then exit the loop
            print("It's really hot outside.")
            break
        # TODO: Add an 'elif' condition before the general temperature message to check if it's too cold
        elif temp < 18:
            # TODO: For temperatures that are too cold, print a specific message and skip to the next one
            print("It's quite cold and please wear more clothes")
            continue
        # TODO: Print a message saying the temperature is nice for all other cases
        print("It nice weather right now.")

########################################################################################################################################################################
def string_iteration():
    text = "Hello, Python!"
    for char in text:
        print(char)
    # Prints:
    # H
    # e
    # l
    # l
    # o
    # ,
    # ...

########################################################################################################################################################################

def exception_handle():
    try:
        text = "Hello, Python!"
        tenth_char = text[9]
        print('The tenth character is:', tenth_char)
    except IndexError as e:
        print("Char access error message:", e)

########################################################################################################################################################################

def string_contents():
    print(ord('A'))  # Prints: 65
    print(chr(65))  # Prints: 'A'
    print(chr(ord('A') + 1)) # Prints: 'B'

    ########################################################################################################################################################################

    print('mark'.upper())  # Prints: 'MARK'
    print('Mark'.lower())  # Prints: 'mark'

    ########################################################################################################################################################################

    print("C".isalpha()) # Prints: True
    print("C++".isalpha()) # Prints: False
    print("239".isdigit()) # Prints: True
    print("C239".isdigit()) # Prints: False
    print("C98".isalnum()) # Prints: True
    print("C98++".isalnum()) # Prints: False

########################################################################################################################################################################

def string_manipulation():
    text = "Python is fun!"
    cleaned_text = ""

    for char in text:
        if char.islower():
            cleaned_text += char.upper()
        elif char.isupper():
            cleaned_text += char.lower()
        else:  # Keep non-alphabetical characters unchanged
            cleaned_text += char

    print(cleaned_text)  # Initially outputs: "pYTHON IS FUN!"

########################################################################################################################################################################

def process_text(text):
    new_text = ""
    for char in text:
        if char.isalpha:
            new_text += char.upper() 
    print(f"Processed Text: {new_text}")

########################################################################################################################################################################

def process_text(text):
    new_text = ""
    for char in text:
        if char.isalpha():
            new_text += char.upper() 
    print(f"Processed Text: {new_text}")

########################################################################################################################################################################

def encrypt_text_1param(text):
    encrypted = ""
    for char in text:
        if char.isalpha():  # check if the character is an alphabet
            shift = 3
            if char.isupper():
                # Shift within 'A' to 'Z'
                encrypted += chr((ord(char) - ord('A') + shift) % 26 + ord('A'))
            else:
                # Shift within 'a' to 'z'
                encrypted += chr((ord(char) - ord('a') + shift) % 26 + ord('a'))
        else:
            encrypted += char  # keep non-alphabet characters unchanged
    return encrypted

########################################################################################################################################################################

# Define a function to encrypt the text using a shift cipher
def encrypt_text_2param(text, shift):
    encrypted = ""

    # Loop through each character in the text
    for char in text:
        if char.isalpha():  # Check if the character is a letter
            if char.isupper():
                # Shift within uppercase letters
                shifted = chr((ord(char) - ord('A') + shift) % 26 + ord('A'))
            else:
                # Shift within lowercase letters
                shifted = chr((ord(char) - ord('a') + shift) % 26 + ord('a'))
            encrypted += shifted
        else:
            # Keep non-alphabetic characters unchanged
            encrypted += char

    return encrypted

########################################################################################################################################################################

def split():
    sentence = 'Python is fun!'
    words = sentence.split() # no delimiter provided, splitting by whitespace
    print(words)  # Output: ['Python', 'is', 'fun!']

########################################################################################################################################################################

    data = 'John,Doe,35,Engineer'
    info = data.split(',') # provided a ',' delimiter
    print(info)  # Output: ['John', 'Doe', '35', 'Engineer']

########################################################################################################################################################################

    words = ['Programming', 'with', 'Python', 'is', 'exciting!']
    sentence = ' '.join(words)
    print(sentence)  # Output: 'Programming with Python is exciting!'

########################################################################################################################################################################
def strip():
    #Python's strip() method removes leading and trailing spaces, tab or newline characters from a string
    name = '    John Doe    \t\n'
    name = name.strip()
    print(name)  # Output: 'John Doe'

########################################################################################################################################################################

    name = '    John Doe    '
    print(name.lstrip())  # Output: 'John Doe    '
    print(name.rstrip())  # Output: '    John Doe'

########################################################################################################################################################################

    num_str = '123'
    print(type(num_str)) # Output: <class 'str'>
    num = int(num_str)
    print(type(num)) # Output: <class 'int'>


########################################################################################################################################################################

    name = 'John'
    age = 25
    print('My name is ' + name + ', and I am ' + str(age) + ' years old.')
    # Prints: My name is John, and I am 25 years old.

########################################################################################################################################################################


    numbers = '1,2,3,4,5'
    # Convert string to a list of numbers
    num_list = [int(number) for number in numbers.split(',')]
    print(num_list) # Output: [1, 2, 3, 4, 5]
    # Calculate average
    average = sum(num_list) / len(num_list)
    print('The average is', average)  # Output: The average is 3.0

########################################################################################################################################################################

    astronauts_data = "Buzz Aldrin, 1930;Yuri Gagarin, 1934;Valentina Tereshkova, 1937"

    # Splitting the string into a list of astronaut info and stripping any whitespace
    astronauts_list = astronauts_data.split(";")
    cleaned_astronauts = []

    for astronaut in astronauts_list:
        name, year = astronaut.split(",")
        cleaned_astronauts.append(name.strip() + " " + year.strip())  # Modify this line to use the join() method
    print(cleaned_astronauts)  # ['Buzz Aldrin 1930', 'Yuri Gagarin 1934', 'Valentina Tereshkova 1937']

########################################################################################################################################################################

    astronauts_data = "Buzz Aldrin, 1930;Yuri Gagarin, 1934;Valentina Tereshkova, 1937"

    # Splitting the string into a list of astronaut info and stripping any whitespace
    astronauts_list = astronauts_data.split(";")
    cleaned_astronauts = []

    for astronaut in astronauts_list:
        name, year = astronaut.split(",")
        # cleaned_astronauts.append(name.strip() + " " + year.strip())  # Modify this line to use the join() method
        name = name.strip()
        year = year.strip()
        cleaned_astronauts.append(' '.join([name, year]))
    print(cleaned_astronauts)  # ['Buzz Aldrin 1930', 'Yuri Gagarin 1934', 'Valentina Tereshkova 1937']

########################################################################################################################################################################

# A tiny piece of code that represents an HR Employee Data Management system.
# This code will manage a simple string that contains employee data.

    employee_data = "Alice,Developer,30|Bob,Manager,45|Charlie,Designer,25"
    # Splitting the employee data by '|' to separate each employee's info
    employee_list = employee_data.split('|')

    # TODO: For each employee, create a formatted string with stripped details and role eligibility for a junior position
    for employee in employee_list:
        # TODO: Parse the employee data and add eligibility note if applicable
        name, role, age = employee.split(',')
        name = name.strip()
        role = role.strip()
        age = age.strip()

        # Add eligibility note if applicable
        eligibility = " - Eligible for junior position" if role in ['Developer', 'Designer'] else ""
        print(f"Name: {name} - Role: {role} - Age: {age}{eligibility}")
        # Example: Name: Alice - Role: Developer - Age: 30 - Eligible for junior position
    
########################################################################################################################################################################

# This function processes astronaut names and planets from a string 
# then prints out a neat summary of who is exploring which planet.
def process_astronaut_data(data):
    astronaut_details = data.split(';')
    for detail in astronaut_details:
        # TODO: Extract the astronaut name and explored planet from the detail, strip away the whitespace.
        name, planet = detail.strip().split('-')
        # TODO: Print the statement in the format "Astronaut [name] is exploring [planet]."
        print(f"Astronaut {name} is exploring {planet}.")


########################################################################################################################################################################

def split_example():
    # Space exploration crew members' data, containing their names, missions, and roles
    crew_data = "Neil,Armstrong,Apollo 11,C;Buzz,Aldrin,Apollo 11,P;Michael,Collins,Apollo 11,CM"

    # TODO: Split the crew_data string into a list of individual crew member information using the appropriate delimiter
    crew_members = crew_data.split(';')
    # TODO: Iterate over the list of crew member data
    for crew_member in crew_members:
        # TODO: For each member, split their data string using commas as delimiters
        crew_member_detail = ' '.join(crew_member.split(','))
        # TODO: Print the crew member's details in a formatted string
        print(crew_member_detail)
    # Expected output:
    # Neil Armstrong Apollo 11 C
    # Buzz Aldrin Apollo 11 P
    # Michael Collins Apollo 11 CM


########################################################################################################################################################################

if (__name__ == "__main__"):
    string_list()
    introduce_list()
    introduce_string()
    slicing_list_string()
    travel_packing_list_selection()
    suitcase_list()
    given_mission_name()
    friends_list()
    for_loop()
    examples_for_while()
    iteration_string()
    comparison_example()
    break_continue_1()
    break_continue_2()
    break_continue_3()
    break_continue_4()
    break_continue_5()
    break_continue_6()
    break_continue_7()
    string_iteration()
    exception_handle()
    string_contents()
    string_manipulation()
    process_text("Happy Coding, Friends!")
    # Example text to encrypt
    original_text = "Hello, Python!"
    encrypted_text = encrypt_text_1param(original_text)
    print(encrypted_text)  # Output should be 'Khoor, Sbwkrq!'
    # Call the function with sample text and a shift value to test it
    sample_text = "Hello, World!"
    shift_value = 5
    encrypted_result = encrypt_text_2param(sample_text, shift_value)
    print("Encrypted Text:", encrypted_result)
    split()
    strip()
    # String containing astronaut names and planets, separated by semicolons.
    # Each astronaut-planet pair is separated by a dash.
    astronaut_data = "    Neil-Mars; Buzz-Jupiter; Sally-Venus    "
    process_astronaut_data(astronaut_data)
    split_example()



