def run():
    temperatures = [18, 22, 30, 35]
    i = 0
    while i < len(temperatures):
        if temperatures[i] > 20:
            print("Temperature", temperatures[i], "is greater than 20.")
        else:
            print("Temperature", temperatures[i], "might require a jacket.")
        i += 1  # Always increment i to avoid infinite loop


if __name__ == "__main__":
    run()