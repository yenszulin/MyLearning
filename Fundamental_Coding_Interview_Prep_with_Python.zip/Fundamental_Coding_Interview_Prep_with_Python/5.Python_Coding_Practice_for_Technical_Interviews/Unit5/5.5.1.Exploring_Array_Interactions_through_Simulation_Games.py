# Task Statement
# Picture a quaint, small town where every house is numbered sequentially from 1 to n. One day, a festive town
# event is held, and balloons are tied to each house. The festivities do not end there. At the conclusion of the
# event, a fun game is played: at each step of the game, each house sends half of its balloons to the neighboring
# house simultaneously (the neighbor on the right side, and for the last house, the neighbor is the first house).
# The game goes on until at some step there are no changes in the amount of balloons compared to the previous step.
# The task is to create a Python function, solution(balloons), where balloons is a list representing the number of
# balloons at each house. The function should simulate this game and return the number of steps in the game.
#
# For example, if balloons = [4, 1, 2], the output should be solution(balloons) = 3. After the first step, the list
# becomes [3, 3, 1]. This is because the first house sends 2 balloons and gets 1, the second house sends nothing
# but gets 2, and the third house sends 1 but receives nothing. Note that when the number of balloons x is odd,
# than the house sends (x - 1) / 2 balloons. After the second step, the list becomes [2, 3, 2] and never changes
# after that. So after the third step, the process finishes.

# 🧠 Key Observations:
# Each house sends half of its balloons to the next house.
#
# If the number is even, send x // 2.
#
# If the number is odd, send (x - 1) // 2.
#
# Transfers happen simultaneously for all houses.
#
# The last house sends to the first house, making it circular.
#
# The simulation stops when the balloon configuration is the same as the previous step.

def solution(balloons):
    n = len(balloons)
    steps = 0
    while True:
        steps += 1
        new_balloons = balloons.copy()
        for i in range(n):
            share = balloons[i] // 2  # Balloons to share
            new_balloons[i] -= share  # Decrease balloons of current house.
            new_balloons[(i + 1) % n] += share  # Increase balloons of next house.
        if new_balloons == balloons:
            break
        balloons = new_balloons
    return steps

def solution_cosmo(balloons):
    steps = 0
    n = len(balloons)

    while True:
        prev = balloons[:]
        send = [(x // 2) for x in balloons]
        receive = [0] * n

        for i in range(n):
            neighbor = (i + 1) % n
            receive[neighbor] += send[i]

        # Update balloons with net change
        balloons = [balloons[i] - send[i] + receive[i] for i in range(n)]

        steps += 1

        if balloons == prev:
            return steps


if __name__ == "__main__":
    print(solution([4, 1, 2]))  # Output: 3
    print(solution_cosmo([4, 1, 2]))  # Output: 3

