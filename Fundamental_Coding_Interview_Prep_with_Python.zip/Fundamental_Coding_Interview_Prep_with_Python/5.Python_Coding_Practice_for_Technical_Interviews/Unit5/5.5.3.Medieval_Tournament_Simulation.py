# Imagine a medieval tournament where knights participate in jousting matches. The knights are arranged in a
# circular formation (represented as an array in your program), and each knight is initially assigned strength,
# represented as integers from 1 to 100, determined randomly.
# The game consists of rounds. On each round, each knight fights the knight on his right side by subtracting
# the strength of his opponent from his own. Since this is a circular game, the knight on the right side of
# the last knight in the array is the first knight. Note that all matches are played in parallel, so the
# strengths are updated only after all matches are played. If after a match, a knight's strength becomes equal
# to or less than zero, symbolizing the knight's defeat, the knight is removed from the game in the next round.
#
# The game continues until a situation develops in which no more moves can be made. This happens either when
# there is just one knight standing or all remaining knights have equal strength meaning no knight can win a match.
#
# Given the list of knights' strengths in the initial order, your program should calculate the number of rounds
# in the tournament.

def jousting_tournament(strengths):
    rounds = 0

    while True:
        n = len(strengths)
        if n <= 1:
            # Only one or zero knights remain
            break

        # Check if all remaining knights have equal strength
        if all(s == strengths[0] for s in strengths):
            break

        # Calculate the new strengths after all fights (simultaneously)
        new_strengths = []
        for i in range(n):
            right_opponent = strengths[(i + 1) % n]
            new_strength = strengths[i] - right_opponent
            new_strengths.append(new_strength)

        # Remove knights with strength <= 0
        strengths = [s for s in new_strengths if s > 0]

        rounds += 1

        # If no knights remain, break
        if not strengths:
            break

    return rounds


if __name__ == "__main__":
    initial_strengths = [10, 20, 15, 30]
    print(jousting_tournament(initial_strengths))  # 2
    initial_strengths = [100, 50, 30, 20]
    print(jousting_tournament(initial_strengths))  # 3
    initial_strengths = [30, 20, 10, 40, 50]
    print(jousting_tournament(initial_strengths))  # 2
    initial_strengths = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
    print(jousting_tournament(initial_strengths))  # 1
