# Bob, Alice's friend, is also interested in string manipulations. Inspired by Alice's technique, he has devised his
# own string encoding scheme. He takes a sentence, which is a string of n alphanumeric characters (ranging from a-z,
# A-Z, 0-9), including spaces and punctuation marks, with n ranging from 1 to 500, inclusive. His encoding technique
# consists of the following steps:
#
# He replaces each alphanumeric character with the previous character in their respective sequence, i.e., for alphabets, he moves in the alphabetical order, and for numbers, he moves in the ordinal sequence.
#
# For instance, given a string word, for each character, if it's not a or A or 0, he replaces it with the character that precedes it in the sequence.
# For the character a or A, he replaces it with z or Z, respectively.
# For the number 0, he replaces it with 9.
# Another important aspect of Bob's algorithm involves frequency analysis. After shifting the characters, he counts the frequency of each alphanumeric character in the new string. Then, he creates an association between each alphanumeric character and its frequency and ASCII value. Each character maps to a number, which is the difference between the ASCII value of the character and its frequency. Once this is done, he computes the absolute value of each of these differences.
#
# The task is to help Bob generate a list of these absolute differences, sorted in ascending order.
#
# ✅ Steps Recap
# Replace each alphanumeric character:
#
# 'b' → 'a', 'a' → 'z'
#
# 'C' → 'B', 'A' → 'Z'
#
# '1' → '0', '0' → '9'
#
# Leave non-alphanumeric characters (e.g., punctuation, space) unchanged.
#
# Count frequency of each alphanumeric character in the shifted string.
#
# For each such character, compute abs(ord(char) - frequency).
#
# Return a sorted list of these absolute differences (ascending).


def bob_encode(sentence):
    shifted = []

    for ch in sentence:
        if 'a' <= ch <= 'z':
            shifted.append('z' if ch == 'a' else chr(ord(ch) - 1))
        elif 'A' <= ch <= 'Z':
            shifted.append('Z' if ch == 'A' else chr(ord(ch) - 1))
        elif '0' <= ch <= '9':
            shifted.append('9' if ch == '0' else chr(ord(ch) - 1))
        else:
            shifted.append(ch)  # keep punctuation and spaces as-is

    # Count frequency of alphanumeric characters
    freq = {}
    for ch in shifted:
        if ch.isalnum():
            freq[ch] = freq.get(ch, 0) + 1

    # Compute abs(ord(char) - frequency)
    differences = [abs(ord(ch) - count) for ch, count in freq.items()]

    return sorted(differences)


if __name__ == "__main__":
    text = "Hello World! 2024"
    print(bob_encode(text))
