# Task Statement
# Consider an array which symbolizes a dense forest; each index is either 1, indicating a tree, or 0, signifying
# a clear position. Starting from a fixed initial index and given a specific direction, your objective is to
# ascertain the smallest possible jump size that enables traversal from the initial position to one of the ends
# of the array without hitting a tree. Each move you make will be exactly the determined jump size in the given
# direction.
#
# Keep these pointers in mind:
# The array of binary integers (0 and 1) depicts the forest.
# The journey will always commence from a 0 index.
# The direction is an integer. 1 implies jumping toward larger indices, while -1 denotes jumping toward smaller
# ones. In situations where there is no jump size that can avoid all trees, return -1 to indicate the impossibility
# of traversal under these conditions. The ultimate objective? Identify the minimal jump size that ensures a
# smooth navigation through the entire forest without hitting a single tree.
#
# Example
# For the input values forest = [0, 1, 0, 0, 0, 0, 1, 1], start = 0, and direction = 1, the output should be 4.
#
# If you take the jump size equal to 1, you immediately step on a tree.
# If you choose 2, you step on a tree after three jumps at forest[6].
# If you choose 3, you again step on a tree at forest[6].
# For the jump size equal to 4, you first jump to the 4th position which is a valid position, then jump outside of
# the array, thereby traversing the forest without hitting a tree.
def calculate_jump(forest, start, direction):

    jump = 1

    while (direction * jump) + start >= 0 and (direction * jump) + start < len(forest):
        pos = start
        while 0 <= pos < len(forest):
            if forest[pos] == 1:
                break
            pos += jump * direction
        else:
            return jump

        jump += 1
    return -1

# ✅ Key Points
# Only positions with value 0 are allowed (clearings).
#
# Start from start index (guaranteed to be 0).
#
# Jump in direction (1 = right, -1 = left).
#
# Try increasing jump sizes and simulate each path.
#
# Return the minimum jump size that avoids all 1s (trees).
#
# If no jump size works, return -1.
#
# ✅ Python Implementation
def minimal_jump_size(forest, start, direction):
    n = len(forest)

    for jump in range(1, n + 1):
        pos = start
        success = True

        while 0 <= pos < n:
            if forest[pos] == 1:
                success = False
                break
            pos += jump * direction

        if success:
            return jump

    return -1


if __name__ == "__main__":
    forest = [0, 1, 0, 0, 0, 0, 1, 1]
    start = 0
    direction = 1

    print(calculate_jump(forest, start, direction))
    print(minimal_jump_size(forest, start, direction))  # Output: 4


