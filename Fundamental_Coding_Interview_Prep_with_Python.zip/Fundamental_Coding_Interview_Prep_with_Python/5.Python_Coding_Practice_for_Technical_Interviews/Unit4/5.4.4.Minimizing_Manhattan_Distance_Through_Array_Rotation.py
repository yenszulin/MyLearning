# Prepare to challenge your array manipulation skills! Consider two arrays, array1 and array2, each consisting of
# n non-negative integers. The values of n range from 1 to 500, inclusive. Each integer in the arrays is at most
# 10^3. Your task is to discover a rotation of array1 that minimizes the Manhattan distance with array2. The
# Manhattan distance between two arrays, a and b, of size n, is defined by:
#
# A rotation of an array refers to taking one or more elements from the end and moving these elements to the
# beginning, maintaining their original order in the process.
# You need to return the smallest possible Manhattan distance obtained through this operation.
# Let's say that you find multiple rotations of array1 that yield the same smallest Manhattan distance with
# array2. In this case, you should return the rotated array that, when converted into an integer number by
# concatenating all of its digits (from left to right), would be the smallest.
# Consider the array as periodic; that is, after the last element, the first one follows.
# Keep in mind that the size of the two arrays is always the same, and the arrays are not necessarily sorted at
# the beginning.
# If array1 is exactly the same as array2 from the beginning, output the original array1 and the Manhattan
# distance 0.
# Remember, the ultimate goal is to minimize the Manhattan distance between array1 and array2 through the least
# alterations possible to array1. Let's see how small you can get!

# ✅ Step-by-Step Strategy
# Rotation Definition:
# A rotation of array1 is created by taking the last k elements and moving them to the front, for each k from 0 to n-1.
#
# Manhattan Distance Calculation:
# For each rotation, calculate the Manhattan distance to array2:
#
# Track the Minimum Distance:
# Keep track of:
# the minimum Manhattan distance found,
# the corresponding rotated array,
# and use lexicographical comparison to break ties if distances are equal.

def rotate_and_minimize_distance(array1, array2):
    n = len(array1)
    min_distance = float('inf')
    best_rotation = []
    best_rotation_value = float('inf')  # Integer formed by digits

    for k in range(n):  # Try every rotation
        rotated = array1[-k:] + array1[:-k]
        distance = sum(abs(rotated[i] - array2[i]) for i in range(n))
        rotation_value = int(''.join(str(d) for d in rotated))  # Concatenated integer

        if (distance < min_distance or
            (distance == min_distance and rotation_value < best_rotation_value)):
            min_distance = distance
            best_rotation = rotated
            best_rotation_value = rotation_value

    return best_rotation, min_distance


if __name__ == "__main__":
    array1 = [3, 1, 4, 2]
    array2 = [1, 4, 2, 3]

    rotated, dist = rotate_and_minimize_distance(array1, array2)
    print("Best Rotated Array:", rotated)
    print("Minimum Manhattan Distance:", dist)

