# You are given an array of n integer values, with n ranging from 1 to 500, inclusive. The array represents a
# path through a virtual dungeon, with certain positions marked as traps.
#
# Each element in the array ranges from −10^10 to 10^10 , inclusive, and represents the trap power. A value of 0
# signifies a safe position, whereas positive integers indicate trap power — the higher the value, the harder it
# is to avoid and, hence, the more dangerous it is. Negative integers are traps that are easier to avoid, with
# negative values implying that the trap could potentially aid you rather than hinder.
#
# Your task is to move from the start position to the end position. For each step, you can move by x elements in
# the right direction only, where x ranges from 1 to n. Each time you step on a trap, you lose health points equal
# to the trap's power. You originally have h health points, where h is a positive integer ranging from 1 to 10^100.
#
# Find the x that you must choose such that you lose the least amount of health points upon reaching the end of
# the array. Also, determine if there is no possible x that allows you to reach the end of the array with any
# remaining health points. In the latter case, return -1 to indicate that it's impossible to traverse the dungeon
# without succumbing to a fatal trap. If at any point your health points reach 0 or less, you are considered out
# of the game.
#
# Example
# Input:
#
# Array of trap powers: [0, 5, -2, 8, 3, 0, 10, 4, -1, 7]
# Initial health: 20
# Process: Let's analyze different step sizes (x) to find which one minimizes health loss:
#
# Step size x = 1:
#
# Path: 0 → 5 → -2 → 8 → 3 → 0 → 10 → 4 → -1 → 7
# Health loss: 0 + 5 + (-2) + 8 + 3 + 0 + 10 + 4 + (-1) + 7 = 34
# Since 34 > 20, with step size 1, you would lose all health before reaching the end.
# Step size x = 2:
#
# Path: 0 → -2 → 3 → 10 → -1
# Health loss: 0 + (-2) + 3 + 10 + (-1) = 10
# Remaining health: 20 - 10 = 10
# Step size x = 3:
#
# Path: 0 → 8 → 0 → 4 → 7
# Health loss: 0 + 8 + 0 + 4 + 7 = 19
# Remaining health: 20 - 19 = 1
# Step size x = 4:
#
# Path: 0 → 3 → 4
# Health loss: 0 + 3 + 4 = 7
# Remaining health: 20 - 7 = 13
# Step size x = 5:
#
# Path: 0 → 0 → 7
# Health loss: 0 + 0 + 7 = 7
# Remaining health: 20 - 7 = 13
# Step size x = 6:
#
# Path: 0 → 10
# Health loss: 0 + 10 = 10
# Remaining health: 20 - 10 = 10
# Step size x = 7:
#
# Path: 0 → 4
# Health loss: 0 + 4 = 4
# Remaining health: 20 - 4 = 16
# Step size x = 8 (optimal):
#
# Path: 0 → -1
# Health loss: 0 + (-1) = -1 (actually gaining 1 health)
# Remaining health: 20 - (-1) = 21
# Step size x = 9:
#
# Path: 0 → 7
# Health loss: 0 + 7 = 7
# Remaining health: 20 - 7 = 13
# Step size x = 10:
#
# Cannot reach the end of the array with this step size, as it would overshoot the array.
# Output:
#
# Optimal step size (x): 8
# Minimum health loss: -1 (you actually gain 1 health point)
# Remaining health: 21
# Additional Example
# If we changed the initial health to be only 3, and the trap values to [0, 5, 10, 8, 3, 20, 10, 4, 30, 7], then
# there would be no possible step size that allows you to reach the end with remaining health, so the output would
# be -1.
#
# ✅ Problem Recap
# Given:
# An array of trap powers (-10 to 10, inclusive).
# A health pool h (1 to 10^4).
# Task:
# Find the step size x (from 1 to n) that leads you from index 0 to (or past) the end of the array with the least
# health lost.
# You only move right.
# Trap cost:
# Positive → lose that many health points.
# Negative → gain health.
# Return the optimal step size x that lets you survive (health > 0 at end) and minimizes total trap cost.
# If no such x exists, return -1.
# 🧩 Python Code
def optimal_step_size(traps, health):
    n = len(traps)
    best_x = -1
    min_health_loss = float('inf')

    for x in range(1, n + 1):
        pos = 0
        total_loss = 0
        while pos < n:
            total_loss += traps[pos]
            pos += x
        if total_loss < min_health_loss and health - total_loss > 0:
            min_health_loss = total_loss
            best_x = x

    return best_x


if __name__ == "__main__":
    traps = [0, 5, -2, 8, 3, 0, 10, 4, -1, 7]
    health = 20
    print(optimal_step_size(traps, health))  # Output: 8
