# Assume you have a community garden composed of n different types of flowers, with n ranging from 1 to 100. Each
# type is represented by a distinct number (1, 2, 3, ..., n). The garden is depicted as a 1D array, wherein each
# element indicates the type of flower planted in that specific location.
#
# Your task involves visiting each type of flower at least once, traversing the garden in a specific direction
# (either from left to right with smaller to larger indices, or from right to left). You can take exactly k number
# of steps in the chosen direction, visiting a new location.
#
# Write a Python function, largest_step(garden, start, direction), that accepts as input the garden as an array,
# your starting position, and the direction in which you want to travel. This function is expected to compute and
# return the largest-sized step step that you can take so that you can visit each type of flower existing in the
# garden at least once.
#
# If no such value of step enables you to visit all types of flowers at least once, the function should return -1.
# The direction is given as an integer — 1 indicates moving towards larger indices (right), while -1 suggests moving
# towards smaller ones (left).

# ✅ Key Points
# garden: list of flower types (integers from 1 to n).
#
# start: starting index in the garden.
#
# direction: 1 = move right, -1 = move left.
#
# For each possible step size, we check if stepping from start in the given direction by step lets us collect all flower types.
#
# Return the maximum valid step. If none is valid, return -1.

def largest_step(garden, start, direction):
    n = len(garden)
    all_types = set(garden)
    max_step = -1

    for step in range(1, n + 1):
        visited = set()
        pos = start

        while 0 <= pos < n:
            visited.add(garden[pos])
            pos += step * direction

        if visited == all_types:
            max_step = step  # update if valid, continue to find larger

    return max_step

if __name__ == "__main__":
    garden = [3, 1, 2, 1, 3, 2, 1]
    start = 0
    direction = 1
    print(largest_step(garden, start, direction))  # Output could be 2 or other max valid step
    garden = [1, 2, 3, 4, 5, 9, 2, 1, 3, 8, 2, 7, 1, 6]
    start = 13
    direction = -1
    print(largest_step(garden, start, direction))  # Output could be 1 or other max valid step
    garden = [1, 2, 3, 4, 5]
    start = 0
    direction = 1
    print(largest_step(garden, start, direction))  # Output could be 1 or other max valid step
    garden = [1]
    start = 0
    direction = 1
    print(largest_step(garden, start, direction))  # Output could be 1 or other max valid step
    garden = [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
    start = 0
    direction = -1
    print(largest_step(garden, start, direction))  # Output could be -1 or other max valid step
    garden = [1, 5, 2, 5, 3, 5, 4, 5]
    start = 3
    direction = -1
    print(largest_step(garden, start, direction))  # Output could be -1 or other max valid step


