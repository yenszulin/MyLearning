# You're assisting in the creation of an algorithm for a novel game where a character hops between two arrays following certain rules. The
# game starts at the first index (1-based) of an array, arrayA.
# The value at the character's current position in arrayA determines the index it jumps to on the second array, arrayB. Upon landing on
# arrayB, it does the same thing: the value at the current position specifies the index it jumps to in arrayA. This iteration continues
# until the character lands on an index in arrayA that it has already visited, at which point the game concludes.
# Your task is to develop a Python function simulating this gameplay. The function receives two equal-length arrays of integers, arrayA
# and arrayB, each containing n elements (1 ≤ n ≤ 100). It should return an array consisting of the 1-based indices on arrayB that the
# character visited before a position on arrayA was repeated. Each element in the input arrays ranges from 1 to n, indicating the next
# 1-based index that the character will jump to in the other array. The function guarantees that each jump always results in a valid
# position within the same-length arrays, and a position in arrayA will inevitably be revisited.

def simulate_game(arrayA, arrayB):
    visited_a = set()
    visited_b_indices = []

    current_a_index = 0  # Start at arrayA[0] (1-based index = 1)

    while current_a_index not in visited_a:
        visited_a.add(current_a_index)

        # Jump from arrayA to arrayB
        next_b_index = arrayA[current_a_index] - 1  # Convert to 0-based index
        visited_b_indices.append(next_b_index + 1)  # Store 1-based index

        # Jump from arrayB to arrayA
        current_a_index = arrayB[next_b_index] - 1  # Convert to 0-based index

    return visited_b_indices

if __name__ == "__main__":
    arrayA = [1, 3, 2, 5, 4]
    arrayB = [5, 4, 3, 2, 1]
    print(simulate_game(arrayA, arrayB))
    # Output: [1]

