# Gloria the bunny finds herself once again amidst an array game. This time, however, the game has slightly intensified with a third array
# coming into play. Your task is to develop a Python function to maneuver Gloria through her quest, yielding the summation of the maximum
# values she encounters from arrayB and arrayC together. Gloria's journey begins at the first element of arrayA. Gloria's movement pattern
# follows a fixed sequence that repeats: arrayA -> arrayB -> arrayA -> arrayC. In other words, Gloria always alternates between arrayA and
# either arrayB or arrayC, following this pattern:
# First hop: arrayA to arrayB
# Second hop: arrayB to arrayA
# Third hop: arrayA to arrayC
# Fourth hop: arrayC to arrayA
# Then the pattern starts over, continuing until the journey ends.
# The rule to decide Gloria's move is: She uses the current element's value in the array as an index for her next array. For example, if
# Gloria is at arrayA[1]=2, she would move to arrayB[2].
# The pattern repeats itself until one of the following occurs:
# Gloria's path repeats by visiting a position in arrayB or arrayC that was already visited, indicating that she is stuck in a loop and
# cannot progress further, OR Gloria tries to access an index that exceeds the length of an array (for example, attempting to access
# arrayA[4] when arrayA only contains 4 items indexed from 0 to 3), in which case Gloria's journey should also stop.
# Your task is to calculate the sum of the maximum values that Gloria encounters in arrayB and arrayC during her journey.
# Each input array consists of n items, where n ranges from 1 to 100, inclusive. Every item in the arrays is a non-negative integer and
# falls within the range of 0 to 99, inclusive.
# EXAMPLE
# Consider arrayA = [2, 1, 3, 0], arrayB = [1, 3, 2, 4], and arrayC = [4, 2, 5, 1]. Gloria's journey would look like:
# She begins at arrayA[0] = 2 which leads her to arrayB[2] = 2.
# She then goes back to arrayA[2] = 3, and then to arrayC[3] = 1.
# She returns to arrayA[1] = 1, then makes a hop to arrayB[1] = 3.
# She goes back to arrayA[3] = 0 and then proceeds to arrayC[0] = 4.
# Now Gloria would go to arrayA[4], however, since arrayA[4] doesn't exist because arrayA only contains 4 elements indexed from 0 to 3,
# Gloria's journey stops here. During her journey, Gloria encounters the maximum value 3 in arrayB and 4 in arrayC. The function should
# return 7, the sum of these two maximum values.

def gloria_three_array_journey(arrayA, arrayB, arrayC):
    max_B = -1
    max_C = -1

    visited_B = set()
    visited_C = set()

    current_index = 0
    current_array = 'A'
    step = 0

    while True:
        if current_array == 'A':
            if current_index >= len(arrayA):
                break
            next_index = arrayA[current_index]
            step += 1
            if step % 2 == 1:
                current_array = 'B'
            else:
                current_array = 'C'

        elif current_array == 'B':
            if next_index >= len(arrayB) or next_index in visited_B:
                break
            visited_B.add(next_index)
            max_B = max(max_B, arrayB[next_index])
            current_index = arrayB[next_index]
            current_array = 'A'

        elif current_array == 'C':
            if next_index >= len(arrayC) or next_index in visited_C:
                break
            visited_C.add(next_index)
            max_C = max(max_C, arrayC[next_index])
            current_index = arrayC[next_index]
            current_array = 'A'

    return max_B + max_C


if __name__ == '__main__':
    arrayA = [2, 1, 3, 0]
    arrayB = [1, 3, 2, 4]
    arrayC = [4, 2, 5, 1]

    result = gloria_three_array_journey(arrayA, arrayB, arrayC)
    print(result)  # Output: 7
