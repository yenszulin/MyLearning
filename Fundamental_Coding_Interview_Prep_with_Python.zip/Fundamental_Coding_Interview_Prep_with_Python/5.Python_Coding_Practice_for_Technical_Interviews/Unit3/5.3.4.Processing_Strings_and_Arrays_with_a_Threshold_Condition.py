# You are required to create a function that, given two parameters — an array of integers and a string — will return a
# modified text message based on these elements.
# You will be provided with an array of n integers, where n is between 1 and 100, inclusive, and a string with m characters,
# where m ranges from 1 to 500, inclusive. Each element in the array will range from −100 to 100, inclusive.
# Your initial task is to process the array by subtracting 3 from each number and then accumulating the absolute values
# of each number until their total exceeds 30. If the total exceeds 30, you must stop processing the array immediately.
# Concurrently, you must process the given string. In this part, replace each lowercase character in your string with the
# succeeding alphabetical character in a cyclic manner; for instance, 'a' should be replaced by 'b', 'b' should be replaced
# by 'c', and so on, until 'z', which should be replaced by 'a'. If a character is not a lowercase letter, it should be left
# as is.
# Similar to the array, if the total absolute value from the array operations crosses the threshold of 30, you should cease
# the string modification immediately.
# At the conclusion, return both an updated string with all processed characters and the remaining, unprocessed portion of
# the initial array, respectively. Can you create a function that accomplishes all this?

# ✅ Task Breakdown
# For the array:
# Subtract 3 from each element.
#
# Accumulate abs(value - 3) until the total exceeds 30.
#
# Stop processing once the sum exceeds 30.
#
# For the string:
# Replace each lowercase letter with the next character ('a' → 'b', 'z' → 'a').
#
# Leave non-lowercase characters unchanged.
#
# Stop processing in sync with the array (same number of processed items).
#
# 🧩 Python Implementation
def process_message(numbers, text):
    updated_text = ''
    total = 0
    i = 0

    while i < len(numbers) and i < len(text):
        # Process number
        adjusted = numbers[i] - 3
        total += abs(adjusted)

        if total > 30:
            break

        # Process character
        ch = text[i]
        if 'a' <= ch <= 'z':
            updated_ch = 'a' if ch == 'z' else chr(ord(ch) + 1)
        else:
            updated_ch = ch

        updated_text += updated_ch
        i += 1

    return (updated_text, numbers[i:])

if __name__ == "__main__":
    numbers = [5, -2, 8, -10, 12, 0]
    text = "hello! world123"
    print(process_message(numbers, text))

# 🔍 Explanation for the example
# Adjusted numbers: [2, -5, 5, -13, 9, -3] → abs: [2, 5, 5, 13, 9] → sum = 34 → stops after processing 4 items.
#
# Processed string: 'hello' → 'ifmmp' (only first 4 chars → 'ifmm')
#
# Remaining numbers: [12, 0]
#
# Output: ('ifmm', [12, 0])