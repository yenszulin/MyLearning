# Array Hopping Adventure: Exploring Index-Based Traversals

# You're assisting in the creation of an algorithm for a novel game where a character hops between two arrays following certain rules. The
# game starts at the first index (1-based) of an array, arrayA.
# The value at the character's current position in arrayA determines the index it jumps to on the second array, arrayB. Upon landing on
# arrayB, it does the same thing: the value at the current position specifies the index it jumps to in arrayA. This iteration continues
# until the character lands on an index in arrayA that it has already visited, at which point the game concludes.
# Your task is to develop a Python function simulating this gameplay. The function receives two equal-length arrays of integers, arrayA
# and arrayB, each containing n elements (1 ≤ n ≤ 100). It should return an array consisting of the 1-based indices on arrayB that the
# character visited before a position on arrayA was repeated. Each element in the input arrays ranges from 1 to n, indicating the next
# 1-based index that the character will jump to in the other array. The function guarantees that each jump always results in a valid
# position within the same-length arrays, and a position in arrayA will inevitably be revisited.

def simulate_game(arrayA, arrayB):
    visitedA = set()
    result = []

    indexA = 1  # start at 1-based index 1 in arrayA

    while indexA not in visitedA:
        visitedA.add(indexA)

        indexB = arrayA[indexA - 1]  # jump to B using A value
        result.append(indexB)       # record visited B index

        indexA = arrayB[indexB - 1]  # jump to A using B value

    return result


# Gloria the bunny finds herself once again amidst an array game. This time, however, the game has slightly intensified with a third array
# coming into play. Your task is to develop a Python function to maneuver Gloria through her quest, yielding the summation of the maximum
# values she encounters from arrayB and arrayC together. Gloria's journey begins at the first element of arrayA. Gloria's movement pattern
# follows a fixed sequence that repeats: arrayA -> arrayB -> arrayA -> arrayC. In other words, Gloria always alternates between arrayA and
# either arrayB or arrayC, following this pattern:
# First hop: arrayA to arrayB
# Second hop: arrayB to arrayA
# Third hop: arrayA to arrayC
# Fourth hop: arrayC to arrayA
# Then the pattern starts over, continuing until the journey ends.
# The rule to decide Gloria's move is: She uses the current element's value in the array as an index for her next array. For example, if
# Gloria is at arrayA[1]=2, she would move to arrayB[2].
# The pattern repeats itself until one of the following occurs:
# Gloria's path repeats by visiting a position in arrayB or arrayC that was already visited, indicating that she is stuck in a loop and
# cannot progress further, OR Gloria tries to access an index that exceeds the length of an array (for example, attempting to access
# arrayA[4] when arrayA only contains 4 items indexed from 0 to 3), in which case Gloria's journey should also stop.
# Your task is to calculate the sum of the maximum values that Gloria encounters in arrayB and arrayC during her journey.
# Each input array consists of n items, where n ranges from 1 to 100, inclusive. Every item in the arrays is a non-negative integer and
# falls within the range of 0 to 99, inclusive.
# EXAMPLE
# Consider arrayA = [2, 1, 3, 0], arrayB = [1, 3, 2, 4], and arrayC = [4, 2, 5, 1]. Gloria's journey would look like:
# She begins at arrayA[0] = 2 which leads her to arrayB[2] = 2.
# She then goes back to arrayA[2] = 3, and then to arrayC[3] = 1.
# She returns to arrayA[1] = 1, then makes a hop to arrayB[1] = 3.
# She goes back to arrayA[3] = 0 and then proceeds to arrayC[0] = 4.
# Now Gloria would go to arrayA[4], however, since arrayA[4] doesn't exist because arrayA only contains 4 elements indexed from 0 to 3,
# Gloria's journey stops here. During her journey, Gloria encounters the maximum value 3 in arrayB and 4 in arrayC. The function should
# return 7, the sum of these two maximum values.

def gloria_journey(arrayA, arrayB, arrayC):
    max_B = -1
    max_C = -1

    visited_B = set()
    visited_C = set()

    current_index = 0
    current_array = 'A'
    step = 0

    while True:
        if current_array == 'A':
            if current_index >= len(arrayA):
                break
            next_index = arrayA[current_index]
            step += 1
            if step % 2 == 1:
                current_array = 'B'
            else:
                current_array = 'C'

        elif current_array == 'B':
            if next_index >= len(arrayB) or next_index in visited_B:
                break
            visited_B.add(next_index)
            max_B = max(max_B, arrayB[next_index])
            current_index = arrayB[next_index]
            current_array = 'A'

        elif current_array == 'C':
            if next_index >= len(arrayC) or next_index in visited_C:
                break
            visited_C.add(next_index)
            max_C = max(max_C, arrayC[next_index])
            current_index = arrayC[next_index]
            current_array = 'A'

    return max_B + max_C

# Alice loves to play a jumping game on two parallel roads, roadA and roadB, each filled with integers. The game begins with Alice choosing
# a starting point on roadA, and then moving according to the following rules:
# Alice chooses a starting point on roadA.
# Each element in both the roads dictate exactly where to jump on the other road. If Alice is at the i-th position of roadA, where
# roadA[i] = x, then Alice moves to the x-th position of roadB. Likewise, if Alice is at the i-th position of roadB, where roadB[i] = y,
# then she moves to the y-th position of roadA. Alice continues these jumps until she ends up at an already visited spot on either road in
# the current route, which signifies the end of this game. It's important to note that if a spot was visited in a previous route but not
# in the current route, it is not considered as an already visited spot.
# The distance covered in each jump is defined as 1 unit, no matter where she jumps to on the other road.
# Your task is to create a function that receives these two roads, roadA and roadB, as its parameters. The function should calculate and
# return an array of total distances Alice covers during her game for each possible starting point on roadA. More specifically, the result
# should be an array results, where results[i] denotes the total distance covered if Alice starts from roadA[i].
# The two input lists, roadA and roadB, contain n and m number of elements respectively. The number of elements in each list can range from
# 1 to 100, inclusive. Each element in roadA can have a value ranging from 0 to m−1, inclusive. Similarly, each element in roadB can have a
# value ranging from 0 to n−1, inclusive. This ensures that any element in either of the lists will be a valid index in the other list.
# Example
# For instance, if Alice's roads are given as roadA = [1, 0, 2] and roadB = [2, 0, 1], the function should return [2, 4, 4] because:
# If Alice starts from roadA[0], her first jump takes her to roadB[1]. The value at this index tells her to jump to roadA[0], but since
# vthat's where she started this route (and thus it's already visited), she stops. As a result, Alice covers a total distance of 2 units.
# If Alice starts from roadA[1], she jumps to roadB[0] which then redirects her to roadA[2]. From roadA[2], she jumps to roadB[1] which
# then leads her to roadA[0]. From roadA[0], she jumps to roadB[1] again but realizes this is the spot she has already visited in this
# route. Thus, in this case she covers a total distance of 4 units. If Alice starts from roadA[2], her first jump takes her to roadB[2]
# and then the rule at this position directs her to roadA[1]. She has not yet visited roadA[1] in this route, so she follows the
# instruction and jumps to roadB[0], which also directs her to roadA[2], which she has visited in this route already so she stops there.
# Therefore, she covers a total distance of 4 units before landing on an already visited spot in her current route.
def jumping_game_distances(roadA, roadB):
    n = len(roadA)
    results = []

    for start in range(n):
        visitedA = set()
        visitedB = set()
        position = start
        on_road_a = True
        distance = 0

        while True:
            if on_road_a:
                if position in visitedA:
                    break
                visitedA.add(position)
                position = roadA[position]
                on_road_a = False
            else:
                if position in visitedB:
                    break
                visitedB.add(position)
                position = roadB[position]
                on_road_a = True
            distance += 1

        results.append(distance)

    return results




if (__name__ == "__main__"):
    arrayA = [1, 3, 2, 5, 4]
    arrayB = [5, 4, 3, 2, 1]
    print(simulate_game(arrayA, arrayB))  # Output: [1, 4, 3, 2, 5]
    arrayA = [2, 1, 3, 0]
    arrayB = [1, 3, 2, 4]
    arrayC = [4, 2, 5, 1]
    print(gloria_journey(arrayA, arrayB, arrayC))  # Output: 7
    roadA = [1, 0, 2]
    roadB = [2, 0, 1]
    print(jumping_game_distances(roadA, roadB))  # Output: [2, 4, 4]
