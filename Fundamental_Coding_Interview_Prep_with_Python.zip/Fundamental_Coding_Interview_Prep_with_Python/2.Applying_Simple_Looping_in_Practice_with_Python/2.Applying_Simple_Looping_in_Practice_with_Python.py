from collections import Counter

def for_loop(numbers):
    result = []
    n = len(numbers)
    for i in range(n):
        result.append((numbers[i], numbers[n - i - 1]))
    return result

# You are given an input array consisting of n integers ranging from 0 to 100, inclusive, where n represents the length of the array.
# Your task is to return a new array of tuples. Each tuple should consist of an element from the input array paired with its geometrical
# mean with the 'opposite' element. The 'opposite' element of any element in the array is defined as the element at the corresponding
# position from the end of the array.

import math

def pair_with_geometric_mean(arr):
        n = len(arr)
        result = []

        for i in range(n):
            elem = arr[i]
            opposite = arr[n - 1 - i]
            geo_mean = math.sqrt(elem * opposite)
            result.append((elem, geo_mean))

        return result


# You are provided with a list of n integers, where n ranges from 2 to 200, inclusive. The task is to return a list of tuples, each
# containing a pair of an integer and its reverse counterpart. In this context, the reverse counterpart of a number is the number with
# its digits reversed. For example, the reverse counterpart of 123 is 321. You must iterate through the list to find the reverse
# counterpart for each integer. If this reversed number exists in the list, create a tuple with the original number and its reverse
# counterpart. If not, skip it.
# Your output should be a list of tuples with the original numbers and their reverse counterparts. The integers in the given list will
# range from 1 to 99999, inclusive.
# Note: The reverse counterpart of a single digit number is the same number. For numbers that result in leading zeros when reversed
# (e.g., 100 becomes 001, which is 1), consider only the integer value (i.e., 1). It's guaranteed that the original list will not
# contain integers with leading zeros.
# For example, for numbers = [12, 21, 34, 43, 56, 65], the output should be solution(numbers) = [(12, 21), (21, 12), (34, 43), (43, 34),
# (56, 65), (65, 56)].

def reversed_string(numbers):
    number_set = set(numbers)
    result = []

    for num in numbers:
        reversed_num = int(str(num)[::-1])
        if reversed_num in number_set:
            result.append((num, reversed_num))

    return result

# You are given an array of n integers, where n ranges from 2 to 200, inclusive. The elements in the array range from -200 to 200,
# inclusive. Your task is to return an array in which each element is the sum of a pair composed of an element and its 'opposite'
# element. By 'opposite', we mean that in an array of n elements, the first and last elements are paired, the second and second-to-last
# elements are paired, and so on. If the array is of odd length, the middle element pairs with itself.
# The function should handle both positive and negative integers and be capable of dealing with an odd number of elements in the list.
# For example, given an input array [1, 2, 3, 4, 5], your function should return [6, 6, 6]. This is because the first element 1 plus
# the last element 5 equals 6, the second element 2 plus the second-to-last element 4 equals 6, and the middle element 3 plus itself
# equals 6.

def sum_with_opposites(arr):
    n = len(arr)
    result = []
    for i in range((n + 1) // 2):  # Handles both even and odd lengths
        total = arr[i] + arr[n - 1 - i]
        result.append(total)
    return result

# Today, our objective is to create a function that operates on an integer input. The task might seem simple, but it requires some
# ingenuity. Here's the mission: given an integer, n, we need to calculate and return the sum of its even digits — and here's the
# clincher — without converting n into a string. For instance, if n equals 4625, the output should be 12 because the sum of the even
# digits 4, 6, and 2 equals 12.

def sum_even_digits(n):
    total = 0
    while n > 0:
        digit = n % 10      # Get last digit
        if digit % 2 == 0:  # Check if even
            total += digit
        n //= 10            # Remove last digit
    return total


def product_of_odd_digits(n):
    product = 1
    has_odd = False

    while n > 0:
        digit = n % 10
        if digit % 2 == 1:  # Check if the digit is odd
            product *= digit
            has_odd = True
        n //= 10  # Remove the last digit

    return product if has_odd else 0


# Your task is to construct a function that accepts an integer n and returns the integer with the same digits as n, but in reverse order.
# You should implement your solution using a while loop.For instance, if the input is 12345, the output should be 54321.
# Keep in mind that n will always be a positive integer between 1 and 100000000
# Do not use built-in functions that convert the integer to another data type, such as a string, to reverse it. Solve the problem purely
# using mathematical operations and loop constructs.
# Note that when the result has leading zeros, you should consider only the integer value (e.g., 1230 becomes 321 after the operation).

def reverse_integer(n):
    reversed_num = 0

    while n > 0:
        digit = n % 10
        reversed_num = reversed_num * 10 + digit
        n //= 10

    return reversed_num


def reverse_integer_2(n):
    # Step 1: Convert to string
    str_n = str(n)

    # Step 2: Reverse the string
    reversed_str = str_n[::-1]

    # Step 3: Convert back to integer
    return int(reversed_str)

# Your task is to implement a function that duplicates every digit in a given non-negative integer number, n. For example, if n equals
# 1234, the function should return 11223344.
# To prevent possible integer overflow, it is guaranteed that n will be a non-negative integer that does not exceed 10000
# Solve this task without converting n into a string or performing any other type of casting. Your job is to work strictly with integer
# operations.
# Keynote:
# Focus on the essence of the problem, which is processing each digit of the number independently while maintaining the digit order.
# There is no need to look for mathematical patterns or clever simplifications; plain and straightforward processing will suffice. Utilize
# the toolbox of basic programming skills: loops, conditions, and mathematical operations. Good luck!

def duplicate_digits(n):
    result = 0
    place = 1

    while n > 0:
        digit = n % 10
        n //= 10

        # Add duplicated digit at the current place
        result += digit * place
        place *= 10
        result += digit * place
        place *= 10

    return result

# You are tasked with writing a function that takes a positive integer, n, as an input and returns the number of consecutive equal digits
# in the number. Specifically, your function should identify pairs of digits in n that are equal and consecutive and return the count of
# these pairs. For instance, if n = 113224, it contains two groups of consecutive equal digits: 11 and 22. Therefore, the output should be 2. For n = 444, the output should also be 2, as there are two groups of 44 in this number.
# Keep in mind that n will be a positive integer ranging from 1 to 100,000,000 , inclusive.
# Note: You are not permitted to convert the number into a string or any other iterable structure for this task. You should work directly
# with the number.

def count_consecutive_equal_pairs(n):
    prev_digit = -1
    pair_count = 0

    while n > 0:
        current_digit = n % 10
        n //= 10

        if current_digit == prev_digit:
            pair_count += 1
        prev_digit = current_digit

    return pair_count


def special_order(inputString):
    length = len(inputString)
    mid = length // 2

    if length == 1:
        first_part = inputString
        second_part = ''
    else:
        first_part = inputString[-1:mid - 1:-1]
        second_part = inputString[:mid]
    return first_part + second_part


# You are provided with a string of n lowercase English alphabet letters (from 'a' to 'z'), where n ranges from 1 to 100, inclusive.
# You must create a new string by selecting characters from the given string in a specific order: select each character that comes k
# characters after the previous selection in the string. If you reach the end of the string, you should continue from the beginning.
# Write a Python function, repeat_char_jump(inputString, step). The function takes two parameters: inputString and step, where inputString
# is the string you are working with, and step is an integer that denotes the number of characters to skip with each jump. The value of
# step ranges from 1 to the length of the input string. The function should return a newly formed string consisting of characters selected
# in the order dictated by the jump length step.
# For example, if inputString is "abcdefg" and step is 3, the function should return "adgcfbe". This is because after 'a', comes 'd' (3
# characters after 'a'), followed by 'g' (3 characters after 'd', circling back to the start of the string after 'g'), and so on.
# Note: You should continue jumping from the start of the string when you reach the end.
# For this task, assume that you need not use a character more than once. When you have traversed all the characters at least once, you
# can stop and return the output string as it is. It is guaranteed, that the inputs will be given in a way, that following the traversal
# pattern, you'll traverse all the characters.

def repeat_char_jump(inputString, k):
    n = len(inputString)
    result = ''
    used = [False] * n  # track which characters are already used
    index = 0

    for _ in range(n):  # we are guaranteed to use each character exactly once
        result += inputString[index]
        used[index] = True
        index = (index + k) % n
        # Skip already used positions (they won’t appear in this loop due to guarantee)

    return result

def repeat_char_jump_2(inputString, step):
    n = len(inputString)
    visited = [False] * n
    result = []
    index = 0
    count = 0

    while count < n:
        if not visited[index]:
            result.append(inputString[index])
            visited[index] = True
            count += 1
        index = (index + step) % n

    return ''.join(result)

# In this task, you are given a string s, and your goal is to produce a new string following a specific pattern. You are to take characters
# in sets of three, reverse the characters in each set, and then place them back into the string in their original positions, preserving
# the reverse order within each set. If 1 or 2 characters remain at the end (because the length of the string is not divisible by 3), they
# should be left as they are.The string s contains only lowercase English letters, with its length ranging from 1 to 300, inclusive.
# For example, if you are given the input 'abcdef', the output should be 'cbafed'. For the input 'abcdefg', your function should provide
# 'cbafedg'.

def reverse_in_triplets(s):
    result = []
    for i in range(0, len(s), 3):
        triplet = s[i:i+3]
        if len(triplet) == 3:
            result.append(triplet[::-1])  # Reverse the triplet
        else:
            result.append(triplet)  # Leave 1 or 2 characters as they are
    return ''.join(result)


# Our task is as follows: Given an array of integers, we aim to return a new array that emerges from the center of the original array and
# alternates direction towards both ends. In other words, the first element of our new array will be the middle element of the original
# one. After establishing the starting point, we will alternate between the elements to the left and to the right of the initial center
# until we have incorporated every element. If the length of the initial array is even, we first take the the element to the left of the
# center, then the one to the right of the center, then do the alternation as described above.For example, for numbers = [1, 2, 3, 4, 5],
# the output should be [3, 2, 4, 1, 5].
# This task might initially seem complex. However, don't worry. We're going to break it down and construct our solution step by step.
# Keep in mind an additional condition: the length of the array—represented as n—can vary from 1 to 100,000, inclusive.

def iterateMiddleToEnd(numbers):
    mid = len(numbers) // 2  # The index of the left middle element
    if len(numbers) % 2 == 1:
        left = mid - 1  # The left to the middle element
        right = mid + 1  # The right to the middle element
        new_order = [numbers[mid]]  # Adding the middle element to the resulting array
    else:
        left = mid - 1  # Left middle element
        right = mid  # Right middle element
        new_order = []  # No elements in the resulting array for now

    while left >= 0 and right < len(numbers):
        new_order.append(numbers[left])
        new_order.append(numbers[right])
        left -= 1
        right += 1

    return new_order


# You are provided with an array of n integers, where n can range from 1 to 200, inclusive. Your task is to create a new array that takes
# two pairs of 'opposite' elements from the original array at each iteration, starting from the center and moving towards both ends, to
# calculate the resulting multiplication of each pair.By 'opposite' elements, we mean pairs of elements symmetrically located relative to
# the array's center. If the array's length is odd, the center element doesn't have an opposite and should be included in the result array
# as is.
# Each element in the array can range from -100 to 100, inclusive.
# For example, if the input array is [1, 2, 3, 4, 5], the returned array should be [3, 8, 5]. This is because the center element 3 remains
# as it is, the multiplication of 2 and 4 is 8, and the multiplication of 1 and 5 is 5.def multiply_opposites(arr):

def multiply_opposites(arr):
    n = len(arr)
    result = []
    mid = n // 2

    # If odd, include center element first
    if n % 2 == 1:
        result.append(arr[mid])

    # Process pairs outward from the center
    for i in range(1, mid + 1):
        left = mid - i
        right = n - (mid - i) - 1
        result.append(arr[left] * arr[right])  # append

    return result


# You are given an array of n integers, where n can range from 1 to 500, inclusive. Your task is to create a new array in which each
# element is a tuple, determined by pairing elements from the middle to both ends of the original array.
# If the original array has an odd length, pair the middle element with 0. If the original array has an even length, start pairing from
# the two middle elements. Continue the pairing by alternating elements from the left and the right until all elements have been paired.
# After creating the paired elements, return the new array of tuples. Ultimately, your result should be an array of tuples, each of size
# two. Each element within a tuple, as well as within the array, can range from -1000 to 1000, inclusive.
# For example, if the input is numbers = [1, 2, 3, 4, 5], the output should be [(3, 0), (2, 4), (1, 5)]. Similarly, if the input is numbers
# = [1, 2, 3, 4], the output should be [(2, 3), (1, 4)].

def pair_from_middle(numbers):
    n = len(numbers)
    result = []

    if n % 2 == 1:  # odd length
        mid = n // 2
        result.append((numbers[mid], 0))
        left = mid - 1
        right = mid + 1
    else:  # even length
        left = (n // 2) - 1
        right = n // 2

    while left >= 0 and right < n:
        result.append((numbers[left], numbers[right]))
        left -= 1
        right += 1

    return result


# You are provided with an array of n integers, where n ranges from 1 to 501 and is always an odd number. The elements of the array span
# values from −1000000 to 1000000 , inclusive. The goal is to return a new array constructed by traversing the initial array in a specific
# order, outlined as follows:
# Begin with the middle element of the array.
# For each subsequent pair of elements, alternate between taking two elements from the left and two elements from the right, relative to
# the middle. If fewer than two elements remain on either side, include all the remaining elements from that side.
# Continue this process until all elements of the array have been traversed. For example, for array = [1, 2, 3, 4, 5, 6, 7], your function
# should return [4, 2, 3, 5, 6, 1, 7]. And for array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], your function should return
# [6, 4, 5, 7, 8, 2, 3, 9, 10, 1, 11].
def unusual_traversal(array):
    # TODO: implement this function
    n = len(array)
    mid = n // 2
    result = [array[mid]]

    left = mid - 1
    right = mid + 1
    while left >= 0 and right < n:
        if left >= 1 and right < n - 1:
            result.append(array[left - 1])
            result.append(array[left])
            result.append(array[right])
            result.append(array[right + 1])
            left -= 2
            right += 2
        else:
            result.append(array[left])
            result.append(array[right])
            left -= 1
            right += 1
    return result


# our goal is to write a Python function that accepts a string as input and identifies all consecutive groups of identical characters
# within it. A group can be defined as a segment of the text where the same character is repeated consecutively.Your function should
# return a list of tuples. Each tuple will consist of the repeating character and the length of its repetition. For instance, if the input
# string is "aaabbcccaae", your function should output: [('a', 3), ('b', 2), ('c', 3), ('a', 2), ('e', 1)].

def group_repeats(s):
    groups = []
    current_group_char = None
    current_group_length = 0

    for char in s:
        if char.isdigit() or char.isalpha():
            if char == current_group_char:
                current_group_length += 1
            else:
                if current_group_char is not None:
                    groups.append((current_group_char, current_group_length))
                current_group_char = char
                current_group_length = 1
    if current_group_char is not None:
        groups.append((current_group_char, current_group_length))

    return groups


# In this task, you are to write a Python function that implements the concept of Run-Length Encoding (RLE) on an alphanumeric input string.
# Run-length encoding is a simple form of data compression where sequences of data entities that are the same are stored as a single data
# entity along with its count. Each count must immediately follow the character it is associated with.Your function's name should be
# encode_rle. It takes a string as an input argument and returns a new string that represents the input's run-length encoding.Your function
# should operate only on alphanumeric characters (numbers 0-9 and uppercase and lowercase letters A-Z, a-z). For any other types of characters
# in the string, simply ignore them and do not include them in the final encoded output.For instance, if the input string is "aaabbcccdde",
# the output should be "a3b2c3d2e1". If the input string includes non-alphanumeric characters, such as "aaa@@bb!!c#d**e", the output should
# be "a3b2c1d1e1".We assume that the given input string could have up to 500 characters.

def encode_rle(s):
    # "aaabbcccdde" -> a3b2c3d2e1
    currentChar = None
    count = 0
    result = ''

    for char in s:
        if char.isalpha() or char.isnumeric():
            if char == currentChar:
                count += 1
            else:
                if currentChar is not None:
                    result = result + currentChar + str(count)
                currentChar = char
                count = 1
    if currentChar is not None:
        result = result + currentChar + str(count)

    return result


def encode_rle_2(s):
    result = []
    i = 0
    n = len(s)

    while i < n:
        # Skip non-alphanumeric characters
        if not s[i].isalnum():
            i += 1
            continue

        count = 1
        # Count consecutive repetitions of the current alphanumeric character
        while i + 1 < n and s[i] == s[i + 1]:
            if not s[i + 1].isalnum():
                break
            count += 1
            i += 1

        result.append(f"{s[i]}{count}")
        i += 1

    return ''.join(result)

# Your task is to write a Python function that takes in a string and identifies all the consecutive groups of identical characters within
# it, with the analysis starting from the end of the string rather than from its beginning. A group is defined as a segment of the text
# where the same character is repeated consecutively. Your function should return a list of tuples. Each tuple will consist of the
# repeating character and the number of its repetitions. For instance, if the input string is "aaabbcccdde", the function should output:
# [('e', 1), ('d', 2), ('c', 3), ('b', 2), ('a', 3)].
# Note that the input string cannot be empty; in other words, it must contain at least one character, and its length must not exceed 500
# characters. The return should also be in reverse order, starting from the group of repeated characters at the end of the string and
# moving backward.Put your knowledge and skills into action to solve this reverse pattern identification puzzle!
def reverse_group_counts(s):
    result = []
    i = len(s) - 1

    while i >= 0:
        current_char = s[i]
        count = 1
        i -= 1
        while i >= 0 and s[i] == current_char:
            count += 1
            i -= 1
        result.append((current_char, count))

    return result

    while i < n:
        pair = s[i:i + 2]
        count = 1
        i += 2
        while i < n and s[i:i + 2] == pair:
            count += 1
            i += 2
        result.append(f"{pair}{count}")

    return ''.join(result)


# In this task, you need to write a Python function that finds repeating two-character patterns in a string. The function should identify
# when the same pair of characters appear next to each other in the string and count how many times each pair repeats consecutively.The
# function should return a new string that lists each pair followed by the number of times it repeats consecutively. For example, let's
# break down the input string "aaabbabbababacab":
# Divide the string into pairs: "aa" "ab" "ba" "bb" "ab" "ab" "ac" "ab"
# Note the consecutive pairs: "ab" appears twice consecutively in the middle. Therefore, the output string will be: "aa1ab1ba1bb1ab2ac1ab1".
# Similarly, for the input string "aaababbababaca", the output should be "aa1ab2ba3ca1". Key points to remember: The input string always
# has an even number of characters. The string contains only lowercase letters. The string length can be up to 500 characters.
# Focus on finding consecutive repetitions of the same two-character patterns.

def count_repeating_pairs(s):
    result = []
    i = 0
    n = len(s)

    while i < n:
        pair = s[i:i + 2]
        count = 1
        i += 2
        while i < n and s[i:i + 2] == pair:
            count += 1
            i += 2
        result.append(f"{pair}{count}")

    return ''.join(result)



if (__name__ == "__main__"):
    numbers = [1, 2, 3, 4, 5, 6, 7]
    for_loop(numbers)
    numbers = [12, 45, 67, 34, 89, 56]
    pair_with_geometric_mean(numbers)
    numbers = [12, 21, 34, 43, 56, 65]
    reversed_string(numbers)
    print(sum_with_opposites([1, 2, 3, 4, 5]))  # [6, 6, 6]
    print(sum_with_opposites([-3, -2, 0, 2, 3]))  # [0, 0, 0]
    print(sum_with_opposites([10, -5]))  # [5]
    print(sum_even_digits(4625))   # Output: 12
    print(sum_even_digits(13579))  # Output: 0
    print(sum_even_digits(24680))  # Output: 20
    print(product_of_odd_digits(43172))  # Output: 21 (3 * 1 * 7)
    print(product_of_odd_digits(2468))   # Output: 0 (no odd digits)
    print(product_of_odd_digits(13579))  # Output: 945 (1 * 3 * 5 * 7 * 9)
    print(reverse_integer(12345))  # Output: 54321
    print(reverse_integer(1230))  # Output: 321
    print(reverse_integer(100))  # Output: 1
    print(reverse_integer_2(12345))  # Output: 54321
    print(reverse_integer_2(1230))  # Output: 321
    print(reverse_integer_2(100))  # Output: 1
    print(duplicate_digits(1234))  # Output: 11223344
    print(count_consecutive_equal_pairs(113224))  # Output: 2 (11, 22)
    print(count_consecutive_equal_pairs(444))     # Output: 2 (44, 44)
    print(count_consecutive_equal_pairs(123456))  # Output: 0
    print(count_consecutive_equal_pairs(100001))  # Output: 3 (00, 00)
    # For example, if the inputString is "abcdefg", the function should return "gfedabc".
    inputString = 'abcdefg'
    special_order(inputString)
    print(repeat_char_jump('cgldxdv', 3))
    print(repeat_char_jump('abcdefg', 3))  # Output: "adgcfbe"
    print(repeat_char_jump_2('cgldxdv', 3))
    print(repeat_char_jump_2('abcdefg', 3))  # Output: "adgcfbe"
    print(reverse_in_triplets("abcdef"))  # Output: 'cbafed'
    print(reverse_in_triplets("abcdefg"))  # Output: 'cbafedg'
    numbers = [1, 2, 3, 4, 5]
    print(iterateMiddleToEnd(numbers))
    print(multiply_opposites([1, 2, 3, 4, 5]))  # Output: [3, 8, 5]
    print(multiply_opposites([1, 2, 3, 4]))  # Output: [6, 4]
    print(multiply_opposites([7]))  # Output: [7]
    print(pair_from_middle([1, 2, 3, 4, 5]))
    # Output: [(3, 0), (2, 4), (1, 5)]
    print(pair_from_middle([1, 2, 3, 4]))
    # Output: [(2, 3), (1, 4)]
    print(pair_from_middle([7]))
    # Output: [(7, 0)]
    print(pair_from_middle([10, 20]))
    # Output: [(10, 20)]
    print(unusual_traversal([1, 2, 3, 4, 5, 6, 7]))
    # Output: [4, 2, 3, 5, 6, 1, 7]
    print(unusual_traversal([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]))
    # Output: [6, 4, 5, 7, 8, 2, 3, 9, 10, 1, 11]
    print(unusual_traversal([42]))
    # Output: [42]
    print(unusual_traversal([1, 2, 3]))
    # Output: [2, 1, 3]
    print(group_repeats("aaabbcccaae"))
    print(encode_rle('aaabbcccdde'))
    print(encode_rle_2("aaabbcccdde"))  # Output: "a3b2c3d2e1"
    print(encode_rle_2("aaa@@bb!!c#d**e"))  # Output: "a3b2c1d1e1"
    print(encode_rle_2("AaaBBbb111"))  # Output: "A1a2B2b213"
    print(encode_rle_2("abc!!xyz"))  # Output: "a1b1c1x1y1z1"
    print(encode_rle_2("$$$"))  # Output: ""
    print(encode_rle_2(""))  # Output: ""
    print(reverse_group_counts("aaabbcccdde"))
    # Output: [('e', 1), ('d', 2), ('c', 3), ('b', 2), ('a', 3)]
    print(reverse_group_counts("aabbbaa"))
    # Output: [('a', 2), ('b', 3), ('a', 2)]
    print(reverse_group_counts("xyz"))
    # Output: [('z', 1), ('y', 1), ('x', 1)]
    print(reverse_group_counts("aaaa"))
    # Output: [('a', 4)]
    print(reverse_group_counts("a"))
    # Output: [('a', 1)]
    print(Counter(list("aaabbcccdde"))) # import from collections. Counter({'a': 3, 'c': 3, 'b': 2, 'd': 2, 'e': 1})
    # collections.Counter
    myList = [1, 1, 2, 3, 4, 5, 3, 2, 3, 4, 2, 1, 2, 3]
    print(Counter(myList))
    print(Counter(myList).items())
    print(Counter(myList).keys())
    print(Counter(myList).values())
    #
    print(count_repeating_pairs("aaabbabbababacab"))
    # Output: "aa1ab1ba1bb1ab2ac1ab1"
    print(count_repeating_pairs("aaababbababaca"))
    # Output: "aa1ab2ba3ca1"
    print(count_repeating_pairs("abababab"))
    # Output: "ab4"
    print(count_repeating_pairs("aaaaaa"))
    # Output: "aa3"
    print(count_repeating_pairs("abacabadabacabae"))
    # Output: "ab1ac1ab1ad1ab1ac1ab1ae1"
