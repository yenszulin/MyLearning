# You are provided with a list of n integers, where n ranges from 2 to 200, inclusive. The task is to return a list of tuples, each
# containing a pair of an integer and its reverse counterpart. In this context, the reverse counterpart of a number is the number with
# its digits reversed. For example, the reverse counterpart of 123 is 321. You must iterate through the list to find the reverse
# counterpart for each integer. If this reversed number exists in the list, create a tuple with the original number and its reverse
# counterpart. If not, skip it.
# Your output should be a list of tuples with the original numbers and their reverse counterparts. The integers in the given list will
# range from 1 to 99999, inclusive.
# Note: The reverse counterpart of a single digit number is the same number. For numbers that result in leading zeros when reversed
# (e.g., 100 becomes 001, which is 1), consider only the integer value (i.e., 1). It's guaranteed that the original list will not
# contain integers with leading zeros.
# For example, for numbers = [12, 21, 34, 43, 56, 65], the output should be solution(numbers) = [(12, 21), (21, 12), (34, 43), (43, 34),
# (56, 65), (65, 56)].
def reversed_string(numbers):
    # TODO: implement solution here
    number_set = set(numbers)  # For fast lookup
    result = []

    for num in numbers:
        reversed_num = int(str(num)[::-1])
        if reversed_num in number_set:
            result.append((num, reversed_num))

    return result


if __name__ == "__main__":
    numbers = [12, 21, 34, 43, 56, 65]
    print(reversed_string(numbers))

