# You are given an input array consisting of n integers ranging from 0 to 100, inclusive, where n represents the length of the array.
# Your task is to return a new array of tuples. Each tuple should consist of an element from the input array paired with its geometrical
# mean with the 'opposite' element. The 'opposite' element of any element in the array is defined as the element at the corresponding
# position from the end of the array.

import math

def pair_with_geometric_mean(numbers):
    # TODO: implement this function
    n = len(numbers)
    result = []

    for i in range(n):
        elem = numbers[i]
        opposite = numbers[n - 1 - i]  # Opposite element
        geo_mean = math.sqrt(elem * opposite)
        result.append((elem, geo_mean))

    return result

if __name__ == "__main__":
    numbers = [1, 2, 3, 4, 5]
    print(pair_with_geometric_mean(numbers))
