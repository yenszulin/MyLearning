def for_loop(numbers):
    result = []
    n = len(numbers)
    for i in range(n):
        result.append((numbers[i], numbers[n - i - 1]))
    return result


if __name__ == "__main__":
    numbers =[1, 2, 3, 4, 5, 6, 7]
    for_loop(numbers)  # [(1, 7), (2, 6), (3, 5), (4, 4), (5, 3), (6, 2), (7, 1)]
