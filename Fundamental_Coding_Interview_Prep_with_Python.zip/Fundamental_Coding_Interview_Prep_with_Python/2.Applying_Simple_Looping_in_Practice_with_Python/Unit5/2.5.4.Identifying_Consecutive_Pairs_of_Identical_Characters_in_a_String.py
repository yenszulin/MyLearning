# In this task, you need to write a Python function that finds repeating two-character patterns in a string. The function should identify
# when the same pair of characters appear next to each other in the string and count how many times each pair repeats consecutively.The
# function should return a new string that lists each pair followed by the number of times it repeats consecutively. For example, let's
# break down the input string "aaabbabbababacab":
# Divide the string into pairs: "aa" "ab" "ba" "bb" "ab" "ab" "ac" "ab"
# Note the consecutive pairs: "ab" appears twice consecutively in the middle. Therefore, the output string will be: "aa1ab1ba1bb1ab2ac1ab1".
# Similarly, for the input string "aaababbababaca", the output should be "aa1ab2ba3ca1". Key points to remember: The input string always
# has an even number of characters. The string contains only lowercase letters. The string length can be up to 500 characters.
# Focus on finding consecutive repetitions of the same two-character patterns.

def count_repeating_pairs(s):
    result = []
    i = 0
    n = len(s)

    while i < n:
        pair = s[i:i + 2]
        count = 1
        i += 2
        while i < n and s[i:i + 2] == pair:
            count += 1
            i += 2
        result.append(f"{pair}{count}")

    return ''.join(result)


if __name__ == "__main__":
    print(count_repeating_pairs("aaabbabbababacab"))
    # Output: "aa1ab1ba1bb1ab2ac1ab1"
    print(count_repeating_pairs("aaababbababaca"))
    # Output: "aa1ab2ba3ca1"
    print(count_repeating_pairs("abababab"))
    # Output: "ab4"
    print(count_repeating_pairs("aaaaaa"))
    # Output: "aa3"
    print(count_repeating_pairs("abacabadabacabae"))
    # Output: "ab1ac1ab1ad1ab1ac1ab1ae1"
