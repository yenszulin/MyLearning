# our goal is to write a Python function that accepts a string as input and identifies all consecutive groups of identical characters
# within it. A group can be defined as a segment of the text where the same character is repeated consecutively.Your function should
# return a list of tuples. Each tuple will consist of the repeating character and the length of its repetition. For instance, if the input
# string is "aaabbcccaae", your function should output: [('a', 3), ('b', 2), ('c', 3), ('a', 2), ('e', 1)].

def group_repeats(s):
    groups = []
    current_group_char = None
    current_group_length = 0

    for char in s:
        if char.isdigit() or char.isalpha():
            if char == current_group_char:
                current_group_length += 1
            else:
                if current_group_char is not None:
                    groups.append((current_group_char, current_group_length))
                current_group_char = char
                current_group_length = 1
    if current_group_char is not None:
        groups.append((current_group_char, current_group_length))

    return groups


if __name__ == "__main__":
    print(group_repeats("aaabbcccaae"))