def special_order(inputString):
    length = len(inputString)
    mid = length // 2

    if length == 1:
        first_part = inputString
        second_part = ''
    else:
        first_part = inputString[-1:mid - 1:-1]
        second_part = inputString[:mid]
    return first_part + second_part

if __name__ == "__main__":
    # For example, if the inputString is "abcdefg", the function should return "gfedabc".
    inputString = 'abcdefg'
    special_order(inputString)

