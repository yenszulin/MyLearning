# You are tasked with writing a Python function, solution(inputString). This function will take inputString as a
# parameter, a string composed of lowercase English alphabet letters ('a' to 'z') with a length anywhere between
# 1 to 100 characters. The function will then return a new string, which is derived from the input string but
# with characters selected in the order we just discussed.
# For example, if the inputString is "abcdefg", the function should return "agbfced"

def solution(inputString):
    result = ''
    length = len(inputString)
    for i in range(length // 2 + length % 2):
        result += inputString[i]
        if length - 1 - i != i:
            result += inputString[length - 1 - i]
    return result

if __name__ == "__main__":
    solution("abcdefg")