# Today, our objective is to create a function that operates on an integer input. The task might seem simple, but it requires some
# ingenuity. Here's the mission: given an integer, n, we need to calculate and return the sum of its even digits — and here's the
# clincher — without converting n into a string. For instance, if n equals 4625, the output should be 12 because the sum of the even
# digits 4, 6, and 2 equals 12.
def sum_even_digits(n):
    digit_sum = 0
    while n > 0:
        digit = n % 10      # Get last digit
        if digit % 2 == 0:  # Check if the digit is even
            digit_sum += digit
        n = n // 10  # Remove the last digit
    return digit_sum


if __name__ == "__main__":
    print(sum_even_digits(4625))   # Output: 12
    print(sum_even_digits(13579))  # Output: 0
    print(sum_even_digits(24680))  # Output: 20
