def product_of_odd_digits(n):
    product = 1
    has_odd = False

    while n > 0:
        digit = n % 10
        if digit % 2 == 1:  # Check if the digit is odd
            product *= digit
            has_odd = True
        n //= 10  # Remove the last digit

    return product if has_odd else 0

if __name__ == "__main__":
    print(product_of_odd_digits(43172))  # Output: 21 (3 * 1 * 7)
    print(product_of_odd_digits(2468))   # Output: 0 (no odd digits)
    print(product_of_odd_digits(13579))  # Output: 945 (1 * 3 * 5 * 7 * 9)