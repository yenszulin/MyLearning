# You are tasked with writing a function that takes a positive integer, n, as an input and returns the number of consecutive equal digits
# in the number. Specifically, your function should identify pairs of digits in n that are equal and consecutive and return the count of
# these pairs. For instance, if n = 113224, it contains two groups of consecutive equal digits: 11 and 22. Therefore, the output should be 2. For n = 444, the output should also be 2, as there are two groups of 44 in this number.
# Keep in mind that n will be a positive integer ranging from 1 to 100,000,000 , inclusive.
# Note: You are not permitted to convert the number into a string or any other iterable structure for this task. You should work directly
# with the number.

def count_consecutive_equal_pairs(n):
    prev_digit = -1
    pair_count = 0

    while n > 0:
        current_digit = n % 10
        n //= 10

        if current_digit == prev_digit:
            pair_count += 1
        prev_digit = current_digit

    return pair_count


if __name__ == "__main__":
    print(count_consecutive_equal_pairs(113224))  # Output: 2 (11, 22)
    print(count_consecutive_equal_pairs(444))     # Output: 2 (44, 44)
    print(count_consecutive_equal_pairs(123456))  # Output: 0
    print(count_consecutive_equal_pairs(100001))  # Output: 3 (00, 00)
