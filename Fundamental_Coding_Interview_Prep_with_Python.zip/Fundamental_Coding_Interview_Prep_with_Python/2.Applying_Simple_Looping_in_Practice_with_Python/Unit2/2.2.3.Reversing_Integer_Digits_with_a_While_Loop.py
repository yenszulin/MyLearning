# Your task is to construct a function that accepts an integer n and returns the integer with the same digits as n, but in reverse order.
# You should implement your solution using a while loop.For instance, if the input is 12345, the output should be 54321.
# Keep in mind that n will always be a positive integer between 1 and 100000000
# Do not use built-in functions that convert the integer to another data type, such as a string, to reverse it. Solve the problem purely
# using mathematical operations and loop constructs.
# Note that when the result has leading zeros, you should consider only the integer value (e.g., 1230 becomes 321 after the operation).

def reverse_integer(n):
    reversed_num = 0

    while n > 0:
        digit = n % 10
        reversed_num = reversed_num * 10 + digit
        n //= 10

    return reversed_num

def reverse_integer_2(n):
    # Step 1: Convert to string
    str_n = str(n)

    # Step 2: Reverse the string
    reversed_str = str_n[::-1]

    # Step 3: Convert back to integer
    return int(reversed_str)



if __name__ == "__main__":
    print(reverse_integer(12345))  # Output: 54321
    print(reverse_integer(1230))  # Output: 321
    print(reverse_integer(100))  # Output: 1
    print(reverse_integer_2(12345))  # Output: 54321
    print(reverse_integer_2(1230))  # Output: 321
    print(reverse_integer_2(100))  # Output: 1