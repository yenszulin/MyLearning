# You are provided with a string of alphanumeric characters in which each number, regardless of the number of digits, is always followed by
# at least one alphabetic character before the next number appears. The task requires you to return a transformed version of the string
# wherein the first alphabetic character following each number is moved to a new position within the string and characters in between are
# removed. Specifically, for each number in the original string, identify the next letter that follows it, and then reposition that
# character to directly precede the number. All spaces and punctuation marks between the number and the letter are removed.
# The length of the string s ranges from 3 to 1000000 (inclusive), and the string contains at least one number. The numbers in the string
# are all integers and are non-negative. Here is an example for better understanding:
# Given the string: "I have 2 apples and 5! oranges and 3 grapefruits." The function should return:
# "I have a2pples and o5ranges and g3rapefruits."
# In this instance, the character 'a' following the number 2 is moved to come before the 2, the 'o' succeeding the 5 is placed before the
# 5, and the 'g' subsequent to the 3 is repositioned to precede the 3. Punctuation marks and spaces in between are removed.
# Please note that the operation should maintain the sequential order of the numbers and the rest of the text. Considering this, the task
# is not solely about dividing a string into substrings but also about modifying them. This will test your expertise in Python string
# operations and type conversions.
def transform_string(s):
    result = []
    i = 0
    n = len(s)

    while i < n:
        if s[i].isdigit():
            # Capture the full number
            num_start = i
            while i < n and s[i].isdigit():
                i += 1
            num = s[num_start:i]

            # Skip any non-alpha characters until we find the next letter
            j = i
            while j < n and not s[j].isalpha():
                j += 1

            if j < n:
                letter = s[j]
                # Append the letter before the number
                result.append(letter + num)
                i = j + 1  # Move past the letter
            else:
                # No letter found after the number (edge case)
                result.append(num)
        else:
            result.append(s[i])
            i += 1

    return ''.join(result)


if (__name__ == "__main__"):
    s = "I have 2 apples and 5! oranges and 3 grapefruits."
    print(transform_string(s))

