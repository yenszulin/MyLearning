# Task Statement and Description
# The task du jour involves creating a Python function named parse_and_multiply_numbers(). The function will take a string as input. This
# input string is quite special — it will have numbers and words jumbled together in a free-spirited manner.
# The function's job is to parse this input string, find all the numbers, convert these numbers (which are currently strings) into integer
# data types, subsequently multiply all these numbers together. The output? It’s the product of all those numbers!
# For you to get an idea, let's illustrate with an example. For the input string "I have 2 apples and 5 oranges," our function should
# return the product of 2 and 5, which is 10.

def parse_and_multiply_numbers(input_string):
    num = ""
    numbers = []
    for char in input_string:
        if char.isdigit():
            num += char
        elif num:
            numbers.append(int(num))
            num = ""
    if num:
        numbers.append(int(num))
    result = 1
    for number in numbers:
        result *= number
    return result

if (__name__ == "__main__"):
    print(parse_and_multiply_numbers("I have 2 apples and 5 oranges,"))