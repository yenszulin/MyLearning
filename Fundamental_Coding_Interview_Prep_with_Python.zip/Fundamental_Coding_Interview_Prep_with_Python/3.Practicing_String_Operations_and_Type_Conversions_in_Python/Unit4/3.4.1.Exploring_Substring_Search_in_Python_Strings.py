# Task Statement and Description
# Here's our challenge: we have two lists of strings of the same length, one containing the "original"
# strings and the other, the "substrings". We're to identify all occurrences of each substring within its
# corresponding original string and return a list of the starting indices of these occurrences. Remember,
# index counting should start from 0.
#
# Example
#
# If we take the following lists: Original List: ["HelloWorld", "LearningPython", "GoForBroke", "BackToBasics"]
# Substring List: ["loW", "ear", "o", "Ba"].
#
# This will produce the following outputs: In "HelloWorld", "loW" starts at index 3. In "LearningPython",
# "ear" starts at index 1. In "GoForBroke", "o" appears at indices 1, 3, and 7. In "BackToBasics",
# "Ba" starts at indices 0 and 6.
#
# So, if findSubString(["HelloWorld", "LearningPython", "GoForBroke", "BackToBasics"], ["loW", "ear", "o", "Ba"])
# is called, the function should return
# [
#     "The substring 'loW' was found in the original string 'HelloWorld' at position(s) 3.",
#     "The substring 'ear' was found in the original string 'LearningPython' at position(s) 1.",
#     "The substring 'o' was found in the original string 'GoForBroke' at position(s) 1, 3, 7.",
#     "The substring 'Ba' was found in the original string 'BackToBasics' at position(s) 0, 6."
# ]

def findSubString(orig_strs, substrs):
    result_arr = []

    for original, substring in zip(orig_strs, substrs):
        start_pos = original.find(substring)
        match_indices = []
        while start_pos != -1:
            match_indices.append(str(start_pos))
            start_pos = original.find(substring, start_pos + 1)
        result_arr.append(f"The substring '{substring}' was found in the original string '{original}' at position(s) {', '.join(match_indices)}.")

    return result_arr


if __name__ == "__main__":
    orig_list =  ["HelloWorld", "LearningPython", "GoForBroke", "BackToBasics"]
    sub_List = ["loW", "ear", "o", "Ba"]
    findSubString(orig_list,sub_List)