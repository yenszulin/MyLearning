# Task Statement and Description
# Consider a string filled with words. Your task is to write a Python function that accepts such a string. It then takes each of those words,
# reverses their character order, and, finally, stitches them all together to form a new string with reversed words.
def reverse_words_in_string(input_str):
    # split the string into words
    words = input_str.split()

    # reverse each word
    reversed_words = [''.join(reversed(word)) for word in words]

    # join the words back together with space as a separator
    result = ' '.join(reversed_words)

    return result


def reverse_words_in_string_2(text):
    words = text.split()
    reversed_words = [word[::-1] for word in words]
    return ' '.join(reversed_words)

if (__name__ == "__main__"):

    # Now we call the function and print the returned result outside of the function
    print(reverse_words_in_string("Hello neat pythonistas_123"))  # this will print: 'olleH taen 321_satsinohtyp'
    print(reverse_words_in_string_2("Hello neat pythonistas_123"))
