# You are given an initial date as a string in the format YYYY-MM-DD, along with an integer n which represents a number of days. Your task
# is to calculate the date after adding the given number of days to the initial date and return the result in the YYYY-MM-DD format.
# Keep these points in mind when resolving the task:
# The initial date string is always valid, formatted as YYYY-MM-DD, where YYYY denotes the year, MM the month, and DD the day.
# The given integer n is the number of days you have to add to the initial date and will be up to 50,000. The output should be a string
# showcasing the final date after adding n days, in the YYYY-MM-DD format.
# Your function will be in the form add_days(date: str, n: int) -> str.
# Constraints
# date = the date string in the YYYY-MM-DD format. The year YYYY will be from 1900 to 2100, inclusive. The month MM and the day DD will be
# valid for the given year. n = the integer representing the number of days you have to add to the initial date. n ranges from 1 to 50,000,
# inclusive. You should consider leap years in the calculation. A year is a leap year if it is divisible by 4, but century years (years
# divisible by 100) are not leap years unless they are divisible by 400. This means that the year 2000 was a leap year, although 1900 was
# not. The month and day result should always be two digits long, padding with a 0 if necessary. For example, July 9th should be formatted
# as "07-09".
# Example: For date = '1999-01-01' and n = 365, the output should be '2000-01-01'.

def is_leap_year(year):
    # Leap year logic
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)


def get_days_in_month(year, month):
    # Number of days in each month
    month_days = [31, 29 if is_leap_year(year) else 28, 31, 30, 31, 30,
                  31, 31, 30, 31, 30, 31]
    return month_days[month - 1]


def add_days(date: str, n: int) -> str:
    year, month, day = map(int, date.split('-'))

    while n > 0:
        days_in_current_month = get_days_in_month(year, month)
        remaining_days_in_month = days_in_current_month - day

        if n <= remaining_days_in_month:
            day += n
            n = 0
        else:
            n -= (remaining_days_in_month + 1)
            day = 1
            month += 1
            if month > 12:
                month = 1
                year += 1

    return f"{year:04d}-{month:02d}-{day:02d}"


from datetime import datetime, timedelta


def add_days_datetime(date: str, n: int) -> str:
    # Convert the input date string to a datetime object
    start_date = datetime.strptime(date, "%Y-%m-%d")

    # Add n days using timedelta
    new_date = start_date + timedelta(days=n)

    # Convert the new date back to string in the same format
    return new_date.strftime("%Y-%m-%d")


if (__name__ == "__main__"):
    input_date = '1999-01-01'
    print(add_days(input_date, 365))
    print(add_days('1999-01-01', 365))  # ➜ '2000-01-01'
    print(add_days('2000-02-28', 1))  # ➜ '2000-02-29' (leap year)
    print(add_days('2100-02-28', 1))  # ➜ '2100-03-01' (not a leap year)
    print(add_days_datetime('1999-01-01', 365))  # ➜ '2000-01-01'
    print(add_days_datetime('2000-02-28', 1))  # ➜ '2000-02-29' (leap year)
    print(add_days_datetime('2100-02-28', 1))  # ➜ '2100-03-01' (not a leap year)
