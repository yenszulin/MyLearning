# Task Statement and Description
# Imagine this: You receive a time formatted as a string in HH:MM:SS where HH, MM, and SS denote the hour, minute, and second, respectively.
# You are also given an integer representing a number of seconds. Your task is to calculate the new time after adding the provided seconds
# and output the result in the HH:MM:SS format.
# For example, if the input time is 05:10:30 and the number of seconds to add is 123, the output should be 05:12:33 since 123 seconds
# translate to 2 minutes and 3 seconds. Take note of these points when resolving this task:
# The input time is invariably a valid time string in the HH:MM:SS format, with HH ranging from 00 to 23, MM, and SS ranging from 00 to
# 59. The output ought to be a time in the same format.

def time_format(time, seconds):
    time_parts = [int(part) for part in time.split(":")]
    seconds_since_start = time_parts[0] * 3600 + time_parts[1] * 60 + time_parts[2]
    total_seconds = (seconds_since_start + seconds) % (24 * 3600)
    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


if (__name__ == "__main__"):
    time = '05:10:30'
    print(time_format(time, 123))
