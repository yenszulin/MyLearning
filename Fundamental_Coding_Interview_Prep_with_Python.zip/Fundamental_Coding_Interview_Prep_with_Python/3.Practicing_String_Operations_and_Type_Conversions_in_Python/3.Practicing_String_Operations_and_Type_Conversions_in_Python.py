# Task Statement and Description
# Consider a string filled with words. Your task is to write a Python function that accepts such a string. It then takes each of those words,
# reverses their character order, and, finally, stitches them all together to form a new string with reversed words.
def reverse_words_in_string(input_str):
    # split the string into words
    words = input_str.split()

    # reverse each word
    reversed_words = [''.join(reversed(word)) for word in words]

    # join the words back together with space as a separator
    result = ' '.join(reversed_words)

    return result

def reverse_words_in_string_2(text):
    words = text.split()
    reversed_words = [word[::-1] for word in words]
    return ' '.join(reversed_words)


# You are given a string of n characters, with n varying from 1 to 1000, inclusive. Your task is to write a Python function that takes this
# string as input, applies the following operations, and finally returns the resulting string. Split the given string into individual words
# , using a space as the separator. Convert each word into a list of its constituent characters, and shift each list once to the right
# (with the last element moving to the first position). After the rotations, reassemble each word from its list of characters.
# Join all the words into a single string, separating adjacent words with a single space. Return this final string as the function's output.
# The constraints for the problem are as follows: The input string will neither start nor end with a space, nor will it have multiple
# consecutive spaces. Each word will contain only alphabets and digits, and its length will range from 1 to 10.
# The words are case-sensitive; for example, 'word' and 'Word' are considered distinct. Your program should output a single string with the
# words rotated by their lengths while preserving their original order. As an illustration, consider the input string "abc 123 def".
# Applying the stated operations results in the output "cab 312 fde".

def rotate_each_word_right(s):
    words = s.split()  # Step 1: Split input into words
    rotated_words = []

    for word in words:
        # Step 2: Shift characters in each word once to the right
        if len(word) == 1:
            rotated = word
        else:
            rotated = word[-1] + word[:-1]
        rotated_words.append(rotated)

    # Step 3: Join rotated words with a space
    return ' '.join(rotated_words)

# Given a string consisting of words separated by whitespace, your task is to write a Python function that accepts this string. It then
# replaces each character in the words with the corresponding character opposite in the English alphabet and stitches them all together to
# form a new string.Here's what you need to consider:
# The input string will include between 1 and 100 words. Each word consists of characters separated by white space.
# A word is composed of characters ranging from a to z or A to Z. So, if a word contains a lowercase 'a', for instance, it should be
# replaced with 'z', 'b' with 'y', 'c' with 'x', and so on, maintaining the same case. For words with an uppercase 'A', it should be
# replaced with 'Z', 'B' with 'Y', 'C' with 'X', and so forth, while preserving the uppercase. The given string will not start or end with
# a space, and there will be no occurrence of double spaces. After transforming the characters of the words, form a new string by taking
# the last word first and appending the remaining words in their original order, each separated by spaces.
# Note: The opposite letter mappings are as follows: a ↔ z, b ↔ y, c ↔ x, ..., m ↔ n, n ↔ m, ..., x ↔ c, y ↔ b, z ↔ a. The mapping is
# case-sensitive. Example: For the input string "CapitaL letters", the output should be "ovggvih XzkrgzO".

def transform_opposite_and_reorder(input_str):
    def opposite_char(c):
        if c.islower():
            return chr(ord('z') - (ord(c) - ord('a')))
        elif c.isupper():
            return chr(ord('Z') - (ord(c) - ord('A')))
        else:
            return c

    words = input_str.split()

    # Apply opposite_char transformation to each word
    transformed_words = []
    for word in words:
        transformed = ''.join(opposite_char(c) for c in word)
        transformed_words.append(transformed)

    # Place last word first, then rest in original order
    reordered = [transformed_words[-1]] + transformed_words[:-1]

    return ' '.join(reordered)

# You are given a string filled with words. Your task is to write a Python function that takes this string as input. Your function should
# then capitalize the first letter of each word while making the rest of the letters lowercase. Finally, it should recombine the words into
# a new string where every word starts with a capital letter.Here's what to keep in mind: The input string will contain between 1 and 100
# words. Each word is a sequence of characters separated by white space. Words consist of characters ranging from a to z, A to Z, 0 to 9,
# or even an underscore _.
# The provided string will not start or end with a space, and it will not contain double spaces. After capitalizing the first character of
# each word and converting the rest to lowercase, the program should return a single string in which the words maintain their original
# order. If the first character of a word is not a letter (like a number or an underscore), keep it as is. Ignore cases where punctuation
# marks are attached to words (such as "Hello," or "world!"). Words and punctuation should retain their original places in your final
# output. You are not required to separate punctuation marks from the words in your solution.
# Example: For the input string "SoME rAndoM _TeXT", the output should be "Some Random _text".

def format_words(input_str):
    def capitalize_word(word):
        if not word:
            return word
        if word[0].isalpha():
            return word[0].upper() + word[1:].lower()
        else:
            return word[0] + word[1:].lower()

    words = input_str.split()
    formatted_words = [capitalize_word(word) for word in words]
    return ' '.join(formatted_words)


# Task Statement and Description
# The task du jour involves creating a Python function named parse_and_multiply_numbers(). The function will take a string as input. This
# input string is quite special — it will have numbers and words jumbled together in a free-spirited manner.
# The function's job is to parse this input string, find all the numbers, convert these numbers (which are currently strings) into integer
# data types, subsequently multiply all these numbers together. The output? It’s the product of all those numbers!
# For you to get an idea, let's illustrate with an example. For the input string "I have 2 apples and 5 oranges," our function should
# return the product of 2 and 5, which is 10.

def parse_and_multiply_numbers(input_string):
    num = ""
    numbers = []
    for char in input_string:
        if char.isdigit():
            num += char
        elif num:
            numbers.append(int(num))
            num = ""
    if num:
        numbers.append(int(num))
    result = 1
    for number in numbers:
        result *= number
    return result


# Let's imagine you are given a string that contains a series of words separated by a hyphen ("-"). Each word in the string can be a
# lowercase letter from 'a' to 'z' or a set of digits representing a number from 1 to 26. Your task is to parse this string and swap the
# type of each word: convert numbers into their corresponding English alphabet letters, and letters into their numerical equivalents. This
# means '1' should convert to 'a', and 'a' should convert to '1'.
# You need to return a new string with the converted words, rejoined with hyphens. Ensure you maintain the original order of the words from
# the input string in your output string. The input string's length should range from 1 to 1000 for this exercise. The string will never be
# empty, always containing at least one valid lowercase letter or numerical word. Remember, the transformation of words should be limited
# to converting numbers from 1 to 26 into their corresponding letters from 'a' to 'z', and vice versa.
# Example: For the input string "1-a-3-c-5", the output should be "a-1-c-3-e".

def swap_letter_number(input_str):
    def convert(token):
        if token.isdigit():
            num = int(token)
            if 1 <= num <= 26:
                return chr(ord('a') + num - 1)
        elif token.isalpha() and len(token) == 1:
            return str(ord(token) - ord('a') + 1)
        return token  # In case of unexpected input

    tokens = input_str.split('-')
    converted = [convert(token) for token in tokens]
    return '-'.join(converted)




# You are given a string s of length n, with n ranging from 1 to 500 inclusive. This string represents the complex and jumbled record of a
# sports game. It combines player names and scores but lacks a uniform structure. The player names consist of words made up of lowercase
# English alphabets (a-z), while the scores are integers ranging from 1 to 100 inclusive.Your mission involves writing a Python function
# solution(). This function should parse the given string, isolate the integers representing player scores, and return the sum of these
# scores. For instance, for the input string, "joe scored 5 points, while adam scored 10 points and bob scored 2, with an extra 1 point
# scored by joe", your function should return the sum 5 + 10 + 2 + 1, which totals 18.

def summing_valid_scores(input_string):
    number = ''
    totalSum = 0
    for char in input_string:
        if char.isnumeric():
            number += char
        else:
            if number != '':
                totalSum += int(number)
                number = ''
    return totalSum

import re

def summing_valid_scores_re(s):
    # Find all occurrences of digits (representing numbers) in the string
    numbers = re.findall(r'\b\d+\b', s)
    # Convert each found number to an integer and return their sum
    return sum(int(num) for num in numbers)


# You are provided with a string of alphanumeric characters in which each number, regardless of the number of digits, is always followed by
# at least one alphabetic character before the next number appears. The task requires you to return a transformed version of the string
# wherein the first alphabetic character following each number is moved to a new position within the string and characters in between are
# removed. Specifically, for each number in the original string, identify the next letter that follows it, and then reposition that
# character to directly precede the number. All spaces and punctuation marks between the number and the letter are removed.
# The length of the string s ranges from 3 to 1000000 (inclusive), and the string contains at least one number. The numbers in the string
# are all integers and are non-negative. Here is an example for better understanding:
# Given the string: "I have 2 apples and 5! oranges and 3 grapefruits." The function should return:
# "I have a2pples and o5ranges and g3rapefruits."
# In this instance, the character 'a' following the number 2 is moved to come before the 2, the 'o' succeeding the 5 is placed before the
# 5, and the 'g' subsequent to the 3 is repositioned to precede the 3. Punctuation marks and spaces in between are removed.
# Please note that the operation should maintain the sequential order of the numbers and the rest of the text. Considering this, the task
# is not solely about dividing a string into substrings but also about modifying them. This will test your expertise in Python string
# operations and type conversions.
def transform_string(s):
    result = []
    i = 0
    n = len(s)

    while i < n:
        if s[i].isdigit():
            # Capture the full number
            num_start = i
            while i < n and s[i].isdigit():
                i += 1
            num = s[num_start:i]

            # Skip any non-alpha characters until we find the next letter
            j = i
            while j < n and not s[j].isalpha():
                j += 1

            if j < n:
                letter = s[j]
                # Append the letter before the number
                result.append(letter + num)
                i = j + 1  # Move past the letter
            else:
                # No letter found after the number (edge case)
                result.append(num)
        else:
            result.append(s[i])
            i += 1

    return ''.join(result)

# Task Statement and Description
# Imagine this: You receive a time formatted as a string in HH:MM:SS where HH, MM, and SS denote the hour, minute, and second, respectively.
# You are also given an integer representing a number of seconds. Your task is to calculate the new time after adding the provided seconds
# and output the result in the HH:MM:SS format.
# For example, if the input time is 05:10:30 and the number of seconds to add is 123, the output should be 05:12:33 since 123 seconds
# translate to 2 minutes and 3 seconds. Take note of these points when resolving this task:
# The input time is invariably a valid time string in the HH:MM:SS format, with HH ranging from 00 to 23, MM, and SS ranging from 00 to
# 59. The output ought to be a time in the same format.

def time_format(time, seconds):
    time_parts = [int(part) for part in time.split(":")]
    seconds_since_start = time_parts[0] * 3600 + time_parts[1] * 60 + time_parts[2]
    total_seconds = (seconds_since_start + seconds) % (24 * 3600)
    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


# You are given two input arguments: an array of strings timePoints and an integer added_seconds. Each string in timePoints is in the
# HH:MM:SS format, representing a valid time from "00:00:00" to "23:59:59" inclusive. The integer added_seconds represents a number of
# seconds, ranging from 1 to 86,400. Your task is to create a new function, add_seconds_to_times(timePoints, added_seconds), which takes
# these two arguments and returns a new array of strings. Each string in the returned array is the new time, calculated by adding the
# provided added_seconds to the corresponding time in timePoints, formatted in HH:MM:SS.The array timePoints contains n strings, where n
# can be any integer from 1 to 100 inclusive. The time represented by each string in timePoints is guaranteed to be valid. The total time,
# after adding added_seconds, can roll over to the next day.
# Example: For timePoints = ['10:00:00', '23:30:00'] and added_seconds = 3600, the output should be ['11:00:00', '00:30:00'].

def add_seconds_to_times(timePoints, added_seconds):
    result = []

    for time_str in timePoints:
        # Split HH:MM:SS and convert to total seconds
        h, m, s = map(int, time_str.split(":"))
        total_seconds = h * 3600 + m * 60 + s

        # Add seconds and wrap around 24 hours if needed
        new_total = (total_seconds + added_seconds) % 86400

        # Convert back to HH:MM:SS
        new_h = new_total // 3600
        new_m = (new_total % 3600) // 60
        new_s = new_total % 60

        # Format as HH:MM:SS
        new_time_str = f"{new_h:02d}:{new_m:02d}:{new_s:02d}"
        result.append(new_time_str)

    return result


# You are given a time period formatted as a string in the HH:MM:SS - HH:MM:SS format. HH:MM:SS represents the time in hours, minutes, and
# seconds form, and the hyphen (-) separates the start time from the end time of the period.Your task is to calculate how many minutes pass
# from the start time until the end time. Here are some guidelines: The input times are always valid time strings in the HH:MM:SS format,
# with HH ranging from 00 to 23, and MM and SS from 00 to 59. The output should be an integer, representing the total length of the time
# period in minutes. The start time of the period will always be earlier than the end time, so periods that cross over midnight
# (like 23:00:00 - 01:00:00) are not considered. We are interested in the number of times the time passes some HH:MM:00 after the start
# time until the end time. Any remaining seconds should be disregarded; for instance, a period of "12:15:00 - 12:16:59" represents 1
# minute, not 2, and a period of "12:14:59 - 12:15:00" also represents 1 minute. Your function should look like this:
# def time_period_length(time_period):
#     pass  # Your code goes here
# Where time_period is a string formatted as HH:MM:SS - HH:MM:SS. The function should return a single integer that represents the total
# length of the specified time period in minutes. Example:  time_period_length("12:15:30 - 14:00:00")  # should return 105
def time_period_length(time_period):
    times = time_period.split('-')
    timePoints = [time.strip() for time in times]
    result = []
    for time_str in timePoints:
        # Split HH:MM:SS and convert to total seconds
        h, m, s = map(int, time_str.split(":"))
        result.append(h * 60 + m)

    # Convert back to HH:MM:SS
    return result[1] - result[0]


# You are given an initial date as a string in the format YYYY-MM-DD, along with an integer n which represents a number of days. Your task
# is to calculate the date after adding the given number of days to the initial date and return the result in the YYYY-MM-DD format.
# Keep these points in mind when resolving the task:
# The initial date string is always valid, formatted as YYYY-MM-DD, where YYYY denotes the year, MM the month, and DD the day.
# The given integer n is the number of days you have to add to the initial date and will be up to 50,000. The output should be a string
# showcasing the final date after adding n days, in the YYYY-MM-DD format.
# Your function will be in the form add_days(date: str, n: int) -> str.
# Constraints
# date = the date string in the YYYY-MM-DD format. The year YYYY will be from 1900 to 2100, inclusive. The month MM and the day DD will be
# valid for the given year. n = the integer representing the number of days you have to add to the initial date. n ranges from 1 to 50,000,
# inclusive. You should consider leap years in the calculation. A year is a leap year if it is divisible by 4, but century years (years
# divisible by 100) are not leap years unless they are divisible by 400. This means that the year 2000 was a leap year, although 1900 was
# not. The month and day result should always be two digits long, padding with a 0 if necessary. For example, July 9th should be formatted
# as "07-09".
# Example: For date = '1999-01-01' and n = 365, the output should be '2000-01-01'.

def is_leap_year(year):
    # Leap year logic
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)


def get_days_in_month(year, month):
    # Number of days in each month
    month_days = [31, 29 if is_leap_year(year) else 28, 31, 30, 31, 30,
                  31, 31, 30, 31, 30, 31]
    return month_days[month - 1]


def add_days(date: str, n: int) -> str:
    year, month, day = map(int, date.split('-'))

    while n > 0:
        days_in_current_month = get_days_in_month(year, month)
        remaining_days_in_month = days_in_current_month - day

        if n <= remaining_days_in_month:
            day += n
            n = 0
        else:
            n -= (remaining_days_in_month + 1)
            day = 1
            month += 1
            if month > 12:
                month = 1
                year += 1

    return f"{year:04d}-{month:02d}-{day:02d}"


from datetime import datetime, timedelta


def add_days_datetime(date: str, n: int) -> str:
    # Convert the input date string to a datetime object
    start_date = datetime.strptime(date, "%Y-%m-%d")

    # Add n days using timedelta
    new_date = start_date + timedelta(days=n)

    # Convert the new date back to string in the same format
    return new_date.strftime("%Y-%m-%d")

# Imagine you are working on a new feature for a text processing application. The feature requires you to provide users with the option to
# replace all occurrences of a certain substring in the entered text with a new substring.You are tasked with writing a function,
# replace_substring(text: str, old: str, new: str) -> str, that does the following:
# Accepts as input text (a string of length n, where 1 ≤ n ≤ 500, which includes only lowercase alphabets and spaces), old (a string of
# length k, where 1 ≤ k ≤ n, which includes only lowercase alphabets), and new (a string of length m, where 1 ≤ m ≤ 500, which includes
# only lowercase alphabets). Replaces every occurrence of the string old in text with the string new. Returns the updated text string with
# all replaced substrings.
# Please ensure that the case of the letters remains consistent during the process, meaning an uppercase letter should be replaced with an
# uppercase letter, and a lowercase letter should be replaced with a lowercase one. For instance, your function might be called as follows:
# replace_substring("hello world", "world", "friend")
# In this case, the output would be: "hello friend"
# This is because there is one occurrence of the substring 'world' in the string. This occurrence is replaced by 'friend', resulting in the
# return value "hello friend".

def replace_substring(text: str, old: str, new: str) -> str:
    return text.replace(old, new)

# You are given two lists, sentences and words, each comprising n strings, where n ranges from 1 to 100 inclusive. Each string in the
# sentences list has a length ranging from 1 to 500 inclusive. Each word in the words list is a single lowercase English alphabet word of
# length 1 to 10 inclusive. Your task is to find all instances of each word in the corresponding sentence from the sentences list and
# replace them with the reverse of the word. The words and sentences at the same index in their respective lists are deemed to correspond
# to each other. Return a new list comprising n strings, where each string is the sentence from the sentences list at the corresponding
# index, with all instances of the word from the words list at the same index replaced with its reverse. If the word is not found in the
# respective sentence, keep the sentence as it is. Remember, while replacing the instances of word in the sentence, you should preserve
# the case of the initial letter of the word. If a word starts with a capital letter in the sentence, its reversed form should also start
# with a capital letter.
# Example: For sentences = ['this is a simple example.', 'the name is bond. james bond.', 'remove every single e'] and words = ['simple',
# 'bond', 'e'], the output should be ['this is a elpmis example.', 'the name is dnob. james dnob.', 'remove every single e'].

def replace_words(sentences, words):
    result = []
    for sentence, word in zip(sentences, words):
        reversed_word = word[::-1]
        # Replace all instances of the word with its reversed form, preserving the case of the initial letter
        sentence = sentence.replace(word, reversed_word)
        sentence = sentence.replace(word.capitalize(), reversed_word.capitalize())
        result.append(sentence)
    return result

# Humans often make mistakes when they are typing quickly. In some cases, they may press two keys simultaneously, resulting in swapped
# characters in the text. Your task is to craft a Python function that helps identify such typos. Specifically, you are asked to construct
# a function called spot_swaps(source: str, target: str) -> List[Tuple[int, str, str]] that behaves as follows: Given two strings, source
# and target, of the same length n (1 ≤ n ≤ 500), inclusive, both comprise only lowercase English letters. The function should return a
# list of tuples. Each tuple should contain three elements: the zero-based index of the swap in the source string, the character (a string
# of length 1) at that index in source, and the character that swapped places with the source character in target.
# In other words, go over both strings simultaneously and, for each character from source and target at position i, find situations when
# source[i] != target[i] and source[i+1] = target[i] and source[i] = target[i+1]. This implies that the characters at positions i and i+1
# in the source string swapped places in the target string.
# Note: Characters can be swapped at most once. The swapped character pairs should be returned in a list in the order they were found (from
# the string start to end). Don't check for swaps at the last position of a string, since there is no character with which to swap.
# Example: For source = "hello" and target = "hlelo", the output should be [(1, 'e', 'l')].

from typing import List, Tuple

def spot_swaps(source: str, target: str) -> List[Tuple[int, str, str]]:
    swaps = []
    i = 0
    n = len(source)

    while i < n - 1:  # Avoid checking the last index
        # Check for swapped characters at positions i and i+1
        if (source[i] != target[i] and
            source[i] == target[i + 1] and
            source[i + 1] == target[i]):
            swaps.append((i, source[i], target[i]))
            i += 2  # Skip the next index to avoid double-swapping
        else:
            i += 1

    return swaps


if (__name__ == "__main__"):

    # Now we call the function and print the returned result outside of the function
    print(reverse_words_in_string("Hello neat pythonistas_123"))  # this will print: 'olleH taen 321_satsinohtyp'
    print(reverse_words_in_string_2("Hello neat pythonistas_123"))
    print(rotate_each_word_right("abc 123 def"))  # Output: "cab 312 fde"
    print(rotate_each_word_right("hello World 1"))  # Output: "ohell dWorl 1"
    print(rotate_each_word_right("a bc defg"))  # Output: "a cb gdef"
    print(transform_opposite_and_reorder("CapitaL letters"))
    # Output: "ovggvih XzkrgzO"
    print(format_words("SoME rAndoM _TeXT"))
    # Output: "Some Random _text"
    print(parse_and_multiply_numbers("I have 2 apples and 5 oranges,"))
    print(swap_letter_number("1-a-3-c-5"))
    # Output: "a-1-c-3-e"
    print(summing_valid_scores('joe scored 5 points, while adam scored 10 points and bob scored 2, with an extra 1 point scored by joe'))
    s = "joe scored 5 points, while adam scored 10 points and bob scored 2, with an extra 1 point scored by joe"
    print(summing_valid_scores_re(s))  # Output: 18
    s = "I have 2 apples and 5! oranges and 3 grapefruits."
    print(transform_string(s))
    time = '05:10:30'
    print(time_format(time, 123))
    input_timePoints = ['10:00:00', '23:30:00']
    input_added_seconds = 3600
    print(add_seconds_to_times(input_timePoints, input_added_seconds))
    print(time_period_length("12:15:30 - 14:00:00"))  # should return 105
    input_date = '1999-01-01'
    print(add_days(input_date, 365))
    print(add_days('1999-01-01', 365))  # ➜ '2000-01-01'
    print(add_days('2000-02-28', 1))  # ➜ '2000-02-29' (leap year)
    print(add_days('2100-02-28', 1))  # ➜ '2100-03-01' (not a leap year)
    print(add_days_datetime('1999-01-01', 365))  # ➜ '2000-01-01'
    print(add_days_datetime('2000-02-28', 1))  # ➜ '2000-02-29' (leap year)
    print(add_days_datetime('2100-02-28', 1))  # ➜ '2100-03-01' (not a leap year)
    print(replace_substring("hello world", "world", "friend"))
    # Example input
    sentences = ['this is a simple example.', 'the name is bond. james bond.', 'remove every single e']
    words = ['simple', 'bond', 'e']
    # Get the result
    result = replace_words(sentences, words)
    # Print the result
    print(result)
    source = "hello"
    target = "hlelo"
    print(spot_swaps(source, target))
