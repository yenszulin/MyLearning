#!/usr/bin/env python3

import release
release.copyright()
