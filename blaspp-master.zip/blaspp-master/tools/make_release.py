#!/usr/bin/env python3

import release
release.make( 'blaspp', 'include/blas.hh', 'src/version.cc' )
